<?php

define('DS', DIRECTORY_SEPARATOR);
define('ROOT', dirname(__FILE__));



// this is to load configuration and helper functions 
require(ROOT . DS . 'config' . DS . 'config.php');
require_once(ROOT . DS . 'app' . DS . 'libs' . DS . 'helpers' . DS . 'functions.php');
require_once(ROOT . DS . 'core' . DS . 'Router.php');

//load classes
function autoload($className){
	$class_path = ROOT . DS . 'core' . DS . $className . '.php';

	$controller_path = ROOT . DS . 'app' . DS . 'controllers' . DS . $className . '.php';

	$model_path = ROOT . DS . 'app' . DS . 'models' . DS . $className . '.php';


	if (file_exists($class_path)) 
	{
		require_once($class_path);
	}
	else if(file_exists($controller_path))
	{
		require_once($controller_path);
	}
	else if(file_exists($model_path))
	{
		require_once($model_path);
	}
}

function getWeekday($date){
		 return ceil(date('d',strtotime($date))/7);
	}
	$current_week= getWeekday(date);

	define('current_week', $current_week);
	 	
spl_autoload_register('autoload');

session_start();

$db = DB::getInstance();


$url = isset($_SERVER['PATH_INFO']) ? explode('/', ltrim($_SERVER['PATH_INFO'], '/')) : [];

	
if (!Session::exist(CURRENT_USER_SESSION_NAME) && COOKIE::exist(REMEMBER_ME_COOKIE_NAME)) 
{
	Users::loginUserFromCookie();
}

	Router::route($url);   



