The library uses ES6 `Promise` API for asynchronous calls. If it is used in older browsers,
you have to provide a "shim" adding the `Promise` API to your target browser.
