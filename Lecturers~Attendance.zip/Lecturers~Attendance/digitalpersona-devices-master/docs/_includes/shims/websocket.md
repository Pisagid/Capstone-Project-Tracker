The library uses [`websocket` browser API](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API)
for streaming authentication data and messages.
Browsers not supporting `WebSocker Standard RFC 6455` are not supported.
