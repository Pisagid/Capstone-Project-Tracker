The library uses ES6 `fetch` API for HTTP connection. If it is used in older browsers,
you have to provide a "shim" adding the `fetch` API to your target browser.
