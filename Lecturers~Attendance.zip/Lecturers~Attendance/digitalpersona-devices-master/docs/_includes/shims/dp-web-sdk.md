The library uses the DigitalPersona WebSDK library. You must include the library
into your application script list:

```html
<html>
   <body>
     ...
     <script type="text/javascript" src="websdk/websdk.client.ui.min.js"></script>
   </body>
</html>
```
