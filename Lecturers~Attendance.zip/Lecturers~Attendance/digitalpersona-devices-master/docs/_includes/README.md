This folder keeps only pieces of documentation that are repeated in repositories 
without changes. Use `{% include <path/name.md> %}` to insert these parts into your doc pages.
