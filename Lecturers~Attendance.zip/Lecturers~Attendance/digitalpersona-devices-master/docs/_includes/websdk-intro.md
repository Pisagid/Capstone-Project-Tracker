> DigitalPersona Web SDK (DP WebSDK) is a Windows service and a user agent application running 
locally on a user device and providing access to authentication devices like fingerprint readers,
smartcard readers etc. These devices are not directly accessible from Javascript running in a browser.
