* Evergreen browsers: 
    * Chromium-based
    * Firefox
    * Edge
* Legacy browsers (shims required):
    * IE11 
