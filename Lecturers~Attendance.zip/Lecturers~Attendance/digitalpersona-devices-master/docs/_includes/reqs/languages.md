The library is distributed in following forms:
 * TypeScript (code and typings)
 * transpiled ES5 (unbundled and bundled UMD module)
 * transpiled ES6 (unbundled and bundled UMD module)
