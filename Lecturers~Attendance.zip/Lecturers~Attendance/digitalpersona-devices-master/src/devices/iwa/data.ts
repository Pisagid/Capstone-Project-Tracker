import { AuthenticationHandle } from "@digitalpersona/services";

/**@internal
 *
 */
export interface IWAData {
    Handle: AuthenticationHandle;
    Data: string;
}
