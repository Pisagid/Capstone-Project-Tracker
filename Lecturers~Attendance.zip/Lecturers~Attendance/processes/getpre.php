<?php 

	extract($_POST);
	$prgcoursequery = $this->TblprogcoursesModel;

	if ($trm > 'Sem 1') {
	?>
		<select class="form-control pre"  name="pereq">
		<option value="">Select Prerequisite Course:....</option>
		<?= $prereq = $prgcoursequery->precourses($trm);?>
		</select>
	<?php
	}
	else 
	{
	?>
		<select class="form-control  pre"  name="pereq">
		<option value="">Select Prerequisite Course:....</option>
		</select>
	<?php
	}
	?>
<?php ?>
