     <style type="text/css">
  input[type="checkbox"]
  {
  display: inline-flex; 
  width: 30%;
  }

  .search
  {
    float: right !important;
    display: inline-block;
    border: none;
      border-bottom: 1px solid;
      border-radius: 5px;

  }
  .searchfield, .searchIcon
  {
    display: inline-block;
  }
  .searchfield
  { 
    width: 92%;
  }

  .searchIcon
  {
    width: 5%;
  }
  .searchbar
  {
      padding-left: 10px;
      height: 40px;
      border: none;
  }
  .searchbar:focus, .searchbar:active, .searchfield:focus, .searchfield:active, .searchIcon:focus, .searchIcon:active, 
  {
    border: none !important;
    border-color: white !important;    
  }
  .coursesviewcontent
{
  margin-top: 1%;
  opacity: 1;
  height: 600px;
  position: relative;
  margin-bottom: 10px; 
  overflow: auto;
  background-color: transparent;
  display: inline-block;
  border-bottom: none;
  overflow-x: hidden;
  width: 100%;
}

 </style>
    <?php 
            if (isset($_POST['faculty_id'])) {
              extract($_POST);
            $lecturerquery = $this->TbllecturerDataModel; 
            $this->load_model('SCampus'); $campusquery = $this->SCampusModel;
            $this->load_model('Tblprogcourses'); $allcourses = $this->TblprogcoursesModel;
            $lecdetails = $lecturerquery->lecdetailsQuery($faculty_id); 
              $fname=  $lecdetails[0]->fname;
              $mname=  $lecdetails[0]->mname;
              $lname= $lecdetails[0]->lname;
              $lec_name = $fname." ".$mname." ".$lname;
              $lec_name = strtolower($lec_name);
              $lec_name = ucwords($lec_name, ' -');
              
              $lecpic = ROOT . DS . 'images'. DS . 'uploads'. DS .$lecdetails[0]->username.'_profile_image';
              $pic_show = PIC_ROOT .$lecdetails[0]->username.'_profile_image';
              $picexist = file_exists($lecpic);
              
              ?>
              
        <div class="row lecmodal" style="margin-top: -50px; display: inline-block; width: 100%;" >
                   <button class="lecclose close" type="button" style="right: 0 !important; margin-top: 11px; background-color: red !important;">
                      <span aria-hidden="true">×</span>
                    </button>
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900  mb-1">Assign Courses For <?= $lec_name ?></h1>

              </div>
              <hr>
             <form  method="post" id="lecassignForm" action="javascript:void(0)">
               <div class="row">
                 <div class="col-sm-4 form-check-inline" style="display: inline-block; margin: auto;">
                  <div class="row" style="margin:auto;">
                      <img type="file"
                       src="<?=
                        (file_exists($lecpic)) ?
                          $pic_show : PROOT."images/default.png"?>" alt="" id="profile-image" disabled="disabled">
                  </div>
                  </div>
                </div> 
                <div class="form-group row">
                  <div class="col-sm-4 mb-3 mb-sm-0">
                    <label>First Name:</label>
                    <input type="text" class="form-control " value="<?= $fname ?>" placeholder=" Enter First Name" name="fname" disabled="disabled">
                  </div>
                  <div class="col-sm-4">
                    <label>Middle Name:</label>
                    <input type="text" class="form-control " value="<?= $mname ?>" placeholder="Enter Middle Name" name="mname" disabled="disabled">
                  </div> 
                  <div class="col-sm-4">
                    <label>Last Name:</label>
                    <input type="text" class="form-control " value="<?= $lname ?>" placeholder="Enter Last Name" name="lname" disabled="disabled">
                  </div>
                </div>
                <div class="row">
                  
                <div class="col-sm-4 user-name">
                    <label>Faculty ID:</label>
                    <input type="text" name="username" value="<?= $lecdetails[0]->username ?>" placeholder="Enter Faculty ID" disabled="disabled" class="form-control  userChecker" >
                  </div>
                  <div class="col-sm-4 user-name" style="display: none;">
                    <label>Lecturer ID:</label>
                    <input type="text" name="lecturer_id" value="<?= $lecdetails[0]->lecturer_id ?>" placeholder=""  class="form-control " >
                  </div>
                  <div class="col-sm-4 form-group" >
                    <label>Title:</label>
                    <select class="form-control " name="title_id" disabled="disabled">
                      <?php $title = array('0'=> 'Select Title:','1'=> 'Mr.','2'=> 'Mrs.', '3'=> 'Ms.','4'=> 'Dr.','5'=> 'Associate Professor.','6'=> 'Professor.','7'=> 'Rev.','8'=> 'Lawyer.','9'=> 'Ing.'); ?>
                      <option value="<?= $lecdetails[0]->title_id ?>"><?= $title[$lecdetails[0]->title_id]?></option> 
                      
                    </select>
                  </div>
                  <div class="col-sm-4 form-group" >
                    <label>Campus:</label>
                    <select class="form-control user-input" name="campus">
                      <option value=""> Select Campus:</option>
                          <?= $campusquery->allcampusQuery();?>
                    </select>
                  </div>
                </div>
                <div class="row form-group" style="display: inline-block;">
                  <div class="search r0">
                    <div class="searchIcon">
                      <span ><i class="fas fa-search"style="width: 5px !important;"></i></span>
                    </div>
                    <div class="searchfield">
                      <input type="search" class="searchbar" name="" id="coursesearch" onkeyup="searchFuntion()" placeholder="Search for Course: ....">
                    </div>
                    
                  </div>
                  <div class="col-sm-12  form-group coursesviewcontent" id="courses_table" style="height: 200px;">
                    <table id="courses" name="courses"   style="width: 100% !important;">
                         <thead >
                            <tr class="bg-secondary" style="color: white; height: 40px">
                             <th style="width: 10% ;" scope="col"><input class="checkbox s_checkbox " type="checkbox" name="course_code[]" value="">Select Course Code</th>
                              <th style="width: 5800px" scope="col">Course Title</th>
                              <th style="width: 20%;" scope="col">Course Code</th>
                            </tr>
                          </thead>
                        <?= $allcourses->allcoursesQuery()?>
                     </table>
                  </div>
                </div>

                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                <div class="form-group row">
                   <div class="col-sm-8" style="display: inline-flex;">
                    <div class="col-md-6">
                    <button id="lecassign"  class="btn btn-primary btn-user btn-block"> AssignCourse</button>
                    </div>
                  </div> 
                  <div class="col-sm-4" style="display: inline-flex;">
                    <div class="col-md-12">
                     <button id=""  class="lecclose btn btn-danger btn-user btn-block r-0"> Cancel</button>
                    </div>
                  </div> 
                 
                </div>
              </form>

            </div>
            <hr>
               
        </div>
      </div>
        <script type="text/javascript">
                    function searchFuntion() {
                      // Declare variables
                      var input, filter, table, tr, td, i, txtValue , nxtvalue;
                      input = document.getElementById("coursesearch");
                      filter = input.value.toUpperCase();
                      table = document.getElementById("courses");
                      tr = table.getElementsByTagName("tr");

                      // Loop through all table rows, and hide those who don't match the search query
                      for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[1];
                        td1 = tr[i].getElementsByTagName("td")[2]
                        if (td) {
                          txtValue = td.textContent || td.innerText;
                          nxtvalue = td1.textContent || td1.innerText;
                          if (txtValue.toUpperCase().indexOf(filter) > -1 || nxtvalue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                          } else {
                            tr[i].style.display = "none";
                          }
                        }
                      }
                    }

                    $('#Attendanceform').on('keyup keypress', function(e) {
                      var keyCode = e.keyCode || e.which;
                      if (keyCode === 13) { 
                        e.preventDefault();
                        return false;
                      }
                    });
                    </script>
            <?php 
            }
           ?>