<?php 

	extract($_POST);
	if (isset($_POST['staff_type'])) {
		$usersquery = $this->UsersModel;
	 $conditions = [
                    'staff_type' => $staff_type
                 ];

				$usertype = $usersquery->selectAll($conditions);
					
					$count = $usersquery->count();
                  $usertype = $usersquery->results();

       
				$counting = $count +1;


	

			if ($staff_type == 1 || 2) {
				//to initiate username 
				if ($staff_type == 1) {
					$user = "att-adm-";
				}
				elseif ($staff_type == 2) {
					$user = "att-usr-";
				}

			//to get full username
			if (strlen($count)==1) {
				if ($count==9) {
					$username = $user."00".$counting;
				}else
				{
					$username = $user."000".$counting;
				}
				$username = strtoupper($username);
			}
			elseif (strlen($count)==2) {
				if ($count==99) {
					$username = $user."0".$counting;
				}else
				{
					$username = $user."00".$counting;
				}
				$username = strtoupper($username);
			}
			elseif (strlen($count)==3) {
				if ($count==99) {
					$username = $user."".$counting;
				}else
				{
					$username = $user."0".$counting;
				}
				$username = strtoupper($username);

			}
			?>
 

			<input type="text" name="username" data-name='Username' id="username" placeholder="Username" class="form-control form-control-user user-input userChecker" disabled="disabled" value="<?php echo $username; ?>">
			<?php 

		}
	}
	else if (isset($_POST['school'])) {
			
		if (!$school) {
		}
		else{
		$lecturerquery = $this->TbllecturerDataModel;
			$id = array('1' => 'ASD' ,'2' => 'SAT' ,'3' => 'ABS');
			$fac = $id[$school];
			$cond = "$fac%";
			$count = $lecturerquery->users($cond);
			$counting = $count +1;

			//to get full username
			if (strlen($count)==1) {
				if ($count==9) {
					$username = $fac."-FAC-00".$counting;
				}else
				{
					$username = $fac."-FAC-000".$counting;
				}
				$username = strtoupper($username);
			}
			elseif (strlen($count)==2) {
				if ($count==99) {
					$username = $fac."-FAC-0".$counting;
				}else
				{
					$username = $fac."-FAC-00".$counting;
				}
				$username = strtoupper($username);
			}
			elseif (strlen($count)==3) {
				if ($count==99) {
					$username = $fac."-FAC-".$counting;
				}else
				{
					$username = $fac."-FAC-0".$counting;
				}
			}
				$username = strtoupper($username);

		 	echo $username;
	
	}
}
 ?>		

