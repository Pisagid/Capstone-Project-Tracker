<?php 
	
	$prgcoursequery = $this->TblprogcoursesModel;
	extract($_POST);

	$run = (isset($run)) ? $run : "no";
	$crscode = strtoupper($crscode);

	//check if course code exist
	$cosexequery = $prgcoursequery->coursexist($crscode, $prgcode);

	//insert
	if (!$cosexequery) {

		if (isset($pereq)) {
			$cosinsert = $prgcoursequery->insertcourse($crscode, $crstitle, $crdhrs, $yr, $trm, $prgcode, $run, $pereq);
		}else{
			$cosinsert = $prgcoursequery->insertcourse($crscode, $crstitle, $crdhrs, $yr, $trm, $prgcode, $run, null);
		}

		
			echo ($cosinsert) ? "Course Added Successfully" : "0";
	
	}
	else
	{
		if (isset($pereq)) {
			$cosinsert = $prgcoursequery->updatecourse($crscode, $crstitle, $crdhrs, $yr, $trm, $prgcode, $run, $pereq);
		}else{
			$cosinsert = $prgcoursequery->updatecourse($crscode, $crstitle, $crdhrs, $yr, $trm, $prgcode, $run, null);
		}

		echo ($cosinsert) ? "Course Updated Successfully" : "0";
	}
	
			
 ?>