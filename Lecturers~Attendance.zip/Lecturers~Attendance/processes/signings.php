    <?php 
            if (isset($_POST['course_code'])) {
              extract($_POST);
            $lecturerquery = $this->TbllecturerDataModel; 
            $lecturequery = $this->LecturesModel; 
            $sessionquery = $this->SessionsModel; $wsessionquery = $this->WSessionsModel; $campusquery = $this->SCampusModel;

             $coursedetails = $lecturequery->coursedetails($course_code, $campus);
            $lec_name = $lecturerquery->singleLectQuery($coursedetails[0]->lecturer_id); 
            $ses_name = (day<6) ? $sessionquery->sessioname() : $wsessionquery->sessioname();

              $username = $lecturerquery->username($coursedetails[0]->lecturer_id);
              $lecpic = ROOT . DS . 'images'. DS . 'uploads'. DS .$username.'_profile_image';
              $pic_show = PIC_ROOT .$username.'_profile_image';
              $picexist = file_exists($lecpic);
              ?>
              
        <div class="row lecmodal" style="margin-top: -50px; display: inline-block; width: 100%;" >
              <button class="lecclose close" type="button" style="right: 0 !important; margin-top: 11px; width:10px !important;">
                      <span aria-hidden="true">×</span>
                    </button>
          <div class="col-lg-12">
            <div class="p-2">
              <div class="text-center mt-4">
                <h1 class="ptext-gray-900 ">Lecturers <?= ($sign_type == "course_signin") ? "SignIn" : "SignOut"?> For <?= $lec_name ?></h4>
                  <hr>
              </div>
             <form  method="post" id="lec<?= ($sign_type == "course_signin") ? "SignIn" : "SignOut"?>Form" action="javascript:void(0)">
               <div class="row">
                   <div class="col-sm-4 form-check-inline" style="display: inline-block; margin: auto;">
                  <div class="row" style="display: block !important;">
                      <label style="text-align: center;">Lecturer Image:</label>
                  </div>
                  <div class="row" style="margin:auto;">
                      <img type="file"
                       src="<?=
                        (file_exists($lecpic)) ?
                          $pic_show : PROOT."images/default.png"?>" alt="" id="profile-image">
                  </div>
                  <div class="row" style="display: none;">
                    <input type="file" name="image" onchange="displayImage(this);" id="faculty-image" >
                  </div>
                  </div>
                </div> 
          
                <div class="row form-group ml-5" >
                  <div class=" col-sm-12">
                    <div class="row form-group">
                      <div class="col-sm-6 form-group">
                        <label>Course Code:</label>
                        <input type="text" class="form-control form-control-user user-input code" value="<?= $coursedetails[0]->course_code ?>" disabled="disabled" name="course_code">
                      </div>
                      <div class="col-sm-6 form-group">
                        <label>Lecturer's ID:</label>
                        <input type="text" class="form-control form-control-user user-input "id="faculty_id" value="<?= $lecturerquery->username($coursedetails[0]->lecturer_id) ?>" disabled="disabled" name="lecturer_id">
                      </div> 
                      <div class="col-sm-6 form-group">
                        <label>Campus:</label>
                        <input type="text" class="form-control form-control-user user-input" value="<?= $campusquery->campusQuery($coursedetails[0]->campus_id) ?>" disabled="disabled" placeholder="Enter Last Name" name="campus">
                      </div> 
                       <div class="col-sm-6 form-group">
                        <label>Period:</label>
                        <input type="text" name="ses_name" value="<?= $ses_name ?>" disabled="disabled"  class="form-control user-input">
                      </div>
                      <div class="col-sm-6 form-group">
                        <label>Date:</label>
                        <input type="text" name="date" value="<?= date ?>" disabled="disabled" placeholder="Enter Phone Number" class="form-control user-input">
                      </div>
                       <div class="col-sm-6 form-group">
                        <label>Lecturer Password:</label>
                        <input type="password" name="password" value="" placeholder="Enter Password " class="form-control user-input pass">
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-4 d-none">
                    <div class="col-sm-4 form-check-inline" style="display: inline-block; margin: auto;">
                      <div class="row" style="display: block !important;">
                          <label style="text-align: center;">FingerPrint Scan:</label>
                      </div>
                    </div>
                          <img type="file" class="col-8" src="<?php echo PROOT ?>images/fingerdefault.png" alt="" id="">
                          <button class="ml-8 bg-success align-items-center">Capture Finger</button>  
                   </div>
                 </div>

                </div>

                <hr class="mt-0">
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                 <div class="form-group row">
                   <div class="col-sm-8" style="display: inline-flex;">
                    <div class="col-md-6">
                    <button id="lec<?= ($sign_type == "course_signin") ? "SignIn" : "SignOut"?>"  class="btn btn-primary btn-user btn-block"> <?= ($sign_type == "course_signin") ? "SingIn" : "SignOut"?></button>
                    </div>
                  </div> 
                  <div class="col-sm-4" style="display: inline-flex;">
                    <div class="col-md-12">
                     <button id=""  class="lecclose btn btn-danger btn-user btn-block r-0"> Cancel</button>
                    </div>
                  </div> 
                 
                </div>
              </form>
            </div>
          
        </div>
      </div>
            <?php 
            }
           ?>