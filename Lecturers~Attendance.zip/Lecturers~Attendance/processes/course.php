<?php 
extract($_POST);

	$lecturerquery = $this->TbllecturerDataModel;
	$assignlectquery = $this->TbllecturerAssignCoursesModel;
	$sessionquery = $this->SessionsModel; $wsessionquery = $this->WSessionsModel; $campusquery = $this->SCampusModel;
	$attendancequery = $this->AttendanceModel;
	$daysquery = $this->DaysModel;
	$lhallquery = $this->LHallModel;
	$lecturequery = $this->LecturesModel;
	$updatequery = $this->UpdatedModel;

              $lec_name = $lecturerquery->lectname($lecturer_id); 
             

		$fields = [
			'password' => 'password'
		];

		$conditions = [
			'username' => $lecturer_id
		];	

		$verify = $lecturerquery->select($fields, $conditions);
		$verify = $lecturerquery->results();

			//this is to get lecturer's password in database 
			$dbpass = $verify[0]->password;
			//when database password is the same as inputted password from the lecturer
			if ($dbpass==$password) 
			{
				 $session_id = (day<6) ? $sessionquery->sessionid($ses_name) : $wsessionquery->sessionid($ses_name);

           		 $campus = $campusquery->campusid($campus);
              		
   				      $attend_query = $attendancequery->att($course_code, $campus, month, year);
                     
                      $a_mark = 0;
                      foreach ($attend_query as $mark) {
                      	$a_mark = $a_mark + $mark->attended;
                      }
					
					$day_id = $lecturequery->courseday($course_code, $campus);

					$day = $daysquery->daynameQuery($day_id);
								//to get number of times that day appears in a month        
				            $count = 0;
				            $days = cal_days_in_month(CAL_GREGORIAN, month, year);
				            $date = new Datetime(year.'-'.month.'-01');
				            for($i=1; $i<=$days; $i++){
				               if($date->format('l') == $day){
				                   $count++;
				                 }
				                 $date->modify('+1 day');
				             }

				            //assigns no_show to the number of times the day for that course was suppose to appear in that month and year 
				               
                             $maximum = $count;

                             // this is to make sure a course signing in is not more than the expected times the day scheduled appears in that month
	                  if ($a_mark <= $maximum) 
	                  {
                     	$attend_check_query = $attendancequery->booked($course_code,$campus);
						//insert into attendance table
						 if (sizeof($attend_check_query)<1) {
                              $att_insert = $attendancequery->insertcourseQuery($course_code, $campus, $session_id);
                              
                             	if ($att_insert)
                                     echo "Lectures SignIn For ".$lec_name." Is Succesful"; 
                              }
                              //update attendance table
                              else{
                              	$mark =1;
                              		$att_insert = $attendancequery->updatecourseQuery($course_code, $campus, $session_id, $mark);
                              		if ($att_insert)
                                     echo "Lectures SignOut For ".$lec_name." Is Succesful"; 
                              }
                                 
	                         	
                         }
                         //exceeded number of signin's
                         else
                         {
                         	echo 2;
                         }
                        
                        
              	}
              	//you are not the assigned lecturer
              	else
              	{
              		echo 1;
              	}

	
 ?>