<?php 
	$userquery = $this->UsersModel;
$registryquery = $this->RegistryModel;
extract($_POST);
	$staff_id = $_SESSION['staff_id'];
		$date = date("Y/m/d");
		 $password = password_hash(DAFAULT_QBTTXPSE, PASSWORD_DEFAULT);
		 $username = strtolower($username);

	    $fullname = $fname." ".$lname;

		 $fields = [
		 	'fullname' => $fullname,
		 	'staff_type' => $staff_type,
		 	'username' => $username,
		 	'password' => $password,
		 	'campus' => $campus_name
		 ];
		 
		$userregister = $userquery->insert($fields);
		
			if (isset($userregister)>0) {
				 $fields = [
				 	'staff_id' => $staff_id,
				 	'username' => $username,
				 	'date_of_registry' => $date
				 ];

				$registryquery = $registryquery->insert($fields);

				echo 1;
			}	
	
 ?>