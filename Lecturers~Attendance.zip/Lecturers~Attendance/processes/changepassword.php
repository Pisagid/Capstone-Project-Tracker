<?php 
	$changequery = $this->UsersModel;

		$user = $_POST['username']; $pass = $_POST['opassword']; 
		$new_pass = $_POST['fpassword'];

	 
		$fields = [
			'password' => 'password'
		];

		$conditions = [
			'username' => $user
		];	

		$verify = $changequery->select($fields, $conditions);
		$verify = $changequery->results();

	if (isset($_POST)) 
	{

		foreach($verify as $row) 
		{
			$dbpass = $row->password;
			$n_pass = password_verify($pass, $dbpass);

			if ($pass==$n_pass) 
			{	
				$password = password_hash($new_pass, PASSWORD_DEFAULT);
				$fields = [
					'password' => $password
				];
				$update = $changequery->update($fields, $conditions);
				
				echo 1;	
				break;

			}
			else
			{
				echo 2;
			}
		}
	}

 ?>