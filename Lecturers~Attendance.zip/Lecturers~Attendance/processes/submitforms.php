<?php 

	$userquery = $this->UsersModel;
	$staffquery = $this->StaffModel;
	$assignlectquery = $this->TbllecturerAssignCoursesModel;
	$progcoursesquery = $this->TblprogcoursesModel;
	$lectnamequery = $this->TbllecturerDataModel;
	$sessionquery = $this->SessionsModel;
	$weekendquery = $this->WSessionsModel;
	$daysquery = $this->DaysModel;
	$campusquery = $this->SCampusModel;
	$weeksquery = $this->WeeksModel;
	$lhallquery = $this->LHallModel;
	$lecturequery = $this->LecturesModel;
	$updatedquery = $this->UpdatedModel;
	$attquery = $this->AttendanceModel;
	$registryquery = $this->RegistryModel;
	extract($_POST);
	
	if (isset($submit)){
		if ($submit == 1) {
			$day = date("l", strtotime($date));
				//day converted to get day id in database
				$day = $daysquery->dayQuery($day);
				$current = date('Y-m-d');
				//making sure selected date for make is not past
				if ($date >= $current) {
					//checking if course is already updated
					$exequery = $updatedquery->existcourseQuery($course_code, $day, $date, $campus);
					//updating if course is already scheduled
					if ($exequery) {
						$update = $updatedquery->updatecourseQuery($course_code, $lec_id, $day, $date, $l_hall, $session_id, $campus, $user_session);
						echo 'Updated';
					 } 
					else
					{
					 	$insert = $updatedquery->insertcourseQuery($course_code, $lec_id, $day, $date, $l_hall, $session_id, $campus, $user_session);
						echo 'Inserted';
				 	}
				}
				else{
					echo $date;
				}
				
			}
			else if($submit == 2){
				$course_code = strtoupper($course_code);
				//to get lecturer's id of to the assigned course in that campus
				$lecturer_id = $assignlectquery->assignLectQuery($course_code, $campus);
				if ($lecturer_id) {
					// to check if the course is already scheduled
					$courseCheck = $lecturequery->courseQuery($course_code, $campus);
					//to check if lecrture is already in use
					$hallCheck = $lecturequery->lhallQuery($session_id, $day, $l_hall, $campus);
					//to check if hall is booked
					if ($hallCheck) {
						echo 2;
					}
					//when lecture is free
					else{
						//if course is assigned already in that campus
						if($courseCheck){
							//updating query
							$update = $lecturequery->updatecourseQuery($course_code, $lecturer_id, $day, $l_hall, $session_id, $campus, $user_session);
							echo 1;
						}
						// when course has not been assigned
						else{
							//inserting query
							$insert = $lecturequery->insertcourseQuery($course_code, $lecturer_id, $day, $l_hall, $session_id, $campus, $user_session);
							echo 3;
						}
					}

				}
				// when there is no lecturer assigned to the course in that campus
				else{
					echo 4;
				}
			}
	}
	else
	{
    extract($_POST);
    // to get month name 
    $dateObj   = DateTime::createFromFormat('!m', $month);
    $monthName = $dateObj->format('F');
    
    ?>
   
    <div id="attendanceInfo" class="col-12">
    	<?php require(ROOT . DS . 'processes' . DS . 'printcss.php'); ?>
        <h3 class="attend_sheet_header" style="text-align: center;">Attendance sheet for <?= $monthName.' '. $year; ?></h3>
        <?php  
    //to get number of weeks in that month  
    $exp_weeks = $lectnamequery->weeks($month,$year);
                                                 
    foreach ($lecturer_id as $row) {
		    //get fullname of lecturer
    			$lec_name = $lectnamequery->lectname($row);

    			$lectnamequery->style($exp_weeks);
		            $cout_lec = strlen($lec_name);
		            if ($cout_lec>0) { ?>
                            <h3 class="attend_sheet_header" style="padding-top: 10px; text-align: center;">Attendance sheet for <?=$lec_name .', ' .$monthName.' '. $year; ?></h3>
                            <div class="att_view">
                                
                                <table id="attendance_table">
                                    <thead >
                                        <tr class="m-2 p-1 bg-gray-100 shadow">
                            <?php 
                                    $attendance_head = array('1' => 'Courses', '2' => '', '3' =>'Attended', '4' =>'No Shows', '5' =>'Total');

                                    $attended = 0; $lecturer_id;
                                    $lec_id = $lectnamequery->getID($row);
                                    

                                     $assignquery = $assignlectquery->assignedcourses($lec_id);
                               if(sizeof($assignquery)>0){                 
                            //get lecturer course
                                    for($a = 1; $a<=sizeof($attendance_head); $a++){
                                        if ($a==1) {
                                            ?>
                                            <th class="att_header">
                                                <?=$attendance_head[$a]; ?><br>/School
                                            </th> <?php 
                                            }
                                         else if($a == 2){
                                            $weeks = $weeksquery->allweeks($exp_weeks);
                                   			 foreach($weeks as $row) { ?>
                                            <th class='att_header'>
                                              <?= $row->week_name; ?>
                                            </th><?php  
                                           }
										}
                                        else{?>
                                            <th class="att_header">
                                                <?=$attendance_head[$a]; ?>
                                            </th><?php  
                                        
                                        }
                                    }
                                 ?>
                                    </tr>
                                </thead>
                                <tbody>
                            <?php
                            foreach ($assignquery as $key) 
                            {
                            	$course_code = $key->course_code; $campus= $key->campus;
                                 $attend_query = $attquery->attendedquery($course_code, $campus, $month, $year);

                               if ($campus>6) {
                               	 //to get school name
                               	continue;

                               }
                                $sch = $campusquery->campusQuery($campus);

                                $day_id = $lecturequery->courseday($course_code, $campus);?>
                                <tr class="lect-row"> 
                                	 <td class="att_data">
                                            <?= $course_code;?><br><?= $sch; ?>
                                         </td>
                                    <?php 
                               if($day_id){
								$day = $daysquery->daynameQuery($day_id);
								//to get number of times that day appears in a month        
				                $count = 0;
				                $days = cal_days_in_month(CAL_GREGORIAN, $month, $year);
				                $date = new Datetime($year.'-'.$month.'-01');
				                for($i=1; $i<=$days; $i++){
				                    if($date->format('l') == $day){
				                        $count++;
				                    }
				                    $date->modify('+1 day');
				                }

				                 //assigns no_show to the number of times the day for that course was suppose to appear in that month and year 
				                  $no_show = $count;
								}
								$attended = 0;$duration  = array(); $i_time = 0; $t_time = 0; $t_attended = array();	 $cal_time = 0;
                                if ($attend_query) {
                                    ?>
                                       
                                        <?php 
                                        //$duration  = array(); $i_time = 0; $t_time = 0; $t_attended = array();
                                        for($w=1; $w<=$exp_weeks;$w++)
                                            {
                                               $att_query =$attquery->attended($course_code, $month, $year, $w, $campus);

                                               $timequery =$attquery->attended($course_code, $month, $year, $w, $campus);
                                                $i_attend = 0;
                                                foreach ($att_query as $value) {
                                                  $i_attend = $i_attend + $value->attended;
                                                  $counting = sizeof($duration);
                                                  foreach ($timequery as $time) {
                                                  	$start_time = $time->start_time;
                                                  	$end_time = $time->end_time;
                                                    if (!isset($start_time) ||  !isset($end_time)) {
                                                         $no_time = new DateTime;
                                                         $no_time->setTime(0, 0);
                                                          $start_time=  $no_time->format('H:i:s');
                                                           $end_time= $no_time->format('H:i:s');
                                                        }
                                                        $timesplit=explode(':',$start_time);
                                                        $start_time =($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);
                                                                
                                                        $timesplit=explode(':',$end_time);
                                                        $end_time =($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);
                                                                 
                                                        $i_time = $end_time-$start_time;
                                                        // echo "difference is ".$i_time."<br>";
                                                        $duration[$counting]= $i_time;
                                                                  
                                                        $t_time = $t_time + $duration[$counting];
                                                        //echo "total is ".$t_time."<br>";
                                                        $cal_time = date("i:s", $t_time);
                                                        //echo "total in minutes ".$cal_time."<br>";
                                                  }
                                                  
                                                }
                                                 if ($i_attend==1) {?>
                                                        <td class="att_data"><?=$i_attend."<br>";?></td><?php
                                                    }
                                                    else
                                                    { ?>
                                                        <td class="att_data"><?=$i_attend=0;?></td><?php  
                                                    }?>
                                                
                                                <?php
                                                }?>
                                    
                                        <td class="att_data">
                                        <?php  
                                        $attend =$attquery->att($course_code, $month, $year, $campus);

                                         foreach($attend as $att){
                                               $attended = $attended + $att->attended;
                                             }
                                       		 echo $attended;
	                                        ?>
	                                    </td>
                                        <td class="att_data">
                                       	 <?= $no_show = $no_show - $attended;?>
                                    	</td>
                                        <td class="att_data"><?=$cal_time;?></td>
                                    
                                    <?php  
                                }


                                //when not in attendance table
                                else{
                                        for($w=0; $w<$exp_weeks;$w++)
                                            { ?>
                                             <td class="att_data"><?= 0;?></td>
                                           <?php
                                            }
                                        ?>
                                        <td class="att_data"><?= $attended;?></td>
                                        <td class="att_data"><?=0?></td >
                                        
                                        
                                            <td class="att_data">
                                            <?php  echo 0;?>
                                        </td>
                                        
                                
                                <?php
                                }
                            }

                            ?>
                        </tr>
                        <?php 
                            }

                            //no course assigned to that lecturer
                            else{
                                ?><tr>
                                <h3 class="attend_sheet" style="text-align: center;">No assinged course for this lecturer</h3>
                                </tr>
                                <?php  
                            }

                             ?>
                               </tbody>
                        </table>  
                     
                      </div>

                 
<?php            
            }   
                }
                ?>
 </div>

 <div id="attendancePrint" style="">
       <button href="#" value="attendanceInfo" class="btn btn-primary btn-user btn-block " id="print">Print</button>
 </div>
 <?php
	}
?>
	
