<?php
     
     extract($_POST); 
     $prgcoursequery = $this->TblprogcoursesModel;
            $semquery = $this->SemestersModel;
           $yearquery = $this->YearsModel;
          $schprogquery = $this->TblprgmsModel;
          $coursedetails = $prgcoursequery->coursedet($crscode, $prgcode);
      		
          if (!$coursedetails) {?>
          	<div class="alert-message" id="message" style=" margin-top: 5px;">
          		<h1 class="text-center">There is A Space Preceding Course Code, Contact Database Admin</h1>
          	</div>
          	
         <?php }
         else
         {

	          $crstitle = $coursedetails[0]->crstitle;
	          $crscode = $coursedetails[0]->crscode;
	          $trm = $coursedetails[0]->trm;
	          $yr = $coursedetails[0]->yr;
	          $crdhrs = $coursedetails[0]->crdhrs;
	          $run = (strlen($coursedetails[0]->run)>2) ? $coursedetails[0]->run : "no";
	         if ($run == "no") {?>
	         	<script type="text/javascript">
	         		$('.runs').prop('checked',false);;
	         	</script>
	         	
	         <?php 
	     	}
	     	else
	     	{?>
	         	<script type="text/javascript">
	         		$('.runs').prop('checked',true);;
	         	</script>
	         	
	         <?php 

	     	}
	          $pereq = (strlen($coursedetails[0]->pereq)>0) ? $coursedetails[0]->pereq : "Select Prerequisite Course ...";
     			
	          $semname = $semquery->semname($coursedetails[0]->trm);
	          $prgname = $schprogquery->prgname($coursedetails[0]->prgcode);
	          if (!$prgname) {
	          	$prgname = "Select Program .....";
	          }
	          $yearname = $yearquery->yearname($coursedetails[0]->yr);

         
            ?>
         <!-- Begin Page Content -->
        <div class="container-fluid lecmodal" style="width: 80%">
        

          <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
        <!-- Nested Row within Card Body -->
        <div class="row" >
          <div class="col-lg-12">
            <div class="p-5">
        	<button class="lecclose close" type="button" style="right: 0 !important; margin-top: 11px; background-color: red !important;">
                      <span aria-hidden="true">×</span>
                    </button>
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Update Program Course Details</h1>
              </div>
              <form  method="post" id="addprogcourseForm" action="javascript:void(0)">
                <div class="form-group row">
                <div class="col-sm-8 form-group camp">
                  <label>Course Title:</label>
                  <input type="text" class="form-control form-control-user user-input" value="<?= $crstitle ?>"  placeholder=" Enter Course Title" name="crstitle">
                </div>
                <div class="col-sm-4 form-group" id="">
                  <label>Course Code:</label>
                  <input type="text" class="form-control form-control-user user-input crs" value="<?= $crscode; ?>" disabled="disabled" placeholder=" Enter Course Code" name="crscode">
                </div>
                </div>
                <div class="row">
                <div class="form-group col-lg-6" id="">
                  <label>Semester:</label>
                    <select class="form-control user-input semes"  name="trm">
                    <option value="<?= $trm; ?>">
                      <?= $semname; ?>
                    </option>
                        <?= $semquery->allsemesters();?>
                  </select>
                 </div>
                <div class="form-group col-lg-6 preq">
                  <label>Prerequisite Course:</label>
                    <select class="form-control pre" name="pereq" disabled="">
                      <option value="<?= $pereq; ?>">
                          <?= $pereq; ?>
                        </option>
                         
                  </select>
                 </div>

                </div>
                 <div class="row">
                   <div class="col-sm-6 form-group" id="">
                  <label>Credit Hour:</label>
                  <input type="number" class="form-control form-control-user user-input cred" value="<?= $crdhrs ?>"  placeholder=" Enter Credit Hour" name="crdhrs">
                   </div>
                  <div class="col-sm-6 " id="">
                  <label>Programme:</label>
                  <select class="form-control user-input " name="prgcode">
                    <option value="<?= $coursedetails[0]->prgcode; ?>">
                      <?= $prgname; ?>
                    </option>
                        <?= $schprogquery->allprogrammes();?>
                  </select>
                  </div>
                <div class="form-group col-lg-6">
                  <label>Year Of Study:</label>
                  <select class="form-control user-input " name="yr">
                    <option value="<?= $yr; ?>">
                        <?= $yearname; ?>
                    </option>
                       <?= $yearquery->years();?> 
                  </select>
                 </div>
                 <div class="col-sm-6 form-group" id="">
                  <label class="text-center" >Run:</label>
                  <input type="checkbox" class="form-control form-control-user user-input runs" value="<?= $run; ?>" name="run">
                </div>
                 <input type="number" name="user_session" style="display: none;" value="<?php echo $_SESSION['staff_id']; ?>">
                </div>


                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                <div class="row">
               		 <div class="col-md-6 ">
                     <button id="addprogcourse"  class=" btn btn-primary btn-user btn-block "> Update Course</button>
                    </div>
                    <div class="col-md-6 ">
                     <button id=""  class="lecclose btn btn-danger btn-user btn-block "> Cancel</button>
                    </div>
               	</div>	
              </form>
              <hr>
             
            </div>
          
        </div>
      </div>
    </div>
       
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

<?php   } ?>

         
	<script type="text/javascript">
        		var dir ="http://localhost/Lecturers~Attendance/";
	$('.cred').keyup(function(){
		if ($.trim($(this).val()) > 3)
		{ 
			$('.alert-message').fadeIn(200, function() {
				$(this).css('color', 'red');
				$(this).addClass('alert-danger').html('Credit Hour Cannot Be Greater Than 3');
			});
			setTimeout(function(){
			$('.alert-message').fadeOut(200, function() {
				$('.cred').val('');	
				});
			},2000);
			
		}   
		else if ($.trim($(this).val()) < 0)
		{ 
			$('.alert-message').fadeIn(200, function() {
				$(this).css('color', 'red');
				$(this).addClass('alert-danger').html('Credit Hour Cannot Be Less Than 0');
			});
			setTimeout(function(){
			$('.alert-message').fadeOut(200, function() {
				$('.cred').val('');	
				});
			},2000);
			
		}          
		
	});



 $('.semes').bind('change', function(){
 	
	var semes = $('.semes').val();
		if ($.trim(semes)!='' && semes != 'Sem 1')
		{
			getpre(semes);
		}
		else
		{
			$('.pre').attr('disabled','disabled');
		}
	});

  function getpre(semes)
			 {
			 		$.ajax({
			 			url:''+dir+'Processor/getpre',
			 			type:"POST",
			 			data:{'trm':semes},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				data = $.trim(data);
			 				//console.log(data);
			 				$('.pre').remove();
			 				$('.preq').append(data); 
			 				$('.pre').css('background-color','white');
			 				$('.pre').css('color','#ccc');
			 			}
			 		});
			 }

			

			
        	</script>

