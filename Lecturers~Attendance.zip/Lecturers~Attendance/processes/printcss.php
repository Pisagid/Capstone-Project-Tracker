 <link href="<?php echo PROOT ?>/css/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
   <link href="<?php echo PROOT ?>/css/sb-admin-2.css" rel="stylesheet">
  <style type="text/css">

 	@media print {
 		#print{
 			display: none !important;
 		}	
 	}
 </style>