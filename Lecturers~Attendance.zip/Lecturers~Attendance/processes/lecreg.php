<?php 
extract($_POST);
		$lecturerquery = $this->TbllecturerDataModel;
	if (sizeof($_POST) == 2) {
		$lec_name = $lecturerquery->lectname($username);
		if(isset($_POST['lecdeact'])){
			$lectdeactivate = $lecturerquery->accountdeact($username);
			if($lectdeactivate)
			{
				echo "Account Deactivated Successfully For ".$lec_name;

			}else
			{
				echo "Account Deactivation Failed For ".$lec_name;
			}

		}
		else if (isset($_POST['lecreset'])) 
		{
			$passwordreset = $lecturerquery->passwordreset($username);
		
			if($passwordreset)
			{
				echo "Password Resetted Successfully For ".$lec_name;

			}else
			{
				echo "Password Reset Failed For ".$lec_name;
			}
		}
	}
	else{
		$check = $lecturerquery->lectname($username);
		$Errors = array(
			0 => 'File Already exist',
			1 => 'File Is Not Supported. Only jpg, jpeg, jfif and png files Supported',
			2 => 'File Is More Then 20mb. Please Try Again',
			3 => 'The uploaded file was only partially uploaded',
			4 => 'No file was uploaded',
			6 => 'Missing a temporary folder',
			7 => 'Failed to write file to disk',
			8 => 'A PHP extension stopped the file upload',
			9 => 'Update For '.$check.' Is Successful',
			10 => 'Faculty Member Registered Successfully'
		);

		
		$joined= date('Y-m-d H:m:s'); $user_status = 1;
		if (!empty($_FILES)) {
				$image = $_FILES['image'];
				$allowed = array("jpg", "jpeg", "jfif", "png");

			    $fileName = $image["name"];
			    $fileType = $image["type"];
			    $fileTempName = $image["tmp_name"];
			    $fileError = $image["error"];
			    $fileSize = $image["size"];

			    

			    $fileExt = explode('.', $fileName);
			    $fileActualExt = strtolower(end($fileExt));
			    $fileName = "profile_image";
			    $fileNameChange =  $username.'_'.$fileName;

				    if (in_array($fileActualExt, $allowed)) 
				    {	
				        if ($fileError == 0) 
				        {
				            if ($fileSize < 20000000) 
				            {
				               $fileFullName = $fileNameChange; 

				               $fileDestination = ROOT."/images/uploads/".$fileFullName;
				               if (file_exists($fileDestination)) {
				               		unlink($fileDestination);
				               		
				               }
				               move_uploaded_file($fileTempName, $fileDestination);
				            }
				            else
				            {
				                echo $Errors[2];
				            }
				        }
				        else
				        {
				           echo $Errors[7];
				        }
				    } 
				    else if(in_array($fileActualExt, $allowed) == "")
				    {
				        //$flash_e = "A file must be uploaded";
				    }
				    else
				    {
				        echo "";
				    }
			}

			
			if ($check) {
				$updatequery =  $lecturerquery->updatelecturer($username, $fname, $mname, $lname, $title_id, $rank_id, $website, $appointment_type_id, $phone, $email, $whatsap, $phone2);
				
				if ($updatequery) 
					echo $Errors[9];
				else
					echo 1;
			}
			else{
				$insert = $lecturerquery->registerQuery($username, DAFAULT_QBTTXPSE, $fname, $mname, $lname, $title_id, $rank_id, $website, $appointment_type_id, $joined, $phone, $email, $whatsap, $phone2, $user_status);

				if ($insert) 
					echo $Errors[10];
				else
					echo 2;
			}

	}
 ?>