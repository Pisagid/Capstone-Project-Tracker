<?php 

	$assignlectquery = $this->TbllecturerAssignCoursesModel;
	$lectnamequery = $this->TbllecturerDataModel;
	$sessionquery = $this->SessionsModel;
	$weekendquery = $this->WSessionsModel;
	$daysquery = $this->DaysModel;
	$lhallquery = $this->LHallModel;
	$lecturequery = $this->LecturesModel;
	$updatequery = $this->UpdatedModel;

	$size = sizeof($_POST);
	extract($_POST);

	if (isset($_POST['get']) != '') {
		?>
		<select class="form-control user-input code_check" id="courses" name="course_code">
			<option value="">Select Course Code:....</option>
				<?= $assignlectquery->campuscoursesQuery($campus_id);?>
			</select>
	<?php 
	}
	//to get available sessions for the chosen school
	if ($size == 1 ) {
		if ($campus_id == 1) {
			$sessions = 3;
			?>
			<select name="session_id" class="form-control user-input ses_check myses" id="ses">
				<option value="">Select Session....</option>
					<?= $sessionquery->limitedsessionQuery($sessions);?>
			</select>
	<?php  
		}
		else if ($campus_id == 2) {
			$sessions = 4;
			?>
			<select name="session_id" class="form-control user-input ses_check myses" id="ses">
				<option value="">Select Session....</option>
					<?= $sessionquery->limitedsessionQuery($sessions);?>
			</select>
	<?php  
		}
		else if ($campus_id == 3 || $campus_id == 4) {
			?>	
			<select name="session_id" class="form-control user-input ses_check myses" id="ses">
				<option value="">Select Session....</option>
					<?= $weekendquery->wsesQuery();?>
			</select>
	<?php  
		}
	}

	//to get the assigned lecturer to that chosen course in that campus
	else if ($size == 2 && !isset($_POST['get'])) {
		$lecturerquery = $assignlectquery->assignLectQuery($course_code, $campus_id);
		$lect_id = $lecturerquery;
		
		if ($lect_id > 0) {
			$lectname = $lectnamequery->singleLectQuery($lect_id);
			$init = "init_check";

			?>
			 <input type="text" name="lecturer" value='<?= $lectname ?>' class="form-control user-input <?= $init ?>" readonly>
			 <input type="text" name="lec_id" value='<?= $lect_id ?>' class="form-control user-input <?= $init ?>" style="display: none;" readonly>
			<?php  
		}
		else 
			//for no assigned lecturer
			echo 1;

	}

	// to get available lecturer halls after date is set for the makeup
	else if ($size == 3) {
		if ($campus_id == 1 || $campus_id == 3) {
			$campus =1;
		}
		else if ($campus_id == 2 || $campus_id == 4)
		{
			$campus =2;
		}
		
		//to convert date into day 
		$day = date("l", strtotime($date));
		//day converted to get day id in database
		$day = $daysquery->dayQuery($day);

		//for lecture halls
		$lhall = $lhallquery->lhallQuery($campus);
		//looping to get all lecture halls
		foreach ($lhall as $row) {
			$l_hall = $row->hall_id;
			//getting free lecture halls from the lectures table
			$flhall = $lecturequery->hallQuery($session_id, $day, $l_hall);

			//making sure the lecture is not assigned in the updated table for a makeup lecture
			$fuhall = $updatequery->hallQuery($session_id, $date, $l_hall);

			if (isset($flhall) || isset($fuhall)) {
					if ($l_hall==$flhall || $l_hall==$fuhall) {
												    				 	
					 } 
					else {
						$hall = "hall";	
						echo "<option value=".$l_hall." class=".$hall.">$l_hall</option>";
					}
				}
		}

	}

	
 ?>