    <?php 
            if (isset($_POST['faculty_id'])) {
              extract($_POST);
            $lecturerquery = $this->TbllecturerDataModel; 
            $lecdetails = $lecturerquery->lecdetailsQuery($faculty_id); 
              $fname=  $lecdetails[0]->fname;
              $mname=  $lecdetails[0]->mname;
              $lname= $lecdetails[0]->lname;
              $lec_name = $fname." ".$mname." ".$lname;
              $lec_name = strtolower($lec_name);
              $lec_name = ucwords($lec_name, ' -');
              
              $lecpic = ROOT . DS . 'images'. DS . 'uploads'. DS .$lecdetails[0]->username.'_profile_image';
              $pic_show = PIC_ROOT .$lecdetails[0]->username.'_profile_image';
              $picexist = file_exists($lecpic);
              
              ?>
              
        <div class="row lecmodal" style="margin-top: -50px; display: inline-block; width: 100%;" >
                   <button class="lecclose close" type="button" style="right: 0 !important; margin-top: 11px; background-color: red !important;">
                      <span aria-hidden="true">×</span>
                    </button>
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900  mb-1">Update Faculty Member Details For <?= $lec_name ?></h1>

              </div>
              <hr>
             <form  method="post" id="lecupdateForm" action="javascript:void(0)">
               <div class="row">
                 <div class="col-sm-4 form-check-inline" style="display: inline-block; margin: auto;">
                  <div class="row" style="display: block !important;">
                      <label style="text-align: center;">Upload Image:</label>
                  </div>
                  <div class="row" style="margin:auto;">
                      <img type="file"
                       src="<?=
                        (file_exists($lecpic)) ?
                          $pic_show : PROOT."images/default.png"?>" alt="" id="profile-image">
                  </div>
                  <div class="row" style="display: none;">
                    <input type="file" name="image" onchange="displayImage(this);" id="faculty-image" >
                  </div>
                  </div>
                </div> 
                <div class="form-group row">
                  <div class="col-sm-4 mb-3 mb-sm-0">
                    <label>First Name:</label>
                    <input type="text" class="form-control " value="<?= $fname ?>" placeholder=" Enter First Name" name="fname">
                  </div>
                  <div class="col-sm-4">
                    <label>Middle Name:</label>
                    <input type="text" class="form-control " value="<?= $mname ?>" placeholder="Enter Middle Name" name="mname">
                  </div> 
                  <div class="col-sm-4">
                    <label>Last Name:</label>
                    <input type="text" class="form-control " value="<?= $lname ?>" placeholder="Enter Last Name" name="lname">
                  </div>
                </div>
                <div class="row">
                  
                <div class="col-sm-4 user-name">
                    <label>Faculty ID:</label>
                    <input type="text" name="username" value="<?= $lecdetails[0]->username ?>" placeholder="Enter Faculty ID" disabled="disabled" class="form-control  userChecker" >
                  </div>
                  <div class="col-sm-4 form-group" >
                    <label>Title:</label>
                    <select class="form-control " name="title_id">
                      <?php $title = array('0'=> 'Select Title:','1'=> 'Mr.','2'=> 'Mrs.', '3'=> 'Ms.','4'=> 'Dr.','5'=> 'Associate Professor.','6'=> 'Professor.','7'=> 'Rev.','8'=> 'Lawyer.','9'=> 'Ing.'); ?>
                      <option value="<?= $lecdetails[0]->title_id ?>"><?= $title[$lecdetails[0]->title_id]?></option> 
                      <option value="1">Mr.</option>
                      <option value="2">Mrs.</option>
                      <option value="3">Ms.</option>
                      <option value="4">Dr.</option>
                      <option value="5">Associate Professor.</option>
                      <option value="6">Professor.</option>
                      <option value="7">Rev.</option>
                      <option value="8">Lawyer.</option>
                      <option value="9">Ing.</option>
                    </select>
                  </div>
                  <div class="col-sm-4 form-group" >
                    <label>Appointment Type:</label>
                    <select class="form-control faculty_type" name="appointment_type_id">
                      <?php $appoint = array('0'=> 'Select Appointment Type:','1'=> 'Full Time','2'=> 'Part Time', '3'=> 'Visiting','4'=> 'Adjunct'); ?>
                          <option value="<?= $lecdetails[0]->appointment_type_id ?>"><?= $appoint[$lecdetails[0]->appointment_type_id] ?></option>
                          <option value="1">Full Time</option>
                          <option value="2">Part Time</option>
                          <option value="3">Visiting</option>
                          <option value="4">Adjunct</option>
                    </select>
                  </div>
                </div>
                <div class="row form-group">
                  <div class=" col-sm-8">
                    <div class="row form-group">
                      <div class="col-sm-6 form-group">
                        <label>Rank:</label>
                        <select class="form-control " name="rank_id">
                          <?php $rank = array('0'=> 'Select Rank:','1'=> 'Professor','2'=> 'Associate Professor.', '3'=> 'Senior Lecturer','4'=> 'Assistant Professor.','5'=> 'Lecturer',
                                          '6'=> 'Assistant Lecturer','7'=> 'Academic Teaching Assistant', ); ?>
                          <option value="<?= $lecdetails[0]->rank_id ?>"><?= $rank[$lecdetails[0]->rank_id]?></option>
                          <option value="1">Professor</option>
                          <option value="2">Associate Professor</option>
                          <option value="3">Senior Lecturer</option>
                          <option value="4">Assistant Professor</option>
                          <option value="5">Lecturer</option>
                          <option value="6">Assistant Lecturer</option>
                          <option value="7">Academic Teaching Assistant</option>
                        </select>
                      </div>
                      <div class="col-sm-6 form-group">
                        <label>Personal Website:</label>
                        <input type="text" name="website" value="<?= $lecdetails[0]->website ?>" placeholder="Enter Personal Website" class="form-control">
                      </div> 
                      <div class="col-sm-6 form-group">
                        <label>Email Address:</label>
                        <input type="email" name="email" value="<?= $lecdetails[0]->email ?>" placeholder="Enter Email Address" class="form-control">
                      </div> 
                       <div class="col-sm-6 form-group">
                        <label>Whatsapp Contact:</label>
                        <input type="number" name="whatsap" value="<?= $lecdetails[0]->whatsap ?>" placeholder="Enter Whatsapp Number" class="form-control">
                      </div>
                      <div class="col-sm-6 form-group">
                        <label>Phone 1:</label>
                        <input type="number" name="phone" value="<?= $lecdetails[0]->phone ?>" placeholder="Enter Phone Number" class="form-control">
                      </div>
                       <div class="col-sm-6 form-group">
                        <label>Phone 2:</label>
                        <input type="number" name="phone2" value="<?= $lecdetails[0]->phone2 ?>" placeholder="Enter Phone Number" class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-4 ">
                    <div class="row">
                      <div class="col-sm-6" style="display: inline-block; margin: auto;">
                      <label style="text-align: center;">FingerPrint Scan:</label>
                      <div class="row" style="display: inline-flex !important;">
                          <img type="file" class="col-xl-10" src="<?php echo PROOT ?>images/fingerdefault.png" alt="" id="">
                          <button class="bg-success">Capture Finger</button>  
                      </div>
                    </div>
                    </div>

                </div>

                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                
              </form>

            </div>
            <hr>
               <div class="form-group row">
                   <div class="col-sm-8" style="display: inline-flex;">
                    <div class="col-md-3">
                    <button id="lecupdate"  class="btn btn-success btn-user btn-block"> Update Lecturer</button>
                    </div>
                    <div class="col-md-3 ">
                    <button id="" data-toggle="modal" data-target="#lecrestpassword" class="btn btn-secondary btn-user btn-block "> Reset Password</button>
                    </div>
                  </div> 
                  <div class="col-sm-4" style="display: inline-flex;">
                    <div class="col-md-6">
                      <button id="deactivate_btn" data-toggle="modal" data-target="#lecdeactivate" class="btn btn-primary btn-user btn-block "> Deactivate Lecturer</button>
                    </div>
                    <div class="col-md-6 ">
                     <button id=""  class="lecclose btn btn-danger btn-user btn-block "> Cancel</button>
                    </div>
                  </div> 
                 
                </div>
        </div>
      </div>
            <?php 
            }
           ?>