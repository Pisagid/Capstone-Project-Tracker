<?php 

	$prgcoursequery = $this->TblprogcoursesModel;
	$prgcoursequery->allcourseJSON();
	
 ?>