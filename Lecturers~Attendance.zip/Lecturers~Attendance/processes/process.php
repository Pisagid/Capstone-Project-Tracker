<?php 
		
	if ($_POST) 
		{
			$validation = true;
			if ($validation === true) 
				{
					$user = $this->UsersModel->findByUsername($_POST['username']);
					
					if ($user && password_verify(Input::get('password'), $user->password)) 
					{

						$remember = (isset($_POST['remember_me']) && Input::get('remember_me')) ? true : false;
						$user->login($remember);
						//Router::redirect('dashboard');
						$_SESSION['acl'] = ($user->staff_type == 1) ? "Administrator" : "User";
						$_SESSION['staff_type'] = $user->staff_type;
						$_SESSION['staff_id'] = $user->id;
						$_SESSION['fullname'] = $user->fullname;
						$_SESSION['username'] = $user->username;
						//$_SESSION['campus'] = $user->campus;

						$arr = explode(' ',trim($user->fullname));
						$_SESSION['user'] =  $arr[0];
						//dnd($_SESSION);
						echo 1;
					}
					else
					{
						echo 0;
					}
				}
			}

  