<?php 	

	extract($_POST);
	/**/
	$end_date = date('Y-m-d', strtotime('+1 year', strtotime($start_date)));
	?>
 	<input type="date" name="end_date" data-name='end_date' id="username" placeholder="" class="form-control form-control-user  dateCheck" disabled="disabled" value="<?php echo $end_date; ?>">
			<?php
 ?>