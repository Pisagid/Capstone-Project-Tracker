<?php 
	$assignlectquery = $this->TbllecturerAssignCoursesModel;
	extract($_POST);
	foreach ($course_code as $course ) {

		$checkexist = $assignlectquery->coursecheck($course, $campus);

		if ($checkexist) {
				$update = $assignlectquery->updateassignquery($course, $lecturer_id, $campus);
				
				if($update)
					echo 'Updated';
			 } 
			else
			{
			 	$insert = $assignlectquery->insertassignQuery($course, $lecturer_id, $campus);
				
			 	if($insert)
					echo 'Inserted';
		 	}
	}

 ?>