<?php 
	
	$lecturequery = $this->LecturesModel;
	$updatedquery = $this->UpdatedModel;
	$sessionquery = $this->SessionsModel;
	$wsessionquery = $this->WSessionsModel;
	$lecturerquery = $this->TbllecturerDataModel;
	$lhallquery = $this->LHallModel;
	$campusquery = $this->SCampusModel;
	$attendancequery = $this->AttendanceModel;


	//this function is used to get the current week number in the month
 
	//this if checking is to check whether whether we are in the normal week days or weekends since we have different sessions
	if (day < 6) {
		$sesquery = $sessionquery->currentsessionQuery();
	}
	else
	{
		$sesquery = $wsessionquery->currentsessionQuery();
	}

	//to get all courses in the attendance table that is not signed out.
	$coursequery = $attendancequery->lecturesJSON($sesquery);

	  $data = array();

	 if ($coursequery) {
	 	
	 	  foreach ($coursequery as $row ) 
	        {
	           	$course_code = $row->course_code;
	            $course_code = strtoupper($row->course_code);
	            $coursedetails = $lecturequery->coursedetails($row->course_code, $row->campus);
	          //  dnd($coursedetails);
	            //getting lecturer's name
	            $lec_name = $lecturerquery->singleLectQuery($coursedetails[0]->lecturer_id);
	            $floor_level = $lhallquery->halllevelQuery($coursedetails[0]->hall_id);
	            $campus_name = $campusquery->campusQuery($coursedetails[0]->campus_id);
	            if (!isset($row->end_time)) {
	            	$data[] = array(
						'<a href="#" data-toggle="model" class="dropdown-item course_signout" data-value="course_signout" school-value="'.$coursedetails[0]->campus_id.'" value="'.$course_code.'">'.$course_code.'</a>',
						$lec_name,
						$campus_name,
						$row->start_time,
						$coursedetails[0]->hall_id,
						$floor_level,
					); 
				}
	        }
	 }


	 $output = array(
				'aaData'=> $data,
			);

			 echo json_encode($output);	

 ?>