<?php 
	
	$lecturequery = $this->LecturesModel;
	$updatedquery = $this->UpdatedModel;
	$sessionquery = $this->SessionsModel;
	$wsessionquery = $this->WSessionsModel;
	$lecturerquery = $this->TbllecturerDataModel;
	$lhallquery = $this->LHallModel;
	$campusquery = $this->SCampusModel;
	$attendancequery = $this->AttendanceModel;



	//this if checking is to check whether whether we are in the normal week days or weekends since we have different sessions
	if (day < 6) {
		$sesquery = $sessionquery->currentsessionQuery();
	}
	else
	{
		$sesquery = $wsessionquery->currentsessionQuery();
	}

	//to get all courses scheduled for this day.
	$coursequery = $lecturequery->lecturesJSON($sesquery);
	//to get all updated courses scheduled for this day.
	$makeupcoursequery = $updatedquery->updatedJSON($sesquery);

	  $data = array();

	  // if there are normal course schedule for that day 
	 if ($makeupcoursequery) {
	 	foreach ($makeupcoursequery as $row ) 
	        {
	           	$course_code = $row->ucourse_code;
	            $course_code = strtoupper($row->ucourse_code);
	            //getting lecturer's name

	            $courseattended = $attendancequery->verifycourse($course_code, $sesquery, date, $row->ucampus_id);

	            if (!$courseattended) {
	            	$lec_name = $lecturerquery->singleLectQuery($row->ulecturer_id);
	            $floor_level = $lhallquery->halllevelQuery($row->uhall_id);
	            $campus_name = $campusquery->campusQuery($row->ucampus_id);
	           
	        		 $data[] = array(
						'<a href="#" data-toggle="model" class="dropdown-item course_signin" data-value="course_signin" school-value="'.$row->ucampus_id.'" value="'.$course_code.'">'.$course_code.'</a>',
						$lec_name,
						$campus_name,
						$row->uhall_id,
						$floor_level,
					);
	            }
	            else
	            {

	            }
	            
	        }


	 }

	 if ($coursequery) {

	 	  foreach ($coursequery as $row ) 
	        {
	           	$course_code = $row->course_code;
	            $course_code = strtoupper($row->course_code);
	            //getting lecturer's name
	            $lec_name = $lecturerquery->singleLectQuery($row->lecturer_id);
	            $floor_level = $lhallquery->halllevelQuery($row->hall_id);
	            $campus_name = $campusquery->campusQuery($row->campus_id);

	             $courseattended = $attendancequery->verifycourse($course_code, $sesquery, date, $row->campus_id);
	             
	            if (!$courseattended) {
	            	$data[] = array(
						'<a href="#" data-toggle="model" class="dropdown-item course_signin" data-value="course_signin" school-value="'.$row->campus_id.'" value="'.$course_code.'">'.$course_code.'</a>',
						$lec_name,
						$campus_name,
						$row->hall_id,
						$floor_level,
					); 
				}
	        }
	 }


	 $output = array(
				'aaData'=> $data,
			);

			 echo json_encode($output);	

 ?>