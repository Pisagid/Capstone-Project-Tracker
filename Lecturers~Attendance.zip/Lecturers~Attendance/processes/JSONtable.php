<?php 

	$lecturerquery = $this->TbllecturerDataModel;
	$lecturerquery->allLectJSON();		

?>