<?php 
	
	define('DEBUG', true);
	

		error_reporting(E_ALL); // Error engine

	ini_set('display_errors', TRUE); // Error display

	ini_set('log_errors', TRUE); // Error logging

	ini_set('error_log', 'errors.log'); // Logging file

	ini_set('log_errors_max_len', 3000024); // Logging file size


	
	if (!isset($_SESSION)) {
		
		define('DEFAULT_CONTROLLER', 'dashboard');
	}
	else
	{
		define('DEFAULT_CONTROLLER', 'login');
	}


	//define('RESTRICTED', 'Login');
	define('DEFAULT_LAYOUT', 'default');

	define('PROOT', '/Lecturers~Attendance/');
	define('PRO_ROOT', '/Lecturers~Attendance/processes/');
	define('PIC_ROOT', '/Lecturers~Attendance/images/uploads/');
	

	define('SITE_TITLE', 'Lecturers ~ Attendance');
	

	date_default_timezone_set("Africa/Accra");
	define('date', date('Y-m-d'));
	define('day', date("N", strtotime(date)));
	define('time', date("H:i:s"));
	define('month', date('m'));
	define('year', date('Y'));
   
	

 
	$online_status = true;

	if($online_status == false)
	{
		define("db_user","root");
		define("db_pass","2398");
		define("db_host","127.0.0.1");
		define("db_name","myait_chatify");
	
	}
	else
	{
		DEFINE("db_user","root");
		DEFINE("db_pass","2398");
		DEFINE("db_host","192.168.0.3");
		DEFINE("db_name","myait_chatify");
		/*DEFINE("db_user","lemsas");
		DEFINE("db_pass","iCkyR=T9XF#z");
		DEFINE("db_host","lemsas.net");
		DEFINE("db_name","lemsas_aitcourseware");*/	
		// DEFINE("db_name","myait_aitcourseware");
	}


	define('CURRENT_USER_SESSION_NAME', 'JmnwfzpvFmJabCFuiQPLV');
	define('DAFAULT_QBTTXPSE', 'faculty');
	define('REMEMBER_ME_COOKIE_NAME', 'QPLVFmJabCFuiJmnwfzpv');
	define('REMEMBER_ME_COOKIE_EXPIRY', '604800');
	

 ?>