<?php 

	/**
	 * 
	 */
	class Register extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->load_model('Users');
			$this->load_model('SCampus');
			$this->load_model('Staff');
			$this->load_model('Registry');
			$this->view->setLayout('default');
		}

		public function indexAction()
		{
			$this->view->render('register/index');
		}

		public function registerAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'reguser.php');
		}

		public function getuserAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'getuser.php');
		}
	}

 ?>