<?php 
	
	/**
	 * 
	 */
	class Processor extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->load_model('Users');
			$this->load_model('Staff');
			$this->load_model('SCampus');
			$this->load_model('Sessions');
			$this->load_model('TbllecturerAssignCourses');
			$this->load_model('Tblprogcourses');
			$this->load_model('TbllecturerData');
			$this->load_model('WSessions');
			$this->load_model('Semesters');
			$this->load_model('Tblprgms');
			$this->load_model('Days');
			$this->load_model('Weeks');
			$this->load_model('Years');
			$this->load_model('LHall');
			$this->load_model('Updated');
			$this->load_model('Lectures');
			$this->load_model('Attendance');
			$this->load_model('Registry');

		}
		public function indexAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'submitforms.php');
		}
		
		public function lecregAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'lecreg.php');
		}

		public function jsonAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'JSONtable.php');
		}

		public function jsoncourseAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'jsoncourse.php');
		}

		public function lecupdateAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'lecupdate.php');
		}

		public function lecassignAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'lecassign.php');
		}
		public function lecassigningAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'lecassigning.php');
		}

		public function getuserAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'getuser.php');
		}

		public function getpreAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'getpre.php');
		}

		public function signingsAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'signings.php');
		}

		public function courseAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'course.php');
		}

		public function coursedetailsAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'coursedetails.php');
		}

		public function addprogcourseAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'courses.php');
		}
		
	
	}
	

 ?>