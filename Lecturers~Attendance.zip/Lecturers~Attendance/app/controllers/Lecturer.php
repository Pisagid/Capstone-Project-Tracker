<?php 

	/**
	 * 
	 */
	class Lecturer extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->load_model('Users');
			$this->load_model('SCampus');
			$this->load_model('Staff');
			$this->load_model('Registry');
			$this->load_model('Lectures');
			$this->view->setLayout('default');
		}

		public function indexAction()
		{
			$this->view->render('lecturer/index');
		}
		
		public function assignAction()
		{
			$this->view->render('lecturer/assign');
		}	

		public function updateAction()
		{
			$this->view->render('lecturer/update');
		}

		public function registerAction()
		{
			$this->view->render('lecturer/register');
		}

		
	
	}

 ?>