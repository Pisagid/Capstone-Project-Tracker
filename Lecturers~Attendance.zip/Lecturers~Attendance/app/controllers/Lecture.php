<?php 

	/**
	 * 
	 */
	class Lecture extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->load_model('Users');
			$this->load_model('SCampus');
			$this->load_model('Staff');
			$this->load_model('Registry');
			$this->load_model('Lectures');
			$this->view->setLayout('default');
		}

		public function indexAction()
		{
			$this->view->render('lecture/index');
		}

		public function addAction()
		{
			$this->view->render('lecture/add');
		}

		public function addcourseAction()
		{
			$this->view->render('lecture/addcourse');
		}
	
	}

 ?>