<?php 
	
	/**
	 * 
	 */
	class Login extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->load_model('Users');
			$this->view->setLayout('authenticator');

		}
		public function indexAction()
		{	
			$this->view->render('login/index');
		}

		public function loginAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'process.php');
		}
		
		public function changepasswordAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'changepassword.php');
		}

		public function logoutAction()
		{
			
			if(currentUser()) 
			{
				currentUser()->logout();
				
			}
			
		}

	}
	

 ?>