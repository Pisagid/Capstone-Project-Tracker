<?php 

	/**
	 * 
	 */
	class Dashboard extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->view->setLayout('default_dashboard');
			
		}

		public function indexAction()
		{
			$this->view->render('dashboard/index');
		}
	}

 ?>