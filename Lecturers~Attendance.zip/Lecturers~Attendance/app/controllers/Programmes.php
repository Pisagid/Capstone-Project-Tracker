<?php 

	/**
	 * 
	 */
	class Programmes extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->load_model('Users');
			$this->load_model('SCampus');
			$this->load_model('Staff');
			$this->load_model('Registry');
			$this->load_model('Tblprgms');
			$this->load_model('Tblprogcourses');
			$this->view->setLayout('default');
		}

		public function indexAction()
		{
			$this->view->render('programmes/index');
		}

		public function viewcoursesAction()
		{
			$this->view->render('programmes/viewprogcourses');
		}
		

		
		
	
	}

 ?>