<?php 

	/**
	 * 
	 */
	class Signatures extends Controller
	{
		
		public function __construct($controller, $action)
		{
			parent::__construct($controller, $action);
			$this->load_model('SCampus');
			$this->load_model('Sessions');
			$this->load_model('TbllecturerData');
			$this->load_model('WSessions');
			$this->load_model('LHall');
			$this->load_model('Lectures');
			$this->load_model('Attendance');
			$this->load_model('Updated');
			$this->view->setLayout('default');
		}

			
		public function jsonAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'JSONlectures.php');
		}

		public function jsonoutAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'Jsonlectout.php');
		}

		public function indexAction()
		{
			$this->view->render('signatures/signin');
		}
		
		public function signinAction()
		{
			$this->view->render('signatures/signin');
		}	

		public function signoutAction()
		{
			$this->view->render('signatures/signout');
		}

		

		
	
	}

 ?>