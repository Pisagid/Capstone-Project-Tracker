<?php 
	
	/**
	 * 
	 */
	class Makeup extends Controller
	{
		public function __construct($controller, $action)
		{
		
			parent::__construct($controller, $action);
			$this->load_model('Users');
			$this->load_model('SCampus');
			$this->load_model('Sessions');
			$this->load_model('TbllecturerAssignCourses');
			$this->load_model('TbllecturerData');
			$this->load_model('WSessions');
			$this->load_model('Days');
			$this->load_model('LHall');
			$this->load_model('Updated');
			$this->load_model('Lectures');
			$this->view->setLayout('default');
		}

		public function indexAction()
		{
			$this->view->render('makeup/index');
		}

		public function makeupdetailsAction()
		{
			require_once(ROOT . DS . 'processes' . DS . 'makeupdetails.php');
		}

	}


 ?>