<?= $this->setSiteTitle('ATTENDANCE | LECTURER');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
        <?php
           
            $this->load_model('TbllecturerData'); $allcourses = $this->TbllecturerDataModel;
            ?>
         <!-- Begin Page Content -->
           <style type="text/css">
  .box
  {
    display: inline-flex; 
    width: 30%;
    margin-left: 30% !important;
    background-color: red;
    }

  .search
  {
    float: right !important;
    display: inline-block;
    border: none;
      border-bottom: 1px solid;
      border-radius: 5px;

  }
  .searchfield, .searchIcon
  {
    display: inline-block;
  }
  .searchfield
  { 
    width: 92%;
  }

  .searchIcon
  {
    width: 5%;
  }
  .searchbar
  {
      padding-left: 10px;
      height: 40px;
      border: none;
  }
  .searchbar:focus, .searchbar:active, .searchfield:focus, .searchfield:active, .searchIcon:focus, .searchIcon:active, 
  {
    border: none !important;
    border-color: white !important;    
  }
  .lecturesviewcontent
{
  margin-top: 1%;
  opacity: 1;
  height: auto;
  max-height: 600px;
  position: relative;
  margin-bottom: 10px; 
  overflow: auto;
  background-color: transparent;
  display: inline-block;
  border-bottom: none;
  overflow-x: hidden;
  width: 100%;
}
th
{
  border-right: solid white;
  margin-left: 5% !important;
}

 </style>
        <div class="container-fluid" style="width: 80%">

          <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
         
        <!-- Nested Row within Card Body -->
        <div class="row" >
          <div class="col-lg-12">
            <div class="p-5" >
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">View Attendance For Faculty Members</h1>
              </div>
              <hr>
              <form  method="post" id="attendanceForm" action="javascript:void(0)" >
                <div class="row">
                 <div class="col-sm-4 user-name" style="display: none;">
                  </div>
                  <div class="col-sm-4 form-group" >
                    <label>Month:</label>
                    <select class="form-control user-input" name="month" >
                      <option value=""> Select Month:</option>
                       <?php $month = array('1'=>"January",'2'=>"February",'3'=>"March",'4'=>"April",'5'=>"May",'6'=>"June",'7'=>"July",'8'=>"August",'9'=>"September",'10'=>"October",'11'=>"November",'12'=>"December");
                      for ($i=1; $i <= 12; $i++) 
                      { 
                        
                        echo "<option value='$i'>$month[$i]</option>";
                      }
                       ?>
                    </select>
                  </div>
                  <div class="col-sm-4 form-group" >
                    <label>Year:</label>
                    <select class="form-control user-input" name="year">
                      <option value=""> Select Year:</option>
                          <?php
                      
                         for($i = date("Y"); $i <= date("Y"); $i--){
                            $n_i = $i+1;
                             echo "<option value='$i'>$i/$n_i</option>";
                             if ($i == 2007) {
                              break;
                             }
                          }
                      ?>
                    </select>
                  </div>
                </div> 
                <div class="row form-group" style="display: inline-block;">
                  <div class="search r0">
                    <div class="searchIcon">
                      <span ><i class="fas fa-search"style="width: 5px !important;"></i></span>
                    </div>
                    <div class="searchfield">
                      <input type="search" class="searchbar" name="" id="lecsearch" onkeyup="searchFuntion()" placeholder="Search for Course: ....">
                    </div>
                    
                  </div>
                  <div class="col-sm-12  form-group lecturesviewcontent" id="attendance_table" style="max-height: 200px;">
                    <table id="lecturers" name="lecturers"   style="width: 100% !important;">
                         <thead >
                            <tr class="bg-secondary" style="color: white; height: 40px">
                             <th style="width: 10% ;" scope="col"><input class="checkbox s_checkbox " type="checkbox" name="" value="">Select Lecturer</th>
                              <th style="width: 5800px" scope="col">Lectures Name</th>
                              <th style="width: 20%;" scope="col">Faculty ID</th>
                            </tr>
                          </thead>
                        <?= $allcourses->lectAttendanceQuery()?>
                     </table>
                  </div>
                </div>

                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                <button id="attendance"  class="btn btn-primary btn-user btn-block">View Attendance</button>
                
               
              </form>
              <hr>
             
            </div>
            <div class="p-5 viewcontent" style="display: none;">
            
                
          </div>
        </div>
      </div>
    </div>
       
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <script type="text/javascript">
                    function searchFuntion() {
                      // Declare variables
                      var input, filter, table, tr, td, i, txtValue , nxtvalue;
                      input = document.getElementById("lecsearch");
                      filter = input.value.toUpperCase();
                      table = document.getElementById("lecturers");
                      tr = table.getElementsByTagName("tr");

                      // Loop through all table rows, and hide those who don't match the search query
                      for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[1];
                        td1 = tr[i].getElementsByTagName("td")[2]
                        if (td) {
                          txtValue = td.textContent || td.innerText;
                          nxtvalue = td1.textContent || td1.innerText;
                          if (txtValue.toUpperCase().indexOf(filter) > -1 || nxtvalue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                          } else {
                            tr[i].style.display = "none";
                          }
                        }
                      }
                    }

                   
                    </script>
<?= $this->end(); ?>


