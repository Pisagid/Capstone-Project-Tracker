<?= $this->setSiteTitle('Lecturers | Time Table');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
          <?php $this->load_model('SCampus'); $campusquery = $this->SCampusModel; ?>
          <?php $this->load_model('Days'); $dayquery = $this->DaysModel; ?>
          <?php $this->load_model('Sessions'); $sesquery = $this->SessionsModel; ?>
          <?php $this->load_model('WSessions'); $wsesquery = $this->WSessionsModel; ?>
          <?php $this->load_model('Lectures'); $lecquery = $this->LecturesModel; ?>
          <?php $this->load_model('Updated'); $updatedquery = $this->UpdatedModel; ?>
          <?php $this->load_model('TbllecturerData'); $lecturerquery = $this->TbllecturerDataModel; ?>
        
         <!-- Begin Page Content -->
    <div class="container-fluid" style="width: 80%">

      <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
        <!-- Nested Row within Card Body -->
        <div class="row" >
        
          <div class="col-lg-12 bg-gray-300" >
            <div class="p-3 bg-gray-100">
              <div class=" text-center">
                <h1 class="h1  text-gray-900 mb-4">Lecture Periods For <?= Date('Y') ?></h1>
              </div>
            </div>
            <div class="row" >
             <?php 
                // this is to get all campuses
                $allcampusquery = $campusquery->allQuery();

                foreach ($allcampusquery as $row) {
                  $campusname = $row->campus; $c_id = $row->id;
                     if ($c_id==1 || $c_id == 2) {
                      $dayid = array('1' => 1,'2' => 2,'3' =>3, '4' => 4,'5' =>5);
                    }
                    else if($c_id==3 || $c_id == 4) {
                        $dayid = array('1' => 6,'2' => 7);
                      }
                  ?>
                   <!-- Collapsable Card  -->
                <div class="card p-2 shadow  col-lg-12">
                  <!-- Card Header - Accordion -->
                  <a href="#collapse<?= $c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="">
                    <h6 class="m-2 font-weight-bold text-primary"><?= $campusname ?></h6>
                  </a>

                  <!-- Card Content - Collapse -->
                 <div class="collapse " id="collapse<?= $c_id ?>">
                    <div class="card-body bg-gray-900">
                     <?php 
                     if ($c_id == 1) 
                       {  // for campus 1
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 
                           $dayname = $dayquery->daynameQuery($i);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              <?php require(ROOT . DS . 'processes' . DS . 'printcss.php'); ?>
                              <div class="card-body">
                                <!-- getting lectures assigned for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center"><?= $campusname ?> Lecture Periods For <?=$dayname ?></h6>
                                <div class="row ">
                                  <?php 
                                    date_default_timezone_set("Africa/Accra");
                                     $date = date("Y/m/d");
                                      
                                      for ($p=1; $p < 4; $p++) 
                                      { 
                                        $sessions = $sesquery->sessionQuery($p);
                                        //to get lectures for the period
                                        $lectures = $lecquery->lecturesQuery($p, $i, $c_id);
                                        // to get lectures from makeup 
                                        $uplectures = $updatedquery->lecturesQuery($p,$i,$c_id, $date);

                                        ?>
                                        <dl class="col-lg-4 ">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd >
                                            <?php 

                                              foreach ($lectures as $row) { 
                                                $course = $row->course_code; $hall = $row->hall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->lecturer_id);
                                                if ($row->session_id == $p) {$lec = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-500 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for lectures table

                                              foreach ($uplectures as $row) { 
                                                $course = $row->ucourse_code; $hall = $row->uhall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->ulecturer_id);
                                                if ($row->usession_id == $p) {$up = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-400 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for makeup table



                                             ?>
                                          </dd>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                                    <hr>
                                 <?php 
                                    if (($up>0 || $lec>0) && $_SESSION['acl'] == "Administrator") {?>
                                     <button href="#" value="<?= $dayname.$c_id ?>" class="btn btn-primary btn-user btn-block " id="print" style="">
                                      Print
                                   </button>
                                    <?php }
                                  ?>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of first if 


                     else if ($c_id == 2) 
                       {  // for campus 2
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 

                           $dayname = $dayquery->daynameQuery($i);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              <?php require(ROOT . DS . 'processes' . DS . 'printcss.php'); ?>
                              <div class="card-body">
                                <!-- getting lectures assigned for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center"><?= $campusname ?> Lecture Periods For <?=$dayname ?></h6>
                                <div class="row ">
                                  <?php 
                                    date_default_timezone_set("Africa/Accra");
                                     $date = date("Y/m/d");
                                      
                                      for ($p=4; $p < 6; $p++) 
                                      { 
                                        $sessions = $sesquery->sessionQuery($p);
                                        //to get lectures for the period
                                        $lectures = $lecquery->lecturesQuery($p, $i, $c_id);
                                        // to get lectures from makeup 
                                        $uplectures = $updatedquery->lecturesQuery($p,$i,$c_id, $date);

                                        ?>
                                        <dl class="col-lg-6">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd >
                                            <?php 

                                              foreach ($lectures as $row) { 
                                                $course = $row->course_code; $hall = $row->hall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->lecturer_id);
                                                if ($row->session_id == $p) {$lec = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for lectures table

                                              foreach ($uplectures as $row) { 
                                                $course = $row->ucourse_code; $hall = $row->uhall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->ulecturer_id);
                                                if ($row->usession_id == $p) {$up = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for makeup table



                                             ?>
                                          </dd>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                                    <hr>
                                 <?php 
                                    if ($up>0 || $lec>0) {?>
                                     <button href="#" value="<?= $dayname.$c_id ?>" class="btn btn-primary btn-user btn-block " id="print" >
                                      Print
                                   </button>
                                    <?php }
                                  ?>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of second campus if

                     else if ($c_id == 3) 
                       {  // for campus 3
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 

                           $dayname = $dayquery->daynameQuery($dayid[$i]);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              <?php require(ROOT . DS . 'processes' . DS . 'printcss.php'); ?>
                              <div class="card-body">
                                <!-- getting lectures assigned for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center"><?= $campusname ?> Lecture Periods For <?=$dayname ?></h6>
                                <div class="row ">
                                  <?php 
                                    date_default_timezone_set("Africa/Accra");
                                     $date = date("Y/m/d");
                                      
                                      for ($p=1; $p <= 4; $p++) 
                                      { 
                                        $sessions = $wsesquery->allwsesQuery($p);
                                        //to get lectures for the period
                                        $lectures = $lecquery->lecturesQuery($p, $dayid[$i], $c_id);
                                        // to get lectures from makeup 
                                        $uplectures = $updatedquery->lecturesQuery($p,$dayid[$i],$c_id, $date);

                                        ?>
                                        <dl class="col-lg-3">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd >
                                            <?php 

                                              foreach ($lectures as $row) { 
                                                $course = $row->course_code; $hall = $row->hall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->lecturer_id);
                                                if ($row->session_id == $p) {$lec = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for lectures table

                                              foreach ($uplectures as $row) { 
                                                $course = $row->ucourse_code; $hall = $row->uhall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->ulecturer_id);
                                                if ($row->usession_id == $p) {$up = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for makeup table
                                             ?>
                                          </dd>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                                    <hr>
                                 <?php 
                                    if ($up>0 || $lec>0) {?>
                                     <button href="#" value="<?= $dayname.$c_id ?>" class="btn btn-primary btn-user btn-block " id="print" >
                                      Print
                                   </button>
                                    <?php }
                                  ?>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of third campus if


                     else if ($c_id == 4) 
                       {  // for campus 4
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 

                           $dayname = $dayquery->daynameQuery($dayid[$i]);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              <?php require(ROOT . DS . 'processes' . DS . 'printcss.php'); ?>
                              <div class="card-body">
                                <!-- getting lectures assigned for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center"><?= $campusname ?> Lecture Periods For <?=$dayname ?></h6>
                                <div class="row ">
                                  <?php 
                                    date_default_timezone_set("Africa/Accra");
                                     $date = date("Y/m/d");
                                      
                                      for ($p=1; $p <= 4; $p++) 
                                      { 
                                        $sessions = $wsesquery->allwsesQuery($p);
                                        //to get lectures for the period
                                        $lectures = $lecquery->lecturesQuery($p, $dayid[$i], $c_id);
                                        // to get lectures from makeup 
                                        $uplectures = $updatedquery->lecturesQuery($p,$dayid[$i],$c_id, $date);

                                        ?>
                                        <dl class="col-lg-3">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd >
                                            <?php 

                                              foreach ($lectures as $row) { 
                                                $course = $row->course_code; $hall = $row->hall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->lecturer_id);
                                                if ($row->session_id == $p) {$lec = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for lectures table

                                              foreach ($uplectures as $row) { 
                                                $course = $row->ucourse_code; $hall = $row->uhall_id; 
                                                $lect_init = $lecturerquery->lecinitQuery($row->ulecturer_id);
                                                if ($row->usession_id == $p) {$up = 1;?>
                                                  <div class="row m-1 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="<?= $course. ' ['.$lect_init.'] ' ?>" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="<?= $hall ?>" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 
                                                }
                                                else
                                                { ?>
                                                  <div class="row m-2 p-1 bg-gray-100 shadow ">
                                                     <div class="col-lg-12 ">
                                                      <input type="text" class="font-weight-bold form-control text-center border-bottom-none" value="" readonly>  
                                                      <input type="text" class="font-weight-bold form-control text-center" value="" readonly> 
                                                    </div> 
                                                  </div>
                                                  <?php 

                                                }
                                                //end of if no course
                                              } 
                                              // end of loop for makeup table
                                             ?>
                                          </dd>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                                    <hr>
                                 <?php 
                                    if ($up>0 || $lec>0) {?>
                                     <button href="#" value="<?= $dayname.$c_id ?>" class="btn btn-primary btn-user btn-block " id="print">
                                      Print
                                   </button>
                                    <?php }
                                  ?>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of fourth campus if
                    ?>
                    </div>
                  </div>

                  <!-- end of campus accordion div -->
                </div>
                <?php 
                //end of foreach for all schools
                }
               ?>

            </div>
          </div>
        </div>
      </div>
      </div>
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

<?= $this->end(); ?>


