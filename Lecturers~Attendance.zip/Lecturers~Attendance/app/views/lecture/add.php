<?= $this->setSiteTitle('Lectures | Time Table');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
          <?php $this->load_model('SCampus'); $campusquery = $this->SCampusModel; ?>
          <?php $this->load_model('Days'); $dayquery = $this->DaysModel; ?>
          <?php $this->load_model('Sessions'); $sesquery = $this->SessionsModel; ?>
          <?php $this->load_model('WSessions'); $wsesquery = $this->WSessionsModel; ?>
          <?php $this->load_model('LHall'); $lhallquery = $this->LHallModel; ?>
        
         <!-- Begin Page Content -->
    <div class="container-fluid" style="width: 80%">

      <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
        <!-- Nested Row within Card Body -->
        <div class="row" >
        
          <div class="col-lg-12 bg-gray-300" >
            <div class="p-3 bg-gray-100">
              <div class=" text-center">
                <h1 class="h1  text-gray-900 mb-4">Schedule Lecture Periods For <?= Date('Y') ?></h1>
              </div>
            </div>
            <div class="row" >
             <?php 
                // this is to get all campuses
                $allcampusquery = $campusquery->allQuery();

                foreach ($allcampusquery as $row) {
                  $campusname = $row->campus; $c_id = $row->id;
                     if ($c_id==1 || $c_id == 2) {
                      $dayid = array('1' => 1,'2' => 2,'3' =>3, '4' => 4,'5' =>5);
                    }
                    else if($c_id==3 || $c_id == 4) {
                        $dayid = array('1' => 6,'2' => 7);
                      }
                  ?>
                   <!-- Collapsable Card  -->
                <div class="card p-2 shadow  col-lg-12">
                  <!-- Card Header - Accordion -->
                  <a href="#collapse<?= $c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="">
                    <h6 class="m-2 font-weight-bold text-primary"><?= $campusname ?></h6>
                  </a>

                  <!-- Card Content - Collapse -->
                 <div class="collapse " id="collapse<?= $c_id ?>">
                    <div class="card-body bg-gray-900">
                     <?php 
                     if ($c_id == 1) 
                       {  // for campus 1
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 
                           $dayname = $dayquery->daynameQuery($i);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              
                              <div class="card-body">
                                <!-- getting lectures Scheduleed for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center"> Schedule <?=$dayname ?> Lecture Periods For <?= $campusname ?></h6>
                                <div class="row ">
                                  <?php 
                                 
                                      for ($p=1; $p < 4; $p++) 
                                      { 
                                        $sessions = $sesquery->sessionQuery($p);
                                        //to get lectures for the period
                                    

                                        ?>
                                        <dl class="col-lg-4">
                                        <form method="POST" id="<?= $p.$dayname.$c_id ?>Form"  action="javascript:void(0)">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd >
                                                  <div class="row m-1 p-1 bg-gray-00 shadow ">
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$p?>" name="session_id"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$i?>" name="day"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$_SESSION['staff_id']?>" name="user_session"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="" name="course_code" placeholder="Course Code:"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <select class="form-control form-control-user <?= $p.$dayname.$c_id ?>-user-input "  name="l_hall">
                                                        <option value="">
                                                          Select Lecture Hall:
                                                        </option>
                                                        <?= $lhallquery->hallQuery($c_id) ?>
                                                      </select>
                                                      </div>

                                                    <div class="form-group col-lg-12 " style="display: none"> 
                                                      <input type="text" class="font-weight-bold form-control text-center" name="campus" value="<?= $c_id ?>" readonly> 
                                                    </div>
                                                    <hr>
                                                    <div class="<?= $p.$dayname.$c_id ?>-alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                                                    <hr> 
                                                  </div>
                                                  
                                          </dd>
                                          <hr>
                                          <button id="<?= $p.$dayname.$c_id ?>" class="add_btn btn btn-primary btn-user btn-block col-lg-5 " value="add" style="margin:auto">Insert</button>
                                        </form>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of first if 


                     else if ($c_id == 2) 
                       {  // for campus 2
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 

                           $dayname = $dayquery->daynameQuery($i);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              
                              <div class="card-body">
                                <!-- getting lectures Scheduleed for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center">Schedule <?=$dayname ?> Lecture Periods For <?= $campusname ?></h6>
                                <div class="row ">
                                  <?php 
                                 
                                      for ($p=4; $p < 6; $p++) 
                                      { 
                                        $sessions = $sesquery->sessionQuery($p);
                                        //to get lectures for the period
                                    

                                        ?>
                                        <dl class="col-lg-6">
                                        <form method="POST" id="<?= $p.$dayname.$c_id ?>Form"  action="javascript:void(0)">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd > 
                                                   <div class="row m-1 p-1 bg-gray-00 shadow ">
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$p?>" name="session_id"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$i?>" name="day"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$_SESSION['staff_id']?>" name="user_session"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="" name="course_code" placeholder="Course Code:"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <select class="form-control form-control-user <?= $p.$dayname.$c_id ?>-user-input "  name="l_hall">
                                                        <option value="">
                                                          Select Lecture Hall:
                                                        </option>
                                                       <?= $lhallquery->hallQuery($c_id) ?>
                                                          </select>   
                                                      </div>
                                                    <div class="form-group col-lg-12 " style="display: none">  
                                                      <input type="text" class="font-weight-bold form-control text-center" name="campus" value="<?= $c_id ?>" readonly> 
                                                    </div>
                                                    <hr>
                                                    <div class="<?= $p.$dayname.$c_id ?>-alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                                                    <hr> 
                                                  </div>
                                            </dd>
                                          <hr>
                                          <button id="<?= $p.$dayname.$c_id ?>" class="add_btn btn btn-primary btn-user btn-block col-lg-5 " value="add" style="margin:auto">Insert</button>
                                        </form>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of second campus if

                     else if ($c_id == 3) 
                       {  // for campus 3
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 

                           $dayname = $dayquery->daynameQuery($dayid[$i]);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              
                              <div class="card-body">
                                <!-- getting lectures Scheduleed for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center">Schedule <?=$dayname ?> Lecture Periods For <?= $campusname ?></h6>
                                <div class="row ">
                                  <?php 
                                      for ($p=1; $p <= 4; $p++) 
                                      { 
                                        $sessions = $wsesquery->allwsesQuery($p);

                                        ?>
                                        <dl class="col-lg-3">
                                        <form method="POST" id="<?= $p.$dayname.$c_id ?>Form"  action="javascript:void(0)">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd >
                                                <div class="row m-1 p-1 bg-gray-00 shadow ">
                                                     <div class="form-group col-lg-12 " style="display:none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$p?>" name="session_id"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display:none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$i?>" name="day"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display:none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$_SESSION['staff_id']?>" name="user_session"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="" name="course_code" placeholder="Course Code:"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <select class="form-control form-control-user <?= $p.$dayname.$c_id ?>-user-input "  name="l_hall">
                                                        <option value="">
                                                          Select Lecture Hall:
                                                        </option>
                                                        <?= $lhallquery->hallQuery(1) ?>
                                                        
                                                      </select>
                                                      </div>

                                                    <div class="form-group col-lg-12 "style="display: none;">
                                                      <input type="text" class="font-weight-bold form-control text-center" name="campus" value="<?= $c_id ?>" readonly> 
                                                    </div>
                                                    <hr>
                                                    <div class="<?= $p.$dayname.$c_id ?>-alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                                                    <hr> 
                                                  </div>
                                          </dd>
                                          <hr>
                                          <button id="<?= $p.$dayname.$c_id ?>" class="add_btn btn btn-primary btn-user btn-block col-lg-5 " value="add" style="margin:auto">Insert</button>
                                        </form>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of third campus if


                     else if ($c_id == 4) 
                       {  // for campus 4
                         for ($i=1; $i <= sizeof($dayid) ; $i++) { 

                           $dayname = $dayquery->daynameQuery($dayid[$i]);
                           $lec =0; $up= 0;
                              ?>
                                <!-- Collapsable Card Example -->
                          <div class="card shadow mb-1">
                            <!-- Card Header - Accordion -->
                            <a href="#<?= $dayname.$c_id ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="<?= $dayname ?>">
                              <h6 class="m-0 font-weight-bold text-secondary"><?= $dayname ?></h6>
                            </a>
                            <!-- Card Content - Collapse -->
                            <div class="collapse " id="<?= $dayname.$c_id ?>">
                              
                              <div class="card-body">
                                <!-- getting lectures Scheduleed for the day -->
                                  <h6 class="mb-2 font-weight-bold text-primary text-center">Schedule <?=$dayname ?> Lecture Periods For <?= $campusname ?></h6>
                                <div class="row ">
                                  <?php 
                                 
                                      for ($p=1; $p <= 4; $p++) 
                                      { 
                                        $sessions = $wsesquery->allwsesQuery($p);
                                        //to get lectures for the period
                                        
                                        ?>
                                        <dl class="col-lg-3">
                                        <form method="POST" id="<?= $p.$dayname.$c_id ?>Form"  action="javascript:void(0)">
                                          <dt class="m-2 shadow border-bottom-secondary text-center bg-gray-900">
                                            <?= $sessions[0]->ses_name ?>
                                            <br>
                                            <?= $sessions[0]->start_time . " - " . $sessions[0]->end_time?>
                                          </dt>
                                          <dd >
                                                 <div class="row m-1 p-1 bg-gray-00 shadow ">
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$p?>" name="session_id"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$i?>" name="day"> 
                                                      </div>
                                                     <div class="form-group col-lg-12 " style="display: none">
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="<?=$_SESSION['staff_id']?>" name="user_session"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <input type="text" class="font-weight-bold <?= $p.$dayname.$c_id ?>-form-control" value="" name="course_code" placeholder="Course Code:"> 
                                                      </div>
                                                      <div class="form-group col-lg-12 " >
                                                        <select class="form-control form-control-user <?= $p.$dayname.$c_id ?>-user-input"  name="l_hall">
                                                        <option value="">
                                                          Select Lecture Hall:
                                                        </option>
                                                        <?= $lhallquery->hallQuery(2) ?>
                                                      </select>
                                                      </div>

                                                    <div class="form-group col-lg-12 " style="display: none">  
                                                      <input type="text" class="font-weight-bold form-control text-center" name="campus" value="<?= $c_id ?>" readonly> 
                                                    </div>
                                                    <hr>
                                                    <div class="<?= $p.$dayname.$c_id ?>-alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                                                    <hr> 
                                                  </div>
                                          </dd>
                                          <hr>
                                          <button id="<?= $p.$dayname.$c_id ?>" class="add_btn btn btn-primary btn-user btn-block col-lg-5 " value="add" style="margin:auto">Insert</button>
                                        </form>
                                        </dl>
                                    <?php 
                                    //end of session loop
                                      }
                                   ?>
                                </div>
                                <!-- end of getting lectures -->
                              </div>
                            </div> 
                         </div>
                        <?php 
                               }
                              //end of for loop
                        }
                            // end of fourth campus if
                    ?>
                    </div>
                  </div>

                  <!-- end of campus accordion div -->
                </div>
                <?php 
                //end of foreach for all schools
                }
               ?>

            </div>
          </div>
        </div>
      </div>
      </div>
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

<?= $this->end(); ?>


