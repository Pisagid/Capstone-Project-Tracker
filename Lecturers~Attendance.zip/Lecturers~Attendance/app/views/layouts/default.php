<?php require 'header.php'; ?>

  <?= $this->content('body');?>

<?php require 'footer.php'; ?>


