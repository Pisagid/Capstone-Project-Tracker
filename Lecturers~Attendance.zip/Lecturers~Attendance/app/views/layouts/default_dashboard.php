<?php require 'header.php'; ?>

  <?= $this->content('body');?>

<?php require 'footer.php'; ?>

<script src="<?php echo PROOT ?>/js/Chart.js"></script>
 <script src="<?php echo PROOT ?>/js/chart-pie.js"></script>
