<!DOCTYPE html>
<html>
<head>
  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?= $this->siteTitle();  ?></title>

  
  <!--Custom fonts for this template--> 
  <link href="<?php echo PROOT ?>/css/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Custom styles for this template -->

 <!--   <link href="<?php ?>/css/icons.css" rel="stylesheet">  -->
<link href="<?php echo PROOT ?>css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo PROOT ?>/css/fixedColumns.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo PROOT ?>/css/buttons.dataTables.min.css" rel="stylesheet">

  <link href="<?php echo PROOT ?>css/dataTables.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo PROOT ?>/css/fixedColumns.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo PROOT ?>/css/buttons.dataTables.min.css" rel="stylesheet">
  <link href="<?php echo PROOT ?>/css/select2.min.css" rel="stylesheet">

  <link href="<?php echo PROOT ?>/css/sb-admin-2.css" rel="stylesheet">
  
</head>

<style type="text/css">
  .model{
    z-index: 5000 !important;
  }
</style>

<body id="page-top">
  <div class="" id="cover">
      <div id="myProgress" style="display: none;"></div>  
      <div id="myBar" style="display: none;"></div>
  </div>

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php require 'sidebar.php'; ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" id="search" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" onkeyup="searchFunction()">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

         

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $_SESSION['username']; ?></span>
                <input type="" style="display: none;" class="cur_user" name="" value="">
               <i class=" mr-2 text-gray-400 fas fa-user"></i>
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item"  data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
                <a class="dropdown-item"  data-toggle="modal" data-target="#changepassword">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Change Password
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
<!-- end of header -->