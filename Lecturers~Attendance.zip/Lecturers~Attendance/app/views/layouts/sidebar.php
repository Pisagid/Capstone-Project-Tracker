<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar" >

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo PROOT ?>dashboard">
        <div class="sidebar-brand-icon ">
       <img src="<?php echo PROOT ?>images/ait_logo.png " style="height: 100%; width: 100%">

        </div>
        <div class="sidebar-brand-text mx-1">Lectures ~ Management</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">


     <?php $menu = Router::getMenu('sidebar'); 

        if (isset($menu['Dashboard'])) {?>
           <!-- Nav Item - Dashboard -->
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo PROOT ?>dashboard">
              <i class="fas fa-university"></i>
              <span>Dashboard</span></a>
          </li>

          <!-- Divider -->
          <hr class="sidebar-divider">
        <?php }

         if (isset($menu['Lecture'])) {?>
           <!-- Nav Item -lectures  -->
            <li class="nav-item">
              <a class="nav-link" href="<?php echo PROOT ?>lecture">
               <i class="fas fa-calendar"></i>
                <span>Lectures</span></a>
            </li>
       <?php }

            if (isset($menu['Lecturers Management'])) {?>
            <!-- Nav Item - lecturers pages  -->
              <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#lecturer" aria-expanded="true" aria-controls="lecturer">
                  <i class="fas fa-fw fa-folder"></i>
                  <span>Lecturers Management</span>
                </a>
                <div id="lecturer" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                  <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Lecturer Assignment</h6>
                    <a class="collapse-item" href="<?php echo PROOT ?>lecturer">Lecturer Details</a>
                    <a class="collapse-item" href="<?php echo PROOT ?>lecturer/register">Register Lecturer</a>
                    <a class="collapse-item" href="<?php echo PROOT ?>lecturer/assign">Assign Courses</a>
                  
                  </div>
                </div>
              </li>
        <?php }


        if (isset($menu['Lectures Management'])) {?>
             <!-- Nav Item - lectures pages  -->
          <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#lecture" aria-expanded="true" aria-controls="lecture">
              <i class="fas fa-fw fa-folder"></i>
              <span>Lectures Management</span>
            </a>
            <div id="lecture" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
              <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Lecture Periods Assignment</h6>
                <a class="collapse-item" href="<?php echo PROOT ?>lecture/add">Schedule Lecture</a>
                <a class="collapse-item" href="<?php echo PROOT ?>makeup">MakeUp Lecture</a>
              </div>
            </div>
          </li>

        <?php }

        if (isset($menu['Programmes Management'])) {?>
             <!-- Nav Item - lectures pages  -->
          <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#programme" aria-expanded="true" aria-controls="programme">
              <i class="fas fa-fw fa-folder"></i>
              <span>Programmes</span>
            </a>
            <div id="programme" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
              <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Programme Courses</h6>
                <a class="collapse-item" href="<?php echo PROOT ?>programmes/">Add Course</a>
                <a class="collapse-item" href="<?php echo PROOT ?>programmes/viewcourses">View Courses</a>
              </div>
            </div>
          </li>

        <?php }

           if (isset($menu['Attandance'])) {?>
             <!-- Nav Item - Attendance Tables -->
            <li class="nav-item">
              <a class="nav-link" href="<?php echo PROOT ?>Attandance/">
                <i class="fas fa-fw fa-graduation-cap"></i>
                <span>Attendance</span></a>
            </li>
            <?php }


           if (isset($menu['Register'])) {?>
               <!-- Nav Item - Registration Portal -->
              <li class="nav-item">
                <a class="nav-link" href="<?php echo PROOT ?>register">
                  <i class="fas fa-fw fa-user-plus"></i>
                  <span>Register User</span></a>
              </li>
            <?php }

              if (isset($menu['Lecturers Attendance'])) {?>
               <!-- Nav Item - Registration Portal -->
               <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#signings" aria-expanded="true" aria-controls="lecture">
              <i class="fas fa-fw fa-folder"></i>
              <span>Mark Attendance</span>
            </a>
            <div id="signings" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
              <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Lecturer Mark Attendance</h6>
                <a class="collapse-item" href="<?php echo PROOT ?>signatures/signin">SignIn Lecturer</a>
                <a class="collapse-item" href="<?php echo PROOT ?>signatures/signout">SignOut Lecturer</a>
              </div>
            </div>
          </li>

            <?php }
    ?>
           

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
