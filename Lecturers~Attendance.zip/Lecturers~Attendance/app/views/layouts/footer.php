<!-- starting of footer -->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.
          <form id="signoutform" class="signoutform" method="POST" action="javascript:void(0)">
             <input type="number" name="signout" value="0" style="display: none;">
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <button class="btn btn-primary user_out" >Logout</button>
        </div>
      </div>
    </div>
  </div>
   <!-- Lecturer Reset passord Modal-->
  <div class="modal fade" id="lecrestpassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Reset Password ?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Reset" below if you are ready to reset password for this Lecturer..
          <form id="lecresetForm" class="lecresetForm" method="POST" action="javascript:void(0)">
             <input type="text" name="resetpassord" value="" style="display: none;">
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <button class="btn btn-primary " id="lecreset" >Reset</button>
        </div>
      </div>
    </div>
  </div>
   <!-- Lecturer account  Deactivation Modal-->
  <div class="modal fade" id="lecdeactivate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Deactivate Lecturer's Account ?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Deactivate" below if you are ready to deactivate lecturer's account..
          <form id="lecdeactForm" class="lecdeactForm" method="POST" action="javascript:void(0)">
             <input type="text" name="user_status" value="" style="display: none;">
          </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <button class="btn btn-primary " id="lecdeact">Deactivate</button>
        </div>
      </div>
    </div>
  </div>
  <!-- change password model -->
  <div class="modal fade" id="changepassword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="margin-top: 10%;">
      <div class="modal-content">
        <div class="modal-header">
          <h2 class="modal-title" style="text-align: center !important;">Change Password</h2>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
           <form id="changeForm" method="POST" action="javascript:void(0)">
              <div class="form-group" style="display: none;">
                <label >Username</label>
                <input type="text" id="username" class="form-control form-control-user-change" name="username" value="<?php echo $_SESSION['username']; ?>" placeholder="Enter Username">
              </div>
              <div class="form-group">
              <label >Old Password</label>
              <input type="password"   id="opassword" class="form-control form-control-user-change" name="opassword" placeholder="Enter Old Password" autocomplete="off">
            </div>
            <div class="form-group">
              <label >New Password</label>
              <input type="password"  id="ipassword" class="form-control form-control-user-change" name="ipassword" placeholder="Enter New Password" autocomplete="off">
            </div>
            <div class="form-group">
              <label >Confirm Password</label>
              <input type="password" id="fpassword" class="form-control form-control-user-change" name="fpassword" placeholder="Confirm Password" autocomplete="off">
            </div>
            <div class="alert-message-change" id="message" style="display: none; margin-top: 5px;"></div>
           </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="cancel-password" type="button" data-dismiss="modal">Cancel</button>
          <button  class="btn btn-primary" id="change-password">Change</button>
        </div>
      </div>
    </div>
  </div>


 <!-- Bootstrap core JavaScript-->
  <script src="<?php echo PROOT ?>/js/jquery.min.js"></script>
  <script src="<?php echo PROOT ?>/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo PROOT ?>/js/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo PROOT ?>/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  
  <script src="<?php echo PROOT ?>/js/Chart.min.js"></script> 

<script src="<?php echo PROOT ?>/js/bootstrap.min.js"></script>                                                           
  <script src="<?php echo PROOT ?>/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo PROOT ?>/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo PROOT ?>/js/dataTables.fixedColumns.min.js"></script>
    <script src="<?php echo PROOT ?>/js/dataTables.responsive.js"></script>
    <script src="<?php echo PROOT ?>/js/dataTables.rowsGroup.js"></script>
    <script src="<?php echo PROOT ?>/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo PROOT ?>/js/buttons.html5.min.js"></script>
    <script src="<?php echo PROOT ?>/js/buttons.print.min.js"></script>
    <script src="<?php echo PROOT ?>/js/select2.min.js"></script>

   <script src="<?php echo PROOT ?>/js/custom.js?var=<?php echo time(); ?>"></script>


</body>

</html>
