<?= $this->setSiteTitle('Programmes | Add Course');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
        <?php
           $this->load_model('TbllecturerAssignCourses'); $assignedcoursesquery = $this->TbllecturerAssignCoursesModel;
            $this->load_model('Semesters'); $semquery = $this->SemestersModel;
            $this->load_model('Years'); $yearquery = $this->YearsModel;
              $this->load_model('Tblprgms'); $schprogquery = $this->TblprgmsModel;
            ?>
         <!-- Begin Page Content -->
        <div class="container-fluid" style="width: 80%">

          <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
        <!-- Nested Row within Card Body -->
        <div class="row" >
        
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Add Program Course</h1>
              </div>
              <form  method="post" id="addprogcourseForm" action="javascript:void(0)">
                <div class="form-group row">
                <div class="col-sm-8 form-group camp">
                  <label>Course Title:</label>
                  <input type="text" class="form-control form-control-user user-input"  placeholder=" Enter Course Title" name="crstitle">
                </div>
                <div class="col-sm-4 form-group" id="">
                  <label>Course Code:</label>
                  <input type="text" class="form-control form-control-user user-input"  placeholder=" Enter Course Code" name="crscode">
                </div>
                </div>
                <div class="row">
                <div class="form-group col-lg-6" id="">
                  <label>Semester:</label>
                    <select class="form-control user-input semes" name="trm">
                    <option value="">
                      Select Semester:
                    </option>
                        <?= $semquery->allsemesters();?>
                  </select>
                 </div>
                <div class="form-group col-lg-6 preq">
                  <label>Prerequisite Course:</label>
                    <select class="form-control pre" name="pereq" disabled="disabled">
                      <option value="">
                          Select Course: ....
                        </option>
                         
                  </select>
                 </div>

                </div>
                 <div class="row">
                   <div class="col-sm-6 form-group" id="">
                  <label>Credit Hour:</label>
                  <input type="number" class="form-control form-control-user user-input cred"  placeholder=" Enter Credit Hour" name="crdhrs">
                   </div>
                  <div class="col-sm-6 " id="">
                  <label>Programme:</label>
                  <select class="form-control user-input " name="prgcode">
                    <option value="">
                      Select Programme Name:
                    </option>
                        <?= $schprogquery->allprogrammes();?>
                  </select>
                  </div>
                <div class="form-group col-lg-6">
                  <label>Year Of Study:</label>
                  <select class="form-control user-input " name="yr">
                    <option value="">
                      Select Year:
                    </option>
                        <?= $yearquery->years();?>
                  </select>
                 </div>
                 <div class="col-sm-6 form-group" id="">
                  <label class="text-center" >Run:</label>
                  <input type="checkbox" class="form-control form-control-user user-input runs"  placeholder=" Enter Credit Hour"  name="run">
                </div>
                 <input type="number" name="user_session" style="display: none;" value="<?php echo $_SESSION['staff_id']; ?>">
                </div>


                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                <button id="addprogcourse" class="btn btn-primary btn-user btn-block">Add Course</button>
                
               
              </form>
              <hr>
             
            </div>
          
        </div>
      </div>
    </div>
       
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

         


<?= $this->end(); ?>