<?= $this->setSiteTitle('SignIn | Lecturer Attendance ');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->

          <div class="card shadow mb-4" style="margin-top: 5px;">
 
            <div class="card-body updatelec">
              <div class="table-responsive lechide" style="width: 100%;">
                <div id="dataTable_wrapper" class="dataTables_wrapper">
           
                  <div class="row" style="margin-top: 1%;" id="table">
                    <?php require(ROOT . DS . 'processes' . DS . 'printcss.php'); ?>

                     <h6 class="m-0 font-weight-bold text-primary" style="margin-bottom: 1% !important;">List Of Ongoing Lectures For <?php echo date("D-M-Y").', '. date('H:i:s'); ?> </h6>
                </div>
                <style type="text/css">
                    div.table-responsive>div.dataTables_wrapper>div.row {
                       margin: 0;
                      }
                      .col-sm-3, .col-sm-4, .col-sm-8, .col-sm-12 {
                      min-height: 1px;
                      padding-left: 15px;
                      margin:0;
                    }
                    label{
                      display: inline-flex !important;
                    }
                    table {
                        border-spacing: 0;
                        display: block; 

                    }
                    td{
                       padding: 4px !important;
                    }
                                </style>
                <div class="row" style="width: 100% !important;" >
                 <table class="table table-bordered col-lg-12" id="dailycourse" style="text-align: left !important;">
                   <thead>
                    <tr >
                      <!-- basic information -->
                        <th width="250px">Course Code</th>
                        <th width="450px">Lecturer Name</th>
                        <th width="250px">School Name</th>
                        <th width="200px">Hall ID</th>
                        <th width="200px">Hall Location</th>
                    </tr>
                   </thead>
                </table>
                </div>
               </div>
            </div>

            <hr>
          </div>

          <!-- to display selected lectuerer details -->
      <script type="text/javascript">
          var dir ="http://localhost/Lecturers~Attendance/";
             document.addEventListener("DOMContentLoaded",function(){
                              getLecturers();
                          },false);
                         
                          function getLecturers(){
                               $('#dailycourse').dataTable({
                                  'bProcessing': true,
                                  'sAjaxSource': ''+dir+'/Signatures/json',
                                  'sAjaxDataProp': "data",
                                  'lengthMenu': [[15,50,100,200,500,-1],[15,50,100,200,500,'ALL']],
                                  'destroy': true,
                                  "order": [[4 , "asc" ]],
                              })
                          }

                    function searchFunction() {
                      // Declare variables
                      var input, filter, table, tr, td, i, txtValue , nxtvalue;
                      input = document.getElementById("search");
                      filter = input.value.toUpperCase();
                      table = document.getElementById("dailycourse");
                      tr = table.getElementsByTagName("tr");

                      // Loop through all table rows, and hide those who don't match the search query
                      for (i = 0; i < tr.length; i++) 
                      {

                        td = tr[i].getElementsByTagName("td")[0];
                        td1 = tr[i].getElementsByTagName("td")[1];
                        td2 = tr[i].getElementsByTagName("td")[2];
                        td3 = tr[i].getElementsByTagName("td")[3];
                        td4 = tr[i].getElementsByTagName("td")[4];

                        if (td)
                        {
                              nameValue = td.textContent || td.innerText;
                              idvalue = td1.textContent || td1.innerText;
                              supValue = td2.textContent || td2.innerText;
                              assValue = td3.textContent || td3.innerText;
                              endValue = td4.textContent || td4.innerText;

                          if (
                                nameValue.toUpperCase().indexOf(filter) > -1 || 
                                idvalue.toUpperCase().indexOf(filter) > -1 || 
                                supValue.toUpperCase().indexOf(filter) > -1 || 
                                assValue.toUpperCase().indexOf(filter) > -1 || 
                                endValue.toUpperCase().indexOf(filter) > -1) 
                              {
                                tr[i].style.display = "";
                              } 
                              else
                               {
                                tr[i].style.display = "none";
                              }
                        }

                      }
                    }

                   
              </script>

<?= $this->end(); ?>
