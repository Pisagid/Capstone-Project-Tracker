<?= $this->setSiteTitle('Lectures | Dashboard');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->

          <?php 
            $this->load_model('Lectures');$lecturesquery = $this->LecturesModel; 
            $this->load_model('Sessions');$sessionquery = $this->SessionsModel; 
            $this->load_model('WSessions');$wsessionquery = $this->WSessionsModel; 
            $this->load_model('Attendance');$attendancequery = $this->AttendanceModel;
            $this->load_model('SCampus');$campusquery = $this->SCampusModel; 
          
            $sesquery = (day < 6) ? $sessionquery->currentsessionQuery() : $wsessionquery->currentsessionQuery();
                   
             ?>
          <div class="row">

             <!-- Expired Projects -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                     <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Expired Lectures for <?= date('D M Y') ?></div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        <?php 
                          $alllectures = $lecturesquery->lectures();
                          $expired = $lecturesquery->count();
                          $attended = 0;
                          foreach ($alllectures as $row) {
                            $course_code = $row->course_code;
                            $checkpresent = $attendancequery->checkpresent($course_code);
                            if ($checkpresent > 0) 
                            {
                              $expired--; $attended++;
                            }
                          }
                           echo $expired.' Expired '.$word = ($expired>1) ? 'Lectures' : 'Lecture';
                         ?>
                        
                      </div>
                    </div>
                   
                  </div>
                </div>
              </div>
            </div>

        

            <!-- Pending Projects -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                       <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Scheduled Lectures for <?= date('D M Y') ?></div>
                           
                      <div class="h5 mb-0 font-weight-bold text-gray-800"> 
                          <?= $lecturesquery->leccount().' ' .$word = ($lecturesquery->leccount()>1) ? 'Lectures Scheduled' : 'Lecture Scheduled'?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa--sign fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

               <!-- Pending Projects -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total On-Going Lectures for <?= date('D M Y').' '. time ?></div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                          <?= ($lecturesquery->seslectcount($sesquery)>1) ? $lecturesquery->seslectcount($sesquery).' Scheduled Lectures For Period '. $sesquery : 'No Lectures On-Going' ?>
                          </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa--sign fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

        
                <!-- total captones -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Attended Lectures for <?= date('D M Y')?></div> 
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                       <?= $attended .' Lectures Attended' ?>
                    </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-book-reader fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

           
          </div>

          <!-- Content Row -->

          <div class="row">

            <!-- Area Chart -->
            <?php $campuses= $campusquery->allcampus(); ?>
               <style type="text/css" media="screen">
                     .school{display: none !important}
                   </style>

                   
            
                <?php 


                  foreach ($campuses  as $row) {
                    
                    $campus_id = $row->id; if($campus_id==5)break;
                    $all_count = $lecturesquery->lectcount($campus_id);
                    $period = 1;
                    if ($row->id  == 1) {
                      $periods = 3;
                    }
                    else if ($row->id  == 2) {
                      $periods = 2;$period = 4;
                    }
                    else if ($row->id  == 3 || 4) {
                      $periods = 4;$period = 1; 
                    }
                 
                    ?>
                     <?php if ($campus_id<3): ?>
                      <style type="text/css">                      
                      .wschool{display: none !important;}
                      .regschool{display: block !important}
                    </style>
                    <?php endif ?>
                    <?php if ($campus_id>3 && day>5): ?>
                      <style type="text/css">
                      .wschool{display: block !important;}
                      .regschool{display: none !important}
                    </style>
                    <?php endif ?>
                     <!-- Card Header - Dropdown -->
                     <div class="col-xl-6 col-lg-7">
              <div class="card shadow mb-1">
                <div class=" school <?= ($campus_id<3) ? 'regschool' : 'wschool' ?> card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-grey"><?= $row->campus ?> Assigned Lectures For Various Periods As At <?php echo date('D-M-Y'); ?></h6>

                </div>
                <!-- Card Body -->
                <div class="school <?= ($campus_id<3) ? 'regschool' : 'wschool' ?> card-body">
                  <div class="chart-area" style="height: auto">

                 <?php  
                     $color = array('1' => 'primary' , '2' => 'warning' , '3' => 'success', '4' => 'secondary');
                    $progress = array('1' => 'bg-primary' , '2' => 'bg-warning' , '3' => 'bg-success', '4' => 'bg-secondary');
                     $capval = array('' => '');
                      for ($i=1; $i <= $periods; $i++) { 
                        $ans = 0; $new = 0;
                          $lectures= $lecturesquery->lecturescount($period, day, $campus_id);
                           $sessions = (day<6) ? $sessionquery->sessionQuery($period) : $wsessionquery->allwsesQuery($period);
                           if ($lectures > 0 && $all_count > 0) {
                                     
                                   $ans = ($lectures/$all_count)*100;
                                 }
                                
                                 $new = round($ans);
                           ?>

                           <h6 class="m-0 font-weight-bold text-<?= $color[$i] ?>" ><?= $lectures; echo ($lectures>1) ? " LECTURES" : " LECTURE"; echo ' FOR ' .$sessions[0]->ses_name; ?> <span class="float-right"><?php echo $new."%"; ?></span></h6>
                             <div style="margin-bottom: 2%; margin-top: 2%; " class="row no-gutters align-items-center shadow h-10">
                                <div class="col " >
                                  <div class="progress progress-sm mr-2 ">
                                    <div class="progress-bar <?php echo $progress[$i]; ?>" role="progressbar" style="width: <?php echo $ans."%"; ?>" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                  </div>
                                </div>
                              </div>
                          <?php 
                           
                           $period++;
                      }
                     ?>

                  </div>
                     <h6 class="m-2 font-weight-bold text-secondary " style="text-align: right;" ><?= $all_count; echo ($all_count>1) ? " LECTURES" : " LECTURE"; echo " FOR  $row->campus"; ?></h6>
                </div>
              </div>
            </div>

                <?php
                  }

                 ?>
               

         
          </div>

       





<?= $this->end(); ?>