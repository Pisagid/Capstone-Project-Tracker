<?= $this->setSiteTitle('REGISTER | USER');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
        <?php
           $this->load_model('Staff');$staffquery = $this->StaffModel;
            $this->load_model('SCampus'); $campusquery = $this->SCampusModel;
            ?>
         <!-- Begin Page Content -->
        <div class="container-fluid" style="width: 60%">

          <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
        <!-- Nested Row within Card Body -->
        <div class="row" >
        
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
              </div>
              <form  method="post" id="reguserForm" action="javascript:void(0)">
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label>First Name:</label>
                    <input type="text" class="form-control form-control-user user-input"  placeholder=" Enter First Name" name="fname">
                  </div>
                  <div class="col-sm-6">
                    <label>Last Name:</label>
                    <input type="text" class="form-control form-control-user user-input"  placeholder="Enter Last Name" name="lname">
                  </div>
                </div>
                <div class="row">
                <div class="form-group col-lg-6">
                  <label>UserType:</label>
                    <select class="form-control user-input staff_type" name="staff_type">
                      <option value="">
                          User Type:....
                        </option>
                         <?= $staffquery->allstaffQuery(); ?>
                  </select>
                 </div>
                <div class="col-sm-6 form-group" >
                  <label>Campus:</label>
                  <select class="form-control user-input campus" name="campus_name">
                    <option value="">
                      Select Campus:
                    </option>
                        <?= $campusquery->allcampusQuery();?>
                  </select>
                </div>

                 <div class="col-sm-6 user-name">
                    <label>Username:</label>
                    <input type="text" name="username" data-name='Username'  placeholder="Username" class="form-control  user-input userChecker" disabled="disabled">
                  
                  </div>
                </div>


                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                <button id="reguser"  class="btn btn-primary btn-user btn-block"> Register User</button>
                
               
              </form>
              <hr>
             
            </div>
          
        </div>
      </div>
    </div>
       
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

         


<?= $this->end(); ?>


