<?= $this->setSiteTitle('REGISTER | LECTURER');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
        <?php
           $this->load_model('Staff');$staffquery = $this->StaffModel;
            $this->load_model('SCampus'); $campusquery = $this->SCampusModel;
            $this->load_model('Faculty'); $facultyquery = $this->FacultyModel;
            ?>
         <!-- Begin Page Content -->
        <div class="container-fluid" style="width: 80%">

          <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
         
        <!-- Nested Row within Card Body -->
        <div class="row" >
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Create A New Faculty Member</h1>
              </div>
              <hr>
              <form  method="post" id="lecregForm" action="javascript:void(0)" enctype="multipart/form-data">
                <div class="row">
                 <div class="col-sm-4 form-check-inline" style="display: inline-block; margin: auto;">
                  <div class="row" style="display: block !important;">
                      <label style="text-align: center;">Upload Image:</label>
                  </div>
                  <div class="row" style="margin:auto;">
                      <img type="file" src="<?php echo PROOT ?>images/default.png" alt="" id="profile-image">
                  </div>
                  <div class="row" style="display: none;">
                    <input type="file" name="image" onchange="displayImage(this);" id="faculty-image" >
                  </div>
                  </div>
                </div> 
                <div class="form-group row">
                  <div class="col-sm-4 mb-3 mb-sm-0">
                    <label>First Name:</label>
                    <input type="text" class="form-control form-control-user user-input"  placeholder=" Enter First Name" name="fname">
                  </div>
                  <div class="col-sm-4">
                    <label>Middle Name:</label>
                    <input type="text" class="form-control "  placeholder="Enter Middle Name" name="mname">
                  </div> 
                  <div class="col-sm-4">
                    <label>Last Name:</label>
                    <input type="text" class="form-control form-control-user user-input"  placeholder="Enter Last Name" name="lname">
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-4 form-group" >
                    <label>School:</label>
                    <select class="form-control faculty_type" name="sch_name">
                      <option value=""> Select School:</option>
                          <?= $facultyquery->allfacultyQuery();?>
                    </select>
                  </div>
                <div class="col-sm-4 user-name">
                    <label>Faculty ID:</label>
                    <input type="text" name="username" placeholder="Enter Faculty ID" class="form-control  user-input userChecker" value="">
                  </div>
                  <div class="col-sm-4 form-group" >
                    <label>Title:</label>
                    <select class="form-control user-input" name="title_id">
                      <option value="">Select Title:</option> 
                      <option value="1">Mr.</option>
                      <option value="2">Mrs.</option>
                      <option value="3">Ms.</option>
                      <option value="4">Dr.</option>
                      <option value="5">Associate Professor.</option>
                      <option value="6.">Professor.</option>
                      <option value="7">Rev.</option>
                      <option value="8">Lawyer.</option>
                      <option value="9">Ing.</option>
                    </select>
                  </div>
                </div>
                <div class="row form-group">
                  <div class=" col-sm-8">
                    <div class="row form-group">
                      <div class="col-sm-6 form-group">
                        <label>Rank:</label>
                        <select class="form-control user-input" name="rank_id">
                          <option value="">Select Rank:</option>
                          <option value="1">Professor</option>
                          <option value="2">Associate Professor</option>
                          <option value="3">Senior Lecturer</option>
                          <option value="4">Assistant Professor</option>
                          <option value="5">Lecturer</option>
                          <option value="6">Assistant Lecturer</option>
                          <option value="7">Academic Teaching Assistant</option>
                        </select>
                      </div>
                      <div class="col-sm-6 form-group">
                        <label>Personal Website:</label>
                        <input type="text" name="website" placeholder="Enter Personal Website" class="form-control ">
                      </div> 
                      <div class="col-sm-6 form-group">
                        <label>Email Address:</label>
                        <input type="email" name="email" placeholder="Enter Email Address" class="form-control">
                      </div> 
                       <div class="col-sm-6 form-group">
                        <label>Whatsapp Contact:</label>
                        <input type="number" name="whatsap" placeholder="Enter Whatsapp Number" class="form-control">
                      </div>
                      <div class="col-sm-6 form-group">
                        <label>Phone 1:</label>
                        <input type="number" name="phone" placeholder="Enter Phone Number" class="form-control ">
                      </div>
                       <div class="col-sm-6 form-group">
                        <label>Phone 2:</label>
                        <input type="number" name="phone2" placeholder="Enter Phone Number" class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="row d-none" >
                      <div class="col-sm-4 " style="display: inline-block; margin: auto;">
                          <label style="text-align: center;">FingerPrint Scan:</label>
                      <div class="row" style="display: inline-flex !important;">
                          <img type="file" class="col-xl-12" src="<?php echo PROOT ?>images/fingerdefault.png" alt="" id="">
                          <button class="bg-success">Capture Finger</button>  
                      </div>
                    </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12 form-group">
                        <label>Appointment Type:</label>
                        <select class="form-control user-input" name="appointment_type_id">
                          <option value="">Select Appointment Type:</option>
                          <option value="1">Full Time</option>
                          <option value="2">Part Time</option>
                          <option value="3">Visiting</option>
                          <option value="4">Adjunct</option>
                        </select>
                      </div>
                    </div>
                  </div>

                </div>

                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                <button id="lecreg"  class="btn btn-primary btn-user btn-block">Register Lecturer</button>
                
               
              </form>
              <hr>
             
            </div>
          
        </div>
      </div>
    </div>
       
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

         <script type="text/javascript">
           function displayImage(e){
            if (e.files[0]) {
              var reader = new FileReader();

              reader.onload = function(e){
                document.querySelector('#profile-image').setAttribute('src', e.target.result);
              }

              reader.readAsDataURL(e.files[0]);              
            }
          }
         </script>


<?= $this->end(); ?>


