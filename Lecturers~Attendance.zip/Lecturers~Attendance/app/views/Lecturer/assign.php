 <?= $this->setSiteTitle('Lecturer | Details');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
          <link href="<?php echo PROOT ?>css/dataTables.bootstrap.css" rel="stylesheet">

          <div class="card shadow mb-4" style="margin-top: 5px;">
 
            <div class="card-body assignlec">
              <div class="table-responsive assignlechide" style="width: 100%;">
                <div id="dataTable_wrapper" class="dataTables_wrapper">
           
                  <div class="row" style="margin-top: 1%;" id="table">
                    <?php require(ROOT . DS . 'processes' . DS . 'printcss.php'); ?>

                     <h6 class="m-0 font-weight-bold text-primary" style="margin-bottom: 1% !important;">List Of Active Faculty Members As At <?php echo date("D-M-Y"); ?> </h6>
                </div>
                <style type="text/css">
                    div.table-responsive>div.dataTables_wrapper>div.row {
                       margin: 0;
                      }
                      .col-sm-3, .col-sm-4, .col-sm-8, .col-sm-12 {
                      min-height: 1px;
                      padding-left: 15px;
                      margin:0;
                    }
                    label{
                      display: inline-flex !important;
                    }
                    table {
                        border-spacing: 0;
                        display: block; 

                    }
                    td{
                       padding: 4px !important;
                    }
                                </style>
                <div class="row" style="width: 100% !important;" >
                 <table class="table table-bordered" id="lecturers" style="text-align: left !important;">
                   <thead>
                    <tr >
                      <!-- basic information -->
                        <th width="150px">Faculty ID</th>
                        <th width="260px">Fullname</th>
                        <th width="240px">Email</th>
                        <th>Contact Number</th>
                        <th width="200px">Rank</th>
                        <th width="150px">Appointment Type</th>
                        <th width="140px">Assigned Date</th>
                    </tr>
                   </thead>
                </table>
                </div>
               </div>
            </div>

            <hr>
          </div>

          <!-- to display selected lectuerer details -->
      <script type="text/javascript">
                            var dir ="http://localhost/Lecturers~Attendance/";
          function displayImage(e){
            if (e.files[0]) {
              var reader = new FileReader();

              reader.onload = function(e){
                document.querySelector('#profile-image').setAttribute('src', e.target.result);
              }

              reader.readAsDataURL(e.files[0]);              
            }
          }

                       document.addEventListener("DOMContentLoaded",function(){
                              getLecturers();
                          },false);
                         
                          function getLecturers(){
                               $('#lecturers').dataTable({
                                  'bProcessing': true,
                                  'sAjaxSource': ''+dir+'/Processor/json',
                                  'sAjaxDataProp': "data",
                                  'lengthMenu': [[15,50,100,200,500,-1],[15,50,100,200,500,'ALL']],
                                  'destroy': true,
                                  "order": [[ 0, "asc" ]],
                              })
                          }

                    function searchFunction() {
                      // Declare variables
                      var input, filter, table, tr, td, i, txtValue , nxtvalue;
                      input = document.getElementById("search");
                      filter = input.value.toUpperCase();
                      table = document.getElementById("lecturers");
                      tr = table.getElementsByTagName("tr");

                      // Loop through all table rows, and hide those who don't match the search query
                      for (i = 0; i < tr.length; i++) 
                      {

                        td = tr[i].getElementsByTagName("td")[0];
                        td1 = tr[i].getElementsByTagName("td")[1];
                        td2 = tr[i].getElementsByTagName("td")[2];
                        td3 = tr[i].getElementsByTagName("td")[3];
                        td4 = tr[i].getElementsByTagName("td")[4];

                        if (td)
                        {
                              nameValue = td.textContent || td.innerText;
                              idvalue = td1.textContent || td1.innerText;
                              supValue = td2.textContent || td2.innerText;
                              assValue = td3.textContent || td3.innerText;
                              endValue = td4.textContent || td4.innerText;

                          if (
                                nameValue.toUpperCase().indexOf(filter) > -1 || 
                                idvalue.toUpperCase().indexOf(filter) > -1 || 
                                supValue.toUpperCase().indexOf(filter) > -1 || 
                                assValue.toUpperCase().indexOf(filter) > -1 || 
                                endValue.toUpperCase().indexOf(filter) > -1) 
                              {
                                tr[i].style.display = "";
                              } 
                              else
                               {
                                tr[i].style.display = "none";
                              }
                        }

                      }
                    }

                   
              </script>

<?= $this->end(); ?>
