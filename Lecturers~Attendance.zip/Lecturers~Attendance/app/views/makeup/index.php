<?= $this->setSiteTitle('Lecturers | Makeup');  ?>
<?= $this->start('body');  ?>
          <!-- Content Row -->
        <?php
           $this->load_model('TbllecturerAssignCourses'); $assignedcoursesquery = $this->TbllecturerAssignCoursesModel;
            $this->load_model('SCampus'); $campusquery = $this->SCampusModel;

            ?>
         <!-- Begin Page Content -->
        <div class="container-fluid" style="width: 60%">

          <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0" >
        <!-- Nested Row within Card Body -->
        <div class="row" >
        
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Lectures MakeUp</h1>
              </div>
              <form  method="post" id="MakeUpForm" action="javascript:void(0)">
                <div class="form-group row">
                <div class="col-sm-6 form-group camp">
                  <label>Campus:</label>
                  <select class="form-control user-input sch_check" name="campus">
                    <option value="">
                      Select Campus:
                    </option>
                        <?= $campusquery->allcampusQuery();?>
                  </select>
                </div>
                <div class="col-sm-6 form-group" id="getcourses">
                  <label>Course Code:</label>
                  <select class="form-control user-input code_check" id="courses" name="course_code" disabled="disabled">
                    <option value="">
                      Select Course Code:
                    </option>
                        
                  </select>
                </div>
                </div>
                <div class="row">
                 <div class="col-sm-6 user-name" id="lectu">
                    <label>Lecturer:</label>
                    <input type="text" name="lecturer"  placeholder="Lecturer" class="form-control user-input init_check" disabled="disabled">
                  </div>
                <div class="form-group col-lg-6" id="session">
                  <label>Session:</label>
                    <select class="form-control user-input ses_check" id="ses_check" name="session_id" disabled="disabled">
                      <option value="">
                         Getting Session:....
                        </option>
                  </select>
                 </div>

                </div>
                 <div class="row">
                 <div class="col-sm-6 user-name">
                    <label>Date for MakeUp:</label>
                    <input type="date" name="date" placeholder="Lecturer" class="form-control user-input day_check" >
                  
                  </div>
                <div class="form-group col-lg-6">
                  <label>Lecture Hall:</label>
                    <select class="form-control user-input hall_check" name="l_hall" disabled="disabled">
                      <option value="">
                          Available Lecture Halls: ....
                        </option>
                         
                  </select>
                 </div>
                 <input type="number" name="user_session" style="display: none;" value="<?php echo $_SESSION['staff_id']; ?>">
                </div>


                <hr>
                <div class="alert-message" id="message" style="display: none; margin-top: 5px;"></div>
                <hr>
                <button id="MakeUp" class="btn btn-primary btn-user btn-block Make_btn">MakeUp</button>
                
               
              </form>
              <hr>
             
            </div>
          
        </div>
      </div>
    </div>
       
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

         


<?= $this->end(); ?>


