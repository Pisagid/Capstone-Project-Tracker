<?php 

	/**
	 * 
	 */
	class SCampus extends Model
	{
		
		public function __construct()
		{
			$table = 's_campus';
			parent::__construct($table);
			
		}

		public function findByUsername($username)
		{
			return $this->findFirst(['conditions'=> "username = ?", 'bind'=>[$username]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}

		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
				return $this->_db->update($this->_table, $fields, $conditions); 	
			}
		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

		public function allcampusQuery ()
		{
			$campusquery = $this->selectAll();
	        $campusquery = $this->results();
	        foreach ($campusquery as $row ) 
	        {
				 $campus_name = $row->campus;
                               $campus_id = $row->id;
                                ?>
				<option value="<?php echo $campus_id;  ?>">
                 <?php echo $campus_name; ?></option>
			<?php
	        }
		}

		public function allQuery ()
		{
			$campusquery = $this->selectAll();
	        $campusquery = $this->results();
	        return $campusquery;
		}
		
		public function results()
		{
			return $this->modelresults();
		}

		public function count()
		{
			return $this->modelcount();
		}

		public function campusQuery ($id)
		{
			$fields = ['campus' => 'campus']; $cond = ['id' => $id]; 
			$campus_name = $this->select($fields, $cond);
	        $campus_name = $this->results();
	       	return $campus_name[0]->campus;
		}

		public function campusid ($campus)
		{
			
			$fields = ['id' => 'id']; $cond = ['campus' => $campus]; 
			
			$sessionquery = $this->select($fields, $cond);
	        $sessionquery = $this->results();
	        return $sessionquery[0]->id;
		}

		public function allcampus()
		{
			$campusquery = $this->selectAll();
	        $campusquery = $this->results();
	        return $campusquery;
		}
	
	}

 ?>