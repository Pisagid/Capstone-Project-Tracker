<?php 

	/**
	 * 
	 */
	class Updated extends Model
	{
		
		public function __construct()
		{
			$table = 'updated';
			parent::__construct($table);
		}

		public function findByUsername($username)
		{
			return $this->findFirst(['conditions'=> "username = ?", 'bind'=>[$username]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function condselect($columns = [], $conditions = [], $logics = [])
			{
				if (empty($columns) || empty($conditions) || empty($logics)) 
				{
					return false;
				}
					return $this->_db->condselect($this->_table, $columns, $conditions, $logics); 	
			}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}


		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->update($this->_table, $fields, $conditions); 	
		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

		

		public function results()
		{
			return $this->modelresults();
		}
		public function count()
		{
			return $this->modelcount();
		}

		public function allsesQuery ()
		{
			$sessionquery = $this->selectAll();
	        $sessionquery = $this->results();
	        foreach ($sessionquery as $row ) 
	        {
				$ses_id=  $row->id; 
				$ses_name=  $row->session_name; 
	         ?>
	            <option value="<?= $ses_id;  ?>">
	            <?= $ses_name; ?></option>
			<?php
	        }
		}

		public function hallQuery ($session_id, $day, $lhall)
		{
			$fields = ['uhall_id' => 'uhall_id']; 
			$cond = ['usession_id' => $session_id,'udate' => $day,'uhall_id' => $lhall]; 
			$fhallquery = $this->select($fields, $cond);
	        $fhallquery = $this->results();
	        if (isset($fhallquery[0]->uhall_id)) {
	       		return $fhallquery[0]->uhall_id;
	        }
	        return false;
		}

		public function existcourseQuery($course, $uday, $udate, $campus)
		{
			$fields = ['ucourse_code' => 'ucourse_code', 'udate' => 'udate']; 
			$cond = ['ucourse_code' => $course,'uday' => $uday, 'udate' => $udate,'ucampus_id' => $campus]; 
			$exiscourse = $this->select($fields, $cond);
	        $exiscourse = $this->results();
	        $exiscourse = $this->count();
	        if ($exiscourse > 0) {
	       		return $exiscourse;
	        }
	        return false;
		}


		public function updatecourseQuery($ucourse_code, $lec_id, $uday, $udate, $uhall_id, $usession_id, $campus, $user_session)
		{
			$fields = ['uday' => $uday,'ulecturer_id' => $lec_id, 'udate' => $udate, 'uhall_id' => $uhall_id, 'usession_id' => $usession_id, 'ucampus_id' => $campus, 'ustaff_id' => $user_session];

			$cond = ['udate' => $udate, 'ucourse_code' => $ucourse_code]; 

			$exiscourse = $this->update($fields, $cond);
	        
	        if ($exiscourse) {
	       		return true;
	        }
	        return false;
		}

		public function lecturesQuery ($session_id, $day, $campus_id, $date)
		{
			$cond = ['usession_id' => $session_id,'uday' => $day,'udate' => $date,'ucampus_id' => $campus_id];
			$lectquery = $this->selectAll($cond);
	        $lectquery = $this->results();
	        
	        return $lectquery;
		}


		public function insertcourseQuery($ucourse_code, $lec_id, $uday, $udate, $uhall_id, $usession_id, $campus, $user_session)
		{
			$fields = ['ucourse_code' => $ucourse_code, 'ulecturer_id' => $lec_id, 'uday' => $uday, 'udate' => $udate, 'uhall_id' => $uhall_id, 'usession_id' => $usession_id, 'ucampus_id' => $campus, 'ustaff_id' => $user_session];

			$insert = $this->insert($fields);
	        
	        if ($insert) {
	       		return true;
	        }
	        return false;
		}		

		public function updatedJSON($sesquery)
		{
			$coursefields = ['*'=> '*']; $ucond = ['uday' => day,'udate' => date, 'usession_id' => $sesquery];
			$makeupcoursequery = $this->select($coursefields, $ucond);
			$makeupcoursecount = $this->count();
			$makeupcoursequery = $this->results();
			if ($makeupcoursecount>0) {
				return $makeupcoursequery;
			}
			else{
				return false;
			}
		}


	}

 ?>