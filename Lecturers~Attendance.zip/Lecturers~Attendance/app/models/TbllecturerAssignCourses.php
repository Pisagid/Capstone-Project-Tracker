<?php 

	/**
	 * 
	 */
	class TbllecturerAssignCourses extends Model
	{
		
		public function __construct()
		{
			$table = 'tbllecturer_assign_courses';
			parent::__construct($table);
			
		}

		public function findByUsername($username)
		{
			return $this->findFirst(['conditions'=> "username = ?", 'bind'=>[$username]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}


		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->update($this->_table, $fields, $conditions); 	
		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

		

		public function results()
		{
			return $this->modelresults();
		}
		public function count()
		{
			return $this->modelcount();
		}

		public function assignedcoursesQuery ()
		{
			$tab = $this->_table;
			$sql = "SELECT DISTINCT course_code FROM {$tab} ORDER BY course_code ASC";
			$coursesquery = $this->query($sql);
			$coursesquery = $this->results();
	        foreach ($coursesquery as $row ) 
	        {
	            $course_code = $row->course_code;
	         ?>
	            <option value="<?php echo $course_code;  ?>">
	            <?php echo $course_code; ?></option>
			<?php
	        }
		}

		public function assignLectQuery($course_code, $campus)
		{
			$fields = ['lecturer_id' => 'lecturer_id']; $cond = ['course_code' => $course_code, 'campus' => $campus];
			$assignlectquery = $this->select($fields, $cond);
	        $assignlectquery = $this->results();
	        if (isset($assignlectquery[0]->lecturer_id)) {
			$lecturer_id= $assignlectquery[0]->lecturer_id;
			return $lecturer_id;
	        }
	        return false;

		}

		public function assignedcourses($lecturer_id)
		{
			$tab = $this->_table;
			$sql = "SELECT DISTINCT course_code, campus FROM {$tab} WHERE lecturer_id = {$lecturer_id} AND status != 'D' ORDER BY course_code ASC";
			$assigned = $this->query($sql);
	        $assigned = $this->results();
			return $assigned;
	       
		}

		public function campuscoursesQuery ($campus)
		{
			$tab = $this->_table;
			$sql = "SELECT DISTINCT course_code FROM {$tab} WHERE campus = {$campus} ORDER BY course_code ASC";
			$coursesquery = $this->query($sql);
			$coursesquery = $this->results();
	        foreach ($coursesquery as $row ) 
	        {
	            $course_code = $row->course_code;
	         ?>
	            <option value="<?php echo $course_code;  ?>">
	            <?php echo $course_code; ?></option>
			<?php
	        }
		}

		public function coursecheck ($course_code, $campus_id)
		{
			$fields = ['course_code' => $course_code];
			$cond = ['course_code' => $course_code, 'campus' => $campus_id];
			$lectquery = $this->select($fields, $cond);
	        $lectquery = $this->results();
	        
	        if (isset($lectquery[0]->course_code)) {
	       		return true;
	        }
	        return false;
		}

		public function insertassignQuery($course_code, $lecturer_id, $campus)
		{
			$fields = ['course_code' => $course_code, 'lecturer_id' => $lecturer_id, 'status' => 'A', 'campus' => $campus,'date_assigned' => date];

			$insert = $this->insert($fields);
	        
	        if ($insert) {
	       		return true;
	        }
	        return false;
		}

		public function updateassignquery($course_code, $lecturer_id, $campus)
		{
			$fields = ['course_code' => $course_code, 'lecturer_id' => $lecturer_id, 'status' => 'A', 'campus' => $campus, 'date_assigned' => date];
			$cond = ['course_code' => $course_code, 'campus' => $campus];

			$update = $this->update($fields, $cond);
			//$update = $this->results();
	      
	        if ($update) {
	       		return true;
	        }
	        return false;
		}
	}

 ?>

