<?php 

	/**
	 * 
	 */
	class Attendance extends Model
	{
		
		public function __construct()
		{
			$table = 'attendance';
			parent::__construct($table);
			
		}

		public function findByUsername($username)
		{
			return $this->findFirst(['conditions'=> "username = ?", 'bind'=>[$username]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}

		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->update($this->_table, $fields, $conditions); 	

		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

	
		
		public function results()
		{
			return $this->modelresults();
		}

		public function count()
		{
			return $this->modelcount();
		}

		
		public function verifycourse($course_code, $sesquery, $date, $campus)
		{
			$fields = ['course_code'=> 'course_code']; 
			$cond = ['date' => $date, 'session_id' => $sesquery,'course_code'=> $course_code, 'campus'=> $campus];
			$verifycoursequery = $this->select($fields, $cond);
			
			$verifycoursequery = $this->results();
		
			return $verifycoursequery;
			
		}

		public function attendedquery($course_code, $campus, $month, $year)
		{

			$fields = ['*'=> '*']; 
			$cond = [ 'course_code' => $course_code, 'campus' => $campus, 'month_id' => $month, 'year' => $year];

			$attendance = $this->selectAll($cond);
				$attendance = $this->results();	
		
			if ($attendance) {
				return $attendance;
			}
			else
				return false;
		}

		public function checkpresent($course_code)
		{
			$fields = ['attended' => 'attended'];
			$cond = ['course_code' => $course_code,'date' => date];
			$check = $this->select($fields,$cond);
	        $check = $this->count();
	        return $check;
		}

		public function attended($course_code, $month, $year, $w, $campus)
		{
			$fields = ['attended' => 'attended', 'start_time' => 'start_time','end_time' => 'end_time'];
			$cond = ['course_code' => $course_code, 'month_id' => $month,'year' => $year ,'week_id' =>  $w ,'campus' => $campus];
			$attended = $this->select($fields,$cond);
	        $attended = $this->results();
	        return $attended;
		}

		public function booked($course_code,$campus)
		{
			$fields = ['attended' => 'attended'];
			$cond = ['course_code' => $course_code, 'month_id' => month,'year' => year ,'date' => date,'campus' => $campus];
			$attended = $this->select($fields,$cond);
	        $attended = $this->results();
	        return $attended;
		}

		public function att($course_code, $month, $year, $campus)
		{
			$fields = ['attended' => 'attended'];
			$cond = ['course_code' => $course_code, 'month_id' => $month,'year' => $year ,'campus' => $campus];
			$attended = $this->select($fields,$cond);
	        $attended = $this->results();
	        return $attended;
		}
		
		public function timequery($course_code, $month, $year, $w, $campus)
		{
			$fields = ['start_time' => 'start_time','end_time' => 'end_time'];
			$cond = ['course_code' => $course_code, 'month_id' => $month,'year' => $year ,'week_id' =>  $w ,'campus' => $campus];
			$attended = $this->select($fields,$cond);
	        $attended = $this->results();
	        return $attended;
		}


		public function lecturesJSON($sesquery)
		{
			$fields = ['*'=> '*'];
			 $cond = ['date' => date, 'session_id' => $sesquery];
			$coursequery = $this->select($fields, $cond);
			$coursecount = $this->count();
			$coursequery = $this->results();
	       if ($coursecount>0) {
				return $coursequery;

			}
			else{
				return false;
			}
		}


		public function insertcourseQuery($course_code, $campus, $session_id)
		{
			$fields = ['course_code' => $course_code, 'campus' => $campus, 'day' => day, 'start_time' => time, 'session_id' => $session_id, 'week_id' => current_week, 'month_id' => month, 'year' => year, 'date' => date, 'staff_id' => $_SESSION['staff_id']];

			$insert = $this->insert($fields);
	        
	        if ($insert) {
	       		return true;
	        }
	        return false;
		}

		public function updatecourseQuery($course_code, $campus, $session_id, $mark)
		{
			$fields = ['end_time' => time,'attended' => $mark];

			$cond = ['course_code' => $course_code, 'campus' => $campus, 'day' => day, 'session_id' => $session_id, 'week_id' => current_week, 'month_id' => month, 'year' => year, 'date' => date];


			$exiscourse = $this->update($fields, $cond);
	        
	        if ($exiscourse) {
	       		return true;
	        }
	        return false;
		}
	

	}

 ?>