<?php 

	/**
	 * 
	 */
	class WSessions extends Model
	{
		
		public function __construct()
		{
			$table = 'w_sessions';
			parent::__construct($table);
			
		}

		public function findByUsername($username)
		{
			return $this->findFirst(['conditions'=> "username = ?", 'bind'=>[$username]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function condselect($columns = [], $conditions = [], $logics = [])
			{
				if (empty($columns) || empty($conditions) || empty($logics)) 
				{
					return false;
				}
					return $this->_db->condselect($this->_table, $columns, $conditions, $logics); 	
			}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}


		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->update($this->_table, $fields, $conditions); 	
		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

		

		public function results()
		{
			return $this->modelresults();
		}
		public function count()
		{
			return $this->modelcount();
		}

		public function wsesQuery ()
		{
			$sessionquery = $this->selectAll();
	        $sessionquery = $this->results();
	        foreach ($sessionquery as $row ) 
	        {
				$ses_id=  $row->id; 
				$ses_name=  $row->ses_name; 
	         ?>
	            <option value="<?= $ses_id;  ?>">
	            <?= $ses_name; ?></option>
			<?php
	        }
		}

		public function wsessionQuery ()
		{
			$fields = ['id' => 'id','ses_name' => 'ses_name'];
			$sessionquery = $this->selectAll($fields);
	        $sessionquery = $this->results();
	        dnd($sessionquery);
	        foreach ($sessionquery as $row ) 
	        {
				$ses_id=  $row->id; 
				$ses_name=  $row->ses_name; 
	         ?>
	            <option value="<?= $ses_id;  ?>">
	            <?= $ses_name; ?></option>
			<?php
	        }
		}

		
		public function allwsesQuery ($id)
		{
			
			$fields = ['start_time' => 'start_time','end_time' => 'end_time','ses_name' => 'ses_name']; $cond = ['id' => $id]; 
			
			$sessionquery = $this->select($fields, $cond);
	        $sessionquery = $this->results();
	        return $sessionquery;
		}

		public function currentsessionQuery ()
		{
			$timesplit=explode(':',time);
			$time=($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);

			$sessionquery = $this->selectAll();
	        $sessionquery = $this->results();
	        //dnd($sessionquery);
	        foreach ($sessionquery as $row ) 
	        {
				$ses_id=  $row->id; 
				$ses_name=  $row->ses_name; 
				$start_time=  $row->start_time; 
				$end_time=  $row->end_time; 

	        	$timesplit=explode(':',$start_time);
    			$start_time =($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);
    			$timesplit=explode(':',$end_time);
    			$end_time =($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);

						
					if ($time >= $start_time &&  $time <= $end_time ) {
						return $ses_id;
					}
	        }
	        return false;
					
		}

		public function sessioname ()
		{
			$timesplit=explode(':',time);
			$time=($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);

			$sessionquery = $this->selectAll();
	        $sessionquery = $this->results();
	        //dnd($sessionquery);
	        foreach ($sessionquery as $row ) 
	        {
				$ses_id=  $row->id; 
				$ses_name=  $row->ses_name; 
				$start_time=  $row->start_time; 
				$end_time=  $row->end_time; 

	        	$timesplit=explode(':',$start_time);
    			$start_time =($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);
    			$timesplit=explode(':',$end_time);
    			$end_time =($timesplit[0]*60)+($timesplit[1])+($timesplit[2]>30?1:0);

						
					if ($time >= $start_time &&  $time <= $end_time ) {
						return $ses_name;
					}
	        }
	        return false;
					
		}

		public function sessionid ($ses_name)
		{
			
			$fields = ['id' => 'id']; $cond = ['ses_name' => $ses_name]; 
			
			$sessionquery = $this->select($fields, $cond);
	        $sessionquery = $this->results();
	        return $sessionquery[0]->id;
		}


	}

 ?>