<?php 

	/**
	 * 
	 */
	class TbllecturerData extends Model
	{
		
		public function __construct()
		{
			$table = 'tbllecturer_data';
			parent::__construct($table);
			
		}

		public function findByUsername($username)
		{
			return $this->findFirst(['conditions'=> "username = ?", 'bind'=>[$username]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}


		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->update($this->_table, $fields, $conditions); 	
		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

		

		public function results()
		{
			return $this->modelresults();
		}
		public function count()
		{
			return $this->modelcount();
		}

		public function condselect($columns = [], $conditions = [], $logics = [])
			{
				if (empty($columns) || empty($conditions) || empty($logics)) 
				{
					return false;
				}
					return $this->_db->condselect($this->_table, $columns, $conditions, $logics); 	
			}


		
		public function users($id)
		{
			
			$fields = ['username' => 'username']; $cond = ['username' => $id]; 
				$logics = ['1' => 'LIKE'];
			
			$users = $this->condselect($fields, $cond, $logics);
	        $users = $this->count();
	        return $users;
	        
		}

		public function tryquery($id)
		{
			$tab = $this->_table;
			$sql = "SELECT MAX(lecturer_id) FROM {$tab} WHERE username LIKE {$id}";
			$field = ['username' => 'username']; $cond = ['username' => $id];

			$tryme = $this->query($sql, $field, $cond);
			//$tryme = $this->results();

			return $tryme;
		}

		public function accountdeact($username)
		{
			$fields = ['user_status' => 0]; $cond = ['username' => $username]; 
			$deactivate = $this->update($fields, $cond);
	        return $deactivate;
		}

		public function passwordreset($username)
		{
			$fields = ['password' => DAFAULT_QBTTXPSE]; $cond = ['username' => $username]; 
			$reset = $this->update($fields, $cond);
	        return $reset;
		}


		public function allLectQuery ()
		{
			$lectquery = $this->selectAll();
	        $lectquery = $this->results();
	        foreach ($lectquery as $row ) 
	        {
				$fname=  $row->fname; $mname=  $row->mname; $lname= $row->lname;
	            $lec_name = $fname." ".$mname." ".$lname;
	            $lec_name = strtolower($lec_name);
	            $lec_name = ucwords($lec_name, ' -');
	            $userid = $row->username;
	         ?>
	            <option value="<?php echo $userid;  ?>">
	            <?php echo $lec_name; ?></option>
			<?php
	        }
		}

		public function allLectJSON()
		{
			$fields = ['*' => '*']; $cond = ['user_status' => 1];
			$lectquery = $this->select($fields, $cond);
	        $lectquery = $this->results();
	        $rank = array('0' => "Null",'1'=>"Professor", '2'=> "Associate Professor", '3'=> "Senior Lecturer", '4'=> "Assistant Professor", 
	        				'5'=> "Lecturer", '6'=>"Assistant Lecturer",'7'=> "Academic Teaching Assistant");

	        $appoint = array('0' => "Null", '1'=>"Full Time", '2'=> "Part Time", '3'=> "Visiting", '4'=> "Adjunct");
	         $data = array();
	        foreach ($lectquery as $row ) 
	        {
				$fname=  $row->fname; $mname=  $row->mname; $lname= $row->lname;
	            $lec_name = $fname." ".$mname." ".$lname;
	            $lec_name = strtolower($lec_name);
	            $lec_name = ucwords($lec_name, ' -');
	           	$rank_id = $row->rank_id;
	            $userid = strtoupper($row->username);
	            $app = $row->appointment_type_id;
	         $data[] = array(
						'<a href="#" data-toggle="model" class="dropdown-item lecid lecassign" value="'.$userid.'">'.$userid.'</a>',
						$lec_name,
						$row->email,
						$row->phone,
						$rank[$rank_id],
						$appoint[$app],
						$row->joined,
					);
	        }

			$output = array(
				'aaData'=> $data,
			);

			 echo json_encode($output);
		}

		public function singleLectQuery($lecturer_id)
		{

			$fields = ['fname' => 'fname','lname' => 'lname','mname' => 'mname']; $cond = ['lecturer_id' => $lecturer_id];
			$singlelectquery = $this->select($fields, $cond);
	        $singlelectquery = $this->results();

	        $fname=  $singlelectquery[0]->fname;
			$mname=  $singlelectquery[0]->mname;
			$lname= $singlelectquery[0]->lname;
			$lec_name = $fname." ".$mname." ".$lname;
			$lec_name = strtolower($lec_name);
			$lec_name = ucwords($lec_name, ' -');

			return $lec_name;
		}

		public function lectname($username)
		{

			$fields = ['fname' => 'fname','lname' => 'lname','mname' => 'mname']; $cond = ['username' => $username];
			$singlelectquery = $this->select($fields, $cond);
	        $singlelectquery = $this->results();
	        if (isset($singlelectquery)) {
	        $fname=  $singlelectquery[0]->fname;
			$mname=  $singlelectquery[0]->mname;
			$lname= $singlelectquery[0]->lname;
			$lec_name = $fname." ".$mname." ".$lname;
			$lec_name = strtolower($lec_name);
			$lec_name = ucwords($lec_name, ' -');

			return $lec_name;
	        }
	        return false;
		}

		public function lecdetailsQuery($lecturer_id)
				{
					$fields = ['*'=> '*']; $cond = ['username' => $lecturer_id];
					$lecdetailsquery = $this->select($fields, $cond);
			        $lecdetailsquery = $this->results();

					return $lecdetailsquery;
				}

				public function username($lecturer_id)
				{
					$fields = ['username'=> 'username']; $cond = ['lecturer_id' => $lecturer_id];
					$lecdetailsquery = $this->select($fields, $cond);
			        $lecdetailsquery = $this->results();
					return $lecdetailsquery[0]->username;
				}

		public function lecinitQuery($lecturer_id)
		{
			$fields = ['fname' => 'fname','mname' => 'mname','lname' => 'lname']; $cond = ['lecturer_id' => $lecturer_id];
			$singlelectquery = $this->select($fields, $cond);
	        $singlelectquery = $this->results();
	       
	        $fname= substr($singlelectquery[0]->fname , 0,1);
			$mname= substr($singlelectquery[0]->mname , 0,1);
			$lname= substr($singlelectquery[0]->lname , 0,1);
			
			$lec_init = $fname."".$mname."".$lname;


			return $lec_init;
		}

		public function registerQuery($username, $password, $fname, $mname, $lname, $title_id, $rank_id, $website, $appointment_type_id, $joined, $phone, $email, $whatsap, $phone2, $user_status)
		{
			
			$fields = ['username' => $username,'password' => $password,'fname' => $fname, 'mname' => $mname, 'lname' => $lname, 'title_id' => $title_id, 'rank_id' => $rank_id, 'website' => $website, 'appointment_type_id' => $appointment_type_id, 'joined' => $joined, 'phone' => $phone, 'email' => $email, 'whatsap' => $whatsap, 'phone2' => $phone2, 'user_status' => $user_status];

			$insert = $this->insert($fields);
	        
	        if ($insert) {
	       		return true;
	        }
	        return false;
		}

		public function updatelecturer($username, $fname, $mname, $lname, $title_id, $rank_id, $website, $appointment_type_id, $phone, $email, $whatsap, $phone2)
		{
			
			$fields = ['username' => $username, 'fname' => $fname, 'mname' => $mname, 'lname' => $lname, 'title_id' => $title_id, 'rank_id' => $rank_id, 'website' => $website, 'appointment_type_id' => $appointment_type_id, 'phone' => $phone, 'email' => $email, 'whatsap' => $whatsap, 'phone2' => $phone2];
			$cond = ['username' => $username];

			$update = $this->update($fields, $cond);
			//$update = $this->results();
	      
	        if ($update) {
	       		return true;
	        }
	        return false;
		}


		public function lectAttendanceQuery()
		{
			$tab = $this->_table;
			$sql = "SELECT  DISTINCT *  FROM {$tab} ORDER BY username ASC";
			$lecturers = $this->query($sql);
	        $lecturers = $this->results();
	        foreach ($lecturers as $row ) 
	        {
	            $username = $row->username;
	            $fname=  $row->fname;
				$mname=  $row->mname;
				$lname= $row->lname;
				$lec_name = $fname." ".$mname." ".$lname;
				$lec_name = strtolower($lec_name);
				$lec_name = ucwords($lec_name, ' -');

	         ?>
		        <tbody>
		        	<style type="text/css">
		        		td, th{
		        			text-align: left;
		        		}
		        	</style>
					<tr >
						<td  style="width: 15% ;"><input class="checkbox singleCheckbox box" type="checkbox" name="lecturer_id[]" value="<?= $username;  ?>"></td>
						<td style="width: 5800px"><?= $lec_name; ?></td>
						<td style="width: 20%;" ><?= $username; ?></td>
						</tr>
				</tbody>
			<?php
	        }
		}

		//to get number of weeks in that month  
	    public function weeks($month, $year)
	    {
		      $num_of_days = date("t", mktime(0,0,0,$month,1,$year)); 
		       $lastday = date("t", mktime(0, 0, 0, $month, 1, $year)); 
		       $no_of_weeks = 0; 
		        $count_weeks = 0; 
		      while($no_of_weeks < $lastday){ 
		      $no_of_weeks += 7; 
		        $count_weeks++; 
		       } 
		        return $count_weeks;
		  } 

		
		public function style($exp_weeks)
		  {
        	if ($exp_weeks==5) { ?>
                 <style type="text/css">
                   .att_header, .att_data
                    {
                        width: 10% !important;
                    }
                                                            
                    </style> <?php
                } 
                else if ($exp_weeks==4) { ?>
                  <style type="text/css">
                     .att_header, .att_data
                    {
                        width: 13% !important;
                    }
                 </style><?php
                 }
                else if ($exp_weeks==3) {?>
                   <style type="text/css">
                     .att_header, .att_data
                    {
                       width: 15% !important;
                    }
                   </style>
                     <?php
                }
            }

            public function getID($username)
            {
            	$fields = ['lecturer_id' => 'lecturer_id']; $cond = ['username' => $username]; 
				$lec_id = $this->select($fields, $cond);
		        $lec_id = $this->results();
		        return $lec_id[0]->lecturer_id;
            }

	}

 ?>