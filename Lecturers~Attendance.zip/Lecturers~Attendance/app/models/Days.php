<?php 

	/**
	 * 
	 */
	class Days extends Model
	{
		
		public function __construct()
		{
			$table = 'days';
			parent::__construct($table);
			
		}

		public function findByUsername($username)
		{
			return $this->findFirst(['conditions'=> "username = ?", 'bind'=>[$username]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function condselect($columns = [], $conditions = [], $logics = [])
			{
				if (empty($columns) || empty($conditions) || empty($logics)) 
				{
					return false;
				}
					return $this->_db->condselect($this->_table, $columns, $conditions, $logics); 	
			}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}


		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->update($this->_table, $fields, $conditions); 	
		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

		

		public function results()
		{
			return $this->modelresults();
		}
		public function count()
		{
			return $this->modelcount();
		}

		public function allsesQuery ()
		{
			$sessionquery = $this->selectAll();
	        $sessionquery = $this->results();
	        foreach ($sessionquery as $row ) 
	        {
				$ses_id=  $row->id; 
				$ses_name=  $row->session_name; 
	         ?>
	            <option value="<?= $ses_id;  ?>">
	            <?= $ses_name; ?></option>
			<?php
	        }
		}

		public function dayQuery ($day)
		{
			$fields = ['id' => 'id']; $cond = ['day_name' => $day]; 
			$dayquery = $this->select($fields, $cond);
	        $dayquery = $this->results();
	       	return $dayquery[0]->id;
		}

		public function daynameQuery ($id)
		{
			$fields = ['day_name' => 'day_name']; $cond = ['id' => $id]; 
			$dayquery = $this->select($fields, $cond);
	        $dayquery = $this->results();
	       	return $dayquery[0]->day_name;
		}

		


	}

 ?>