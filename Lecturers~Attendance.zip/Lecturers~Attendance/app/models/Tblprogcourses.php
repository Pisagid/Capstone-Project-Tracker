<?php 

	/**
	 * 
	 */
	class Tblprogcourses extends Model
	{
		
		public function __construct()
		{
			$table = 'tblprogcourses';
			parent::__construct($table);
			
		}

		public function findByUsername($crscode)
		{
			return $this->findFirst(['conditions'=> "crscode = ?", 'bind'=>[$crscode]]);
		} 

		public function select($columns = [], $conditions = [])
		{
			if (empty($columns) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->select($this->_table, $columns, $conditions); 	
		}

		public function query($sql, $bind = [], $condParams = [])
		{
			return $this->_db->query($sql, $bind, $condParams);
		}

		public function selectAll($conditions = [])
		{
			if (empty($conditions)) 
			{
				return $this->_db->selectAll($this->_table, $conditions); 	
			}
			return $this->_db->selectAll($this->_table, $conditions); 	

		}


		public function insert($fields)
		{
			if (empty($fields)) 
			{
				return false;
			}
				return $this->_db->insert($this->_table, $fields); 	
		}

		public function update($fields, $conditions)
		{
			if (empty($fields) || empty($conditions)) 
			{
				return false;
			}
				return $this->_db->update($this->_table, $fields, $conditions); 	
		}
		
		public function delete($conditions = [])
		{
			if (empty($conditions) == '' && $this->id == '') 
			{
				return false;
				$id = ($id == '')? $this->id : $id;

				if ($this->_softDelete) 
				{
					return $this->update($this->table, ['deleted' => 1], $conditions);		
				}
				else 
				{
					return  $this->_db->delete($this->_table, $conditions);		
				}	
			}
		}

		

		public function results()
		{
			return $this->modelresults();
		}
		public function count()
		{
			return $this->modelcount();
		}

		public function allcoursesQuery()
		{
			$tab = $this->_table;
			$sql = "SELECT DISTINCT crscode, crstitle FROM {$tab} ORDER BY crscode ASC";
			$coursesquery = $this->query($sql);
	        $coursesquery = $this->results();
	        foreach ($coursesquery as $row ) 
	        {

	            $course_code = $row->crscode;
	            $title = $row->crstitle;
	         ?>
		        <tbody>
		        	<style type="text/css">
		        		td, th{
		        			text-align: left;
		        		}
		        	</style>
					<tr >
						<td  style="width: 15% ;"><input class="checkbox singleCheckbox" type="checkbox" name="course_code[]" value="<?= $course_code;  ?>"></td>
						<td style="width: 5800px"><?= $title; ?></td>
						<td style="width: 20%;" ><?= $course_code; ?></td>
						</tr>
				</tbody>
			<?php
	        }
		}

		public function precourses($trm)
		{
			$tab = $this->_table;
			$sql = "SELECT DISTINCT crscode, crstitle FROM {$tab} WHERE trm < '{$trm}' ORDER BY crscode ASC";
			$coursesquery = $this->query($sql);
	        $coursesquery = $this->results();

	        foreach ($coursesquery as $row ) 
	        {

	            $course_code = $row->crscode;
	            $title = $row->crstitle;
	    
	         ?>
	          <option value="<?php echo $course_code;  ?>">
	            <?php echo $title; ?></option>
		        
			<?php
	        }
		}

		public function coursexist($crscode, $prgcode)
		{
			$fields = ['crscode' => 'crscode']; $cond = ['crscode' => $crscode, 'prgcode' => $prgcode];
			$course = $this->select($fields, $cond);
	        $course = $this->results();

			return $course;
		}
		public function coursedet($crscode, $prgcode)
		{
			$fields = ['*' => '*']; $cond = ['crscode' => $crscode, 'prgcode' => $prgcode];
			$course = $this->select($fields, $cond);
	        $course = $this->results();

			return $course;
		}

		public function insertcourse($crscode, $crstitle, $crdhrs, $yr, $trm, $prgcode, $run, $pereq)
		{
			$fields = ['crscode' => $crscode,'crstitle' => $crstitle,'crdhrs' => $crdhrs, 'yr' => $yr, 'trm' => $trm, 'prgcode' => $prgcode, 'run' => $run, 'pereq' => $pereq];

			$insert = $this->insert($fields);
	        
	        if ($insert) {
	       		return true;
	        }
	        return false;
		}

		public function allcourseJSON()
		{
			$tab = $this->_table;
			$sql = "SELECT DISTINCT crscode, crstitle, pereq, prgcode, trm, yr, run FROM {$tab} ORDER BY crstitle ASC";
			$lectquery = $this->query($sql);
	        $lectquery = $this->results();
	         $data = array();
	        foreach ($lectquery as $row ) 
	        {
	            $crstitle = sanitize($row->crstitle);
	            $pereq = strtoupper($row->pereq);
	            $crscode = strtoupper($row->crscode);
	            $prgcode = $row->prgcode;
	            $trm = $row->trm;
	            $yr = $row->yr;
	            $run = $row->run;

	         $data[] = array(
						'<a href="#" data-toggle="model" class="dropdown-item crscode crscod" prgcode="'.$prgcode.'" value="'.$crscode.'">'.$crscode.'</a>',
						$crstitle,
						$pereq,
						$prgcode,
						$trm,
						$yr,
						$run,
					);
	        }

			$output = array(
				'aaData'=> $data,
			);
	            

			 echo json_encode($output);
		}

		public function updatecourse($crscode, $crstitle, $crdhrs, $yr, $trm, $prgcode, $run, $pereq)
		{
			$fields = ['crscode' => $crscode,'crstitle' => $crstitle,'crdhrs' => $crdhrs, 'yr' => $yr, 'trm' => $trm, 'prgcode' => $prgcode, 'run' => $run, 'pereq' => $pereq];

			$cond = ['crscode' => $crscode];

			$update = $this->update($fields, $cond);
			//$update = $this->results();
	      
	        if ($update) {
	       		return true;
	        }
	        return false;
		}

		public function singleLectQuery($username)
		{
			$fields = ['fname' => 'fname','lname' => 'lname','mname' => 'mname']; $cond = ['username' => $username];
			$singlelectquery = $this->select($fields, $cond);
	        $singlelectquery = $this->results();

	        $fname=  $singlelectquery[0]->fname;
			$mname=  $singlelectquery[0]->mname;
			$lname= $singlelectquery[0]->lname;
			$lec_name = $fname." ".$mname." ".$lname;
			$lec_name = strtolower($lec_name);
			$lec_name = ucwords($lec_name, ' -');

			return $lec_name;
		}


	}

 ?>

