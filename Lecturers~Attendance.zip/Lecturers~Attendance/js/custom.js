$(document).ready(function(){

	var dir ="http://localhost/Lecturers~Attendance/";
	
	var input = "form-control-user";
	var selectinput = "user-input";
	var checkbox = "check";
	function setAutocomplete()
	{
		$('input').attr('autocomplete','off');
	}
	setAutocomplete();


	function move() {
	 var elem = document.getElementById("myBar"); 
	  var width = 1;
	  var id = setInterval(frame, 10);
		function frame() {
			 if (width >= 100) {
			  clearInterval(id);
			  $('#myBar, #myProgress').hide();
			}
			else 
			{

			 $('#myBar, #myProgress').fadeIn();
			 width++; 
				elem.style.width = width + '%'; 
			 }
		}
	}

function formChecker_extend(class_target)
		{
		var dataValid = true;
		$(class_target).each(function(index, el){
			var inputField = $(this);
			var inputName = inputField.attr('name');
			if ($.trim(inputField.val()) == '')
			 { 
				$(this).css('border-color','red');
				inputField.attr('placeholder',''+inputName+' is required');    	 	
				dataValid = false;
			 }      
		});

		if(dataValid===true)
		{
			return true;
		}
		else
		{
			var chc = $(class_target).attr('name');
			if ($.trim($(chc).val()) == '')
			{
				var inputName = $(this).attr('name');	
				$(this).css('border-color','red');
				$(this).attr('placeholder',''+inputName+' is required');   

				
			}

			$('.alert-message').fadeIn(200, function() {
					$(this).css('color','red');
					$(this).addClass('alert-danger').html('Please Fill All Required Input Fields');
				});
				setTimeout(function(){
					$('.alert-message').fadeOut(200, function() {
						$(this).addClass('alert-danger').html('');
					});
				},5000);
			return false;
		}
	}



 //for login
  $(document).on('click', '#login', function(e) {
		e.preventDefault();
		$(document).keyup(mine(input)).change(mine(input));
	if (formChecker_extend('.'+input)===true) {
			$('#logForm').submit();
		}
 })


 $(document).on('submit', '#logForm', function(a) {
 	a.preventDefault();
		$.ajax({
				url:''+dir+'login/login',
				type: 'POST',
				data:new FormData(this),
				contentType:false,
				cache:false,
				processData:false,
				beforeSend:function(data)
				{

				},
				success:function(data)
				{	
					//console.log(data);
					var response = $.trim(data);
					//console.log(response);
						if (response==1) {
						   move();
							setTimeout(function(){
							$('#cover').fadeOut(200, function() {
								window.location.href =''+dir+'dashboard';
							});
							},1000);
						}
						 else if (response==0) {
							$('.alert-message').fadeIn(200, function() {
							$(this).css('color','red');
								$(this).addClass('alert-danger').html('Check Username or Password');
							});   

							setTimeout(function(){
							$('.alert-danger').fadeOut(200, function() {
								$(this).removeClass('alert-danger').html('');
							});
							},5000);
						}	
					}

				
		});
	});

 //for changing password

			function changePassword() {
				 $(document).on('submit', '#changeForm', function(e) {
					$.ajax({
					url:''+dir+'login/changepassword',
					type:'POST',
					data:new FormData(this),
					contentType:false,
					cache:false,
					processData:false,
					beforeSend:function(data)
					{

					},
					success:function(data)
					{
						var response = $.trim(data);
						if (response==1) 
			 				{
			 					/*console.log(data);*/
			 					move();
								$('.alert-message-change').fadeIn(200, function() {
										$(this).css('color','green');
										$(this).addClass('alert-success').html('Password Change is succesful');
									});
								
									setTimeout(function(){
										setTimeout(function(){
											$('.alert-message').fadeOut(200, function() {
												$(this).removeClass('alert-success').html('');
												
											});
											
											},5000);
											$('.alert-message-change').fadeIn(200, function() {
												$(this).css('color','red');
												$(this).addClass('alert-success').html('You will be logged out to confirm new password');

											});
											setTimeout(function(){
												$('#signoutform').submit();

											},5000);
												
										},4000);
									
							}
							else if (response==2) 
							{
			 					$('.alert-message-change').fadeIn(200, function() {
									$(this).css('color','red');
									$(this).addClass('alert-danger').html('Incorrect Password');
									$('#opassword').css('border-color','red');
								});
			 				}
					}

					});
				});
				$('#changeForm').submit();
			}
	
$(document).on('click', '#change-password', function(k) {
		k.preventDefault();
		
		var username = $('#username').val();
		var old_password = $('#opassword').val();
		var pass_1 = $('#ipassword').val();
		var pass_2 = $('#fpassword').val();
		var classs = $(this).attr('name');
		$(document).keyup(mine(input+'-change')).change(mine(input+'-change'));
		if (formChecker_extend('.'+input+'-change')===true)
		{
				if(pass_1 === pass_2)
				{
					$('.alert-message-change').fadeIn(200, function() {
						$(this).css('color','red');
						$(this).addClass('alert-danger').html('');
						$('#fpassword').css('border-color','#ccc');

					});
					changePassword();
					
				}
				else
				{
					$('.alert-message-change').fadeIn(200, function() {
							$(this).css('color','red');
							$(this).addClass('alert-danger').html('Password Mis-matched');
							$('#fpassword').css('border-color','red');
						});

					setTimeout(function(){
						$('.alert-message-change').fadeIn(200, function() {
							$(this).removeClass('alert-danger').html('');
							//$('#fpassword').css('border-color','red');
						});
					},5000);
				}
		}

	});

 $(document).on('click', '#cancel-password', function(e) {
		e.preventDefault();
			$('#changeForm').trigger('reset');
 });
//end of change password


//alerter 
function mine(id){

	$('.'+id).keydown(function(){
		if ($.trim($(this).val()) =='')
		{ 
			$("#"+id).attr('disabled', 'disabled');
			$(this).css('border-color','red');
		}          
		else
		{
			$("#"+id).removeAttr('disabled');
			$(this).css('border-color','#ccc');
		}
	 });

	$('.'+id).keyup(function(){
		if ($.trim($(this).val()) =='')
		{ 
			$("#"+id).attr('disabled', 'disabled');	
			$(this).css('border-color','red');
		}          
		else
		{
			$("#"+id).removeAttr('disabled');
			$(this).css('border-color','#ccc');
		}
	});
	$('.'+id).change(function(){
		$(this).css('border-color','#ccc');
	});
	$('.'+id).click(function(){
		if ($.trim($(this).val()) > 3)
		{ 
			$("#"+id).attr('disabled', 'disabled');
			$(this).css('border-color','red');
		}          
		else
		{
			$("#"+id).removeAttr('disabled');
			$(this).css('border-color','#ccc');
		}
	});
}
//end of alerter




	$('.cred').keyup(function(){
		if ($.trim($(this).val()) > 3)
		{ 
			$('.alert-message').fadeIn(200, function() {
				$(this).css('color', 'red');
				$(this).addClass('alert-danger').html('Credit Hour Cannot Be Greater Than 3');
			});
			setTimeout(function(){
			$('.alert-message').fadeOut(200, function() {
				$('.cred').val('');	
				});
			},2000);
			
		}   
		else if ($.trim($(this).val()) < 0)
		{ 
			$('.alert-message').fadeIn(200, function() {
				$(this).css('color', 'red');
				$(this).addClass('alert-danger').html('Credit Hour Cannot Be Less Than 0');
			});
			setTimeout(function(){
			$('.alert-message').fadeOut(200, function() {
				$('.cred').val('');	
				});
			},2000);
			
		}          
		
	});


 $(document).on("click", "#addprogcourse", function(e){
		e.preventDefault();
		$(document).keyup(mine(selectinput)).change(mine(selectinput));
		$(document).keyup(mine(input)).change(mine(input));
	if ((formChecker_extend('.'+input)===true) && (formChecker_extend('.'+selectinput)===true))
		{
			$('.crs').removeAttr('disabled');
			addprogcourse();
		}

 });

  function addprogcourse()
			 {
			 	$(document).on('submit', '#addprogcourseForm', function(e) {
			 			e.preventDefault();
			 			$.ajax({
						url:''+dir+'Processor/addprogcourse',
						type: 'POST',
						data:new FormData(this),
						contentType:false,
						cache:false,
						processData:false,
						beforeSend:function()
						{
						},
						success:function(data)
						{	
							  
							if ($.trim(data) == 0) 
							 {
							 	$('.alert-message').fadeIn(200, function() {
										$(this).css('color','red');
											$(this).addClass('alert-danger').html('Failed To Add OR Update Course');
								});
									setTimeout(function(){
										$('.alert-message').fadeOut(200, function() {
									});
								},5000);
							}
							if ($.trim(data) != 0) 
							 {
							 	$('.alert-message').fadeIn(200, function() {
										$(this).css('color','green');
											$(this).addClass('alert-success').html(''+data);
								});
									setTimeout(function(){
										$('.alert-message').fadeOut(200, function() {
										location.reload();
									});
								},5000);
							}
						}
			 		});
			 	});
			 	$('#addprogcourseForm').submit();
			 }

 //for registering users
 $("#reguser").click(function(e){
		e.preventDefault();
		$(document).keyup(mine(selectinput)).change(mine(selectinput));
		$(document).keyup(mine(input)).change(mine(input));
	if ((formChecker_extend('.'+input)===true) && (formChecker_extend('.'+selectinput)===true))
		{
			var new_user = $('.userChecker').attr('value');
			registerUser(new_user);
		}

 });

 function registerUser(new_user)
			 {
			 	$(document).on('submit', '#reguserForm', function(e) {
			 		var form = new FormData(this);
			 		form.append("username", ""+new_user)
			 			e.preventDefault();
			 			$.ajax({
						url:''+dir+'register/register',
						type: 'POST',
						data:form,
						contentType:false,
						cache:false,
						processData:false,
						beforeSend:function()
						{
						},
						success:function(data)
						{	
							//console.log(data);
							/*alert(data);
							console.log(data);*/  
							if ($.trim(data)==1)
							 {
							 	$('.alert-message').fadeIn(200, function() {
										$(this).css('color','green');
											$(this).addClass('alert-success').html('User Registration is Successful');
								});
									setTimeout(function(){
										$('.alert-message').fadeOut(200, function() {
										location.reload();
									});
								},5000);
							}
						}
			 		});
			 	});
			 	$('#reguserForm').submit();
			 }


 //for registering lecturers
 		$(document).on('click', '#lecreset, #lecdeact', function(e){
		e.preventDefault();
		var id = $(this).attr('id');
		var username = $('.userChecker').val();
				
						if (id == "lecdeact") {
							$.ajax({
								url:''+dir+'processor/lecreg',
								type:'POST',
								data:{"lecdeact": ""+id, "username": ""+username},
								beforeSend:function(data)
								{
								
								},
								success:function(data)
								{
									$('#lecrestpassword').removeClass('show');
									$('.fade').removeClass('show');
									$('#lecrestpassword').hide();
									$('.modal-backdrop').hide();

									$('.alert-message').fadeIn(200, function() {
									$(this).css('color','green');
									$(this).addClass('alert-success').html(''+data);
									});
									setTimeout(function(){
									$('.alert-message').fadeOut(200, function() {
											 	location.reload();
											});
										},5000);
									}
				 			});
						}
						else if(id == "lecreset") {
							$.ajax({
							url:''+dir+'processor/lecreg',
							type:'POST',
							data:{"lecreset": ""+id, "username": ""+username},
							beforeSend:function(data)
							{
							
							},
							success:function(data)
							{
								$('#lecrestpassword').removeClass('show');
								$('.fade').removeClass('show');
								$('#lecrestpassword').hide();
								$('.modal-backdrop').hide();

								$('.alert-message').fadeIn(200, function() {
								$(this).css('color','green');
								$(this).addClass('alert-success').html(''+data);
								});
								setTimeout(function(){
								$('.alert-message').fadeOut(200, function() {
										 	location.reload();
										});
									},5000);
								}
				 			});
						}
						
						

				 });

 		//for registering lecturers
 $(document).on('click', '#lecreg, #lecupdate', function(e){
		e.preventDefault();
		var id = $(this).attr('id');
		$('.userChecker').removeAttr('disabled');
		var form = '#'+id+'Form';
		$(document).keyup(mine(selectinput)).change(mine(selectinput));
		$(document).keyup(mine(input)).change(mine(input));
	if ((formChecker_extend('.'+input)===true) && (formChecker_extend('.'+selectinput)===true))
		{
			lecturesform(form);

		}

 });
 		function lecturesform(form){
 				$(document).on('submit', ''+form, function(e) {
			 			e.preventDefault();
			 			$.ajax({
						url:''+dir+'processor/lecreg',
						type:'POST',
						data:new FormData(this),
						contentType:false,
						cache:false,
						processData:false,
						beforeSend:function(data)
						{
						
						},
						success:function(data)
						{
							data = $.trim(data);
							console.log(data);
							if (data == 1) {
								$('.alert-message').fadeIn(200, function() {
								$(this).css('color','red');
								$(this).addClass('alert-danger').html('Update For Faculty Member Failed');
								});
								setTimeout(function(){
								$('.alert-message').fadeOut(200, function() {
										});
									},5000);
							}
							if (data == 2) {
								$('.alert-message').fadeIn(200, function() {
								$(this).css('color','red');
								$(this).addClass('alert-danger').html('Registration Of Faculty Member Failed');
								});
								setTimeout(function(){
								$('.alert-message').fadeOut(200, function() {
										});
									
									},5000);
							}
							else{
								$('.alert-message').fadeIn(200, function() {
								$(this).css('color','green');
								$(this).addClass('alert-success').html(''+data);
								});
								setTimeout(function(){
								$('.alert-message').fadeOut(200, function() {
										});
								if (data == 'Faculty Member Registered Successfully') {
									location.reload();
								}
									},5000);
							}
							
						}
			 		});
			 	});

 				$(''+form).submit();
 		}
			 

 $('.campus, .staff_type').bind('change', function(e){
	var campus = $('.campus').val();
	var staff_type= $('.staff_type').val();
		if ($.trim(campus)!='' && $.trim(staff_type) !='')
		{
			getusername(campus, staff_type);
		}
	});

function getusername(campus, staff_type)
			 {
			 	
			 		$.ajax({
			 			url:''+dir+'register/getuser',
			 			type:"POST",
			 			data:{'campus_name':campus, 'staff_type':staff_type},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				data = $.trim(data);
			 				//console.log(data);
			 				//$('.userChecker').removeAttr('disabled');
			 				$('.userChecker').remove();
			 				$('.user-name').append(data); 
			 				$('.userChecker').css('background-color','white');
			 				$('.userChecker').css('color','black');
			 				/*alert($('.hall_check').data('value'));	*/
			 			}
			 		});
			 }
// end of registering users

//for get prerequisite courses
 $('.semes').bind('change', function(){
 	
	var semes = $('.semes').val();
		if ($.trim(semes)!='' && semes != 'Sem 1')
		{
			getpre(semes);
		}
		else
		{
			$('.pre').attr('disabled','disabled');
		}
	});

 function getpre(semes)
			 {
			 		$.ajax({
			 			url:''+dir+'Processor/getpre',
			 			type:"POST",
			 			data:{'trm':semes},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				data = $.trim(data);
			 				//console.log(data);
			 				$('.pre').remove();
			 				$('.preq').append(data); 
			 				$('.pre').css('background-color','white');
			 				$('.pre').css('color','#ccc');
			 			}
			 		});
			 }


//end of prerequisite

 $('.faculty_type').bind('change', function(e){
	var school = $(this).val();
			lecusername(school);
	});
 		function lecusername(school)
			 {
			 	
			 		$.ajax({
			 			url:''+dir+'processor/getuser',
			 			type:"POST",
			 			data:{'school':school},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				data = $.trim(data);
			 				console.log(data);
			 				if ($.trim(data)!= '') {
			 						$('.userChecker').val(''+data);
			 						$('.userChecker').attr('disabled', 'disabled');
			 				}
			 				else
			 				{
			 					$('.userChecker').removeAttr('disabled');
			 					$('.userChecker').val('');}

			 			}
			 		});
			 }


//for user sign out
$(document).on('click', '.user_out', function(a){
				a.preventDefault();
				$('#signoutform').submit();
			});

			$('#signoutform').submit(function(){
					$.ajax({
					url:''+dir+'login/logout',
					type:'POST',
					data:new FormData(this),
					contentType:false,
					cache:false,
					processData:false,
					beforeSend:function(data)
					{
					
					},
					success:function(data)
					{
						//console.log(data);
						location.reload();
						window.location.href =""+dir+'Login';
					
					}

					});
				});

				// end of user sign out

 //for assigning a project
  $('.assign_date').bind('change', function(e){
			 		var start_date = $('.assign_date').val();
			 		 if ($.trim(start_date)!='')
			 		 {
			 		 	getEnd_date(start_date);
			 		 }
			 	});

function getEnd_date(start_date)
			 {
			 	
			 		$.ajax({
			 			url:''+dir+'assign/getenddate',
			 			type:"POST",
			 			data:{'start_date':start_date},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				//$('.userChecker').removeAttr('disabled');
			 				$('.dateCheck').remove();
			 				$('.end_date').append(data); 
			 				$('.dateCheck').css('background-color','white');
			 				$('.dateCheck').css('color','black');
			 				/*alert($('.hall_check').data('value'));	*/
			 			}
			 		});
			 }

//buttons submit
 $(document).on('click', '#MakeUp, .add_btn', function(e) {
		e.preventDefault();
		var id = $(this).attr('id');
		if ($(this).attr('value') == "add") {
			input = ''+id+"-form-control";
			selectinput = ""+id+"-user-input";
		}
		var code = $('.code_check').val();
		var form_submit = ''+id+'Form';
		var submit;
		//alert(form_submit);
		$(document).keyup(mine(input)).change(mine(input));
		$(document).keyup(mine(selectinput)).change(mine(selectinput));
	if ((formChecker_extend('.'+input))===true && (formChecker_extend('.'+selectinput)===true)) {
			//for makeup schedule
		 if (form_submit=='MakeUpForm') 
			{
				submit = 1;
				formSubmit(form_submit, submit, code);
			}

			//for for adding a course submission forms
			else if (form_submit==''+id+'Form') 
			{
				submit = 2; code = id;
				formSubmit(form_submit, submit, id);
				
			} 	
			
			
		}
		

 });


 //forms submit
 function formSubmit (form_submit, submit, code){
 	$(document).on('submit', '#'+form_submit, function(e) {
		e.preventDefault();
		var form = new FormData(this);
		form.append("submit", ""+submit);

		$.ajax({
			url:''+dir+'Processor',
			type: 'POST',
			data:form,
			contentType:false,
			cache:false,
			processData:false,
			beforeSend:function(data)
			{
				
			},
			success:function(data)
			{
				data = $.trim(data);
				//console.log(data);
				// for makeup  
				if (submit==1) {
					if ($.trim(data)=="Updated"){
						$('.alert-message').fadeIn(200, function() {
							$(this).css('color','green');
							$(this).addClass('alert-success').html('MakeUp For '+code+' is Successfully '+data);
						});
						setTimeout(function(){
						$('.alert-message').fadeOut(200, function() {
						location.reload();
							});
						},5000);
					}
					else if ($.trim(data)=="Inserted"){
						$('.alert-message').fadeIn(200, function() {
							$(this).css('color','green');
							$(this).addClass('alert-success').html('MakeUp For '+code+' is Successful');
						});
						setTimeout(function(){
						$('.alert-message').fadeOut(200, function() {
							location.reload();
							});
						},5000);
					}
					else{
						$('.alert-message').fadeIn(200, function() {
							$(this).css('color','red');
							$(this).addClass('alert-danger').html('The Date '+data+' is Already Past');
						});
						setTimeout(function(){
						$('.alert-message').fadeOut(200, function() {
							});
						},5000);
					}
				}
				// for scheduling courses
				
				else if(submit==2){
					//alert(code);
						
							if (data==1) {
									$('.'+code+'-alert-message').fadeIn(200, function() {
									$(this).css('color','green');
										$(this).addClass('alert-success').html('Course schedule Updated Successfully');
									});
									setTimeout(function(){
										$('.'+code+'-alert-message').fadeOut(200, function() {
											$(this).removeClass('alert-success').html('');
											$('#'+code+'Form').trigger('reset');
											
										});
									},5000);
								}
								else if (data==2) {
									$('.'+code+'-alert-message').fadeIn(200, function() {
									$(this).css('color','red');
										$(this).addClass('alert-danger').html('Hall has been booked');
									});
									setTimeout(function(){
										$('.'+code+'-alert-message').fadeOut(200, function() {
												$(this).removeClass('alert-success').html('');
												
										});
									},5000);
								}
								else if (data==3) {
									$('.'+code+'-alert-message').fadeIn(200, function() {
										$(this).css('color','green');
										$(this).addClass('alert-success').html('Course scheduled succesfully!');
									});
									

									setTimeout(function(){
										
										$('.'+code+'-alert-message').fadeOut(200, function() {
											$(this).removeClass('alert-success').html('');
											$('#'+code+'Form').trigger('reset');
											
										});
									},5000);
								}
								else if (data==4) {
									alert(code);
									$('.'+code+'-alert-message').fadeIn(200, function() {
										$(this).css('color','red');
										$(this).addClass('alert-danger').html('No Lecturer for this course');
									});

									setTimeout(function(){
										$('.'+code+'-alert-message').fadeOut(200, function() {
											$(this).removeClass('alert-danger').html('');
											
										});
									},5000);
								}
				}
				//end of scheduling courses

			}
		});
	});

	$('#'+form_submit).submit();
 }

//corcerning makeup page
$(document).on('change','.day_check, .sch_check, .ses_check', function(e){
	var ses_check = $('.ses_check').val();
	var day_check = $('.day_check').val();
	var sch_check = $('.sch_check').val();
	if ( $.trim(day_check)!='' && $.trim(sch_check)!='' && $.trim(ses_check)!='')
	{ 		 	
		checkStatus(ses_check,day_check,sch_check);
	}
	else
	{
		$('.hall_check').attr('disabled','disabled');
	}
	
});


$(document).on('change','.sch_check', function(e){
	var sch_check = $('.sch_check').val();
	if($.trim(sch_check)!='')
	{
		getsession(sch_check);
		getcourses(sch_check);
	}
});

$(document).on('change','.code_check', function(e){
	var sch_check = $('.sch_check').val();
	var code_check = $('.code_check').val();
	if($.trim(sch_check)!='' && $.trim(code_check)!='')
	{
		lecturer(code_check, sch_check);
	}
});

	//to get schools periods
		 	 function getsession(sch_check)
		 	 {
		 	 	$.ajax({
		 	 		url:''+dir+'makeup/makeupdetails',
			 			type:"POST",
			 			data:{'campus_id':sch_check},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				if ($.trim(data) != '') 
			 				{
			 					$('.ses_check').removeAttr('disabled');
				 				$('.ses_check').remove();
				 				$('#session').append(data);
			 				}
			 			}
		 	 	});
		 	 }
//to get assigned courses for the school
		 	 function getcourses(sch_check)
		 	 {
		 	 	var get = 'getcourses';
		 	 	$.ajax({
		 	 		url:''+dir+'makeup/makeupdetails',
			 			type:"POST",
			 			data:{'campus_id':sch_check, 'get':get},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				if ($.trim(data) != '') 
			 				{
			 					$('.code_check').removeAttr('disabled');
				 				$('.code_check').remove();
				 				$('#getcourses').append(data);
			 				}
			 				
			 			}
		 	 	});
		 	 }

	// to get assigned lecturer
	function lecturer(code_check, sch_check)
			 	{
			 		$.ajax({
			 			url:''+dir+'makeup/makeupdetails',
			 			type:"POST",
			 			data:{'course_code':code_check, 'campus_id':sch_check},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				if ($.trim(data)== 1) 
			 				{
			 					if ($('.init_check').val() != '') 
			 						{
			 							$('.init_check').val('');	
			 							$('.init_check').attr('placeholder', 'Lecturer');
			 						};
			 					
			 					$('.alert-message').fadeIn(200, function() {
										$(this).css('color','red');
										$(this).addClass('alert-danger').html('No Assigned Lecturer for '+code_check+' In This Campus');
								});
								setTimeout(function(){
								$('.alert-message').fadeOut(200, function() {
									});
								},5000);
			 				}
			 				else{
				 				$('.init_check').remove();
				 				$('#lectu').append(data);
			 				}

			 			}
			 		});
			 	}

			 function checkStatus(ses_check,day_check,sch_check)
			 {
			 		$.ajax({
			 			url:''+dir+'makeup/makeupdetails',
			 			type:"POST",
			 			data:{'session_id':ses_check, 'date':day_check, 'campus_id':sch_check},
			 			beforeSend(data)
			 			{
			 				
			 			},
			 			success:function(data)
			 			{
			 				$('.hall_check').removeAttr('disabled');
			 				$('.hall').remove();
			 				$('.hall_check').append(data);
			 				
			 				/*alert($('.hall_check').data('value'));	*/
			 			}
			 		});
			 		
			 	
			 }

//end of makeup


//
 function checkboxChecker ()
 {
 	var checker = false;
 	 var check = document.getElementsByClassName(''+checkbox);
	for (var i = 0; i < check.length; i++) {
			  var checked = $(check[i]).val();
			  if (checked == 1) {
			  	checker =true;
			  } 
	  }

	  if (checker==true) 
	  {
	  	return true;
	  }
	  else{
	  	return false;
	  }
 }


//for print
			$(document).on('click', '#print', function(){
				var id = $(this).attr('value');
			  	 var prtContent = document.getElementById(id);
                 var WinPrint = window.open('', '', 'left=0,top=0,width=auto,height=auto,toolbar=0,scrollbars=0,status=0');
                  WinPrint.document.write(prtContent.innerHTML);
                  WinPrint.document.close();
                  WinPrint.focus();
                  WinPrint.print();
                  WinPrint.close();
			  });


		function searchFunction() {
		  // Declare variables
				 var input, filter, table, tr, td, i, txtValue , nxtvalue;
				input = document.getElementById("lecsearch");
				 filter = input.value.toUpperCase();
				table = document.getElementById("lecturers");
				 tr = table.getElementsByTagName("tr");

				// Loop through all table rows, and hide those who don't match the search query
					for (i = 0; i < tr.length; i++) {
						td = tr[i].getElementsByTagName("td")[1];
						td1 = tr[i].getElementsByTagName("td")[2]
						if (td)
						 {
						        txtValue = td.textContent || td.innerText;
								nxtvalue = td1.textContent || td1.innerText;
								if (txtValue.toUpperCase().indexOf(filter) > -1 || nxtvalue.toUpperCase().indexOf(filter) > -1) {
								tr[i].style.display = "";
							    } 
							    else 
							    {
								  tr[i].style.display = "none";
								}
							}
						  }

						}

						$('#Attendanceform').on('keyup keypress', function(e) {
						var keyCode = e.keyCode || e.which;
						if (keyCode === 13) { 
						 e.preventDefault();
						 return false;
					  }
				});

						$(document).on('click', '.lecid', function(){
                              var id = $(this).attr('value');
                              lectDetails(id);
                              		$('.lechide').hide();

                            });
						$(document).on('click', '.lecassign', function(){
                              var id = $(this).attr('value');
                              lecassign(id);
                              		$('.assignlechide').hide();

                            });

						$(document).on('click', '.crscode', function(){
                              var crscode = $(this).attr('value');
                              var prgcode = $(this).attr('prgcode');
                           
                              crsdetails(crscode, prgcode);
                              		$('.lechide').hide();

                            });

						$(document).on('click', '.lecclose', function(){
                              $('.lechide').show();
								$('.lechide').addClass('show');
								$('.lecmodal').hide();

								 $('.assignlechide').show();
								$('.assignlechide').addClass('show');
								$('.lecmodal').hide();
                            });

                          function crsdetails(crscode, prgcode)
                          {
                           
                              $.ajax({
                              url:''+dir+'/Processor/coursedetails',
                              type: "POST",
                              data:{'crscode':crscode,'prgcode':prgcode},
                              cache: false,
                              beforeSend:function(data)
                              {

                              },
                              success:function(data)
                              { 
                              
                               $('.courseview').append(data);                                
                              }

                              
                           });
                          }

                            function lectDetails(faculty_id)
                          {
                           
                              $.ajax({
                              url:''+dir+'/Processor/lecupdate',
                              type: "POST",
                              data:{'faculty_id':faculty_id},
                              cache: false,
                              beforeSend:function(data)
                              {

                              },
                              success:function(data)
                              { 
                              
                               $('.updatelec').append(data);                                
                              }

                              
                           });
                          }

                          function lecassign(faculty_id)
                          {
                           
                              $.ajax({
                              url:''+dir+'/Processor/lecassign',
                              type: "POST",
                              data:{'faculty_id':faculty_id},
                              cache: false,
                              beforeSend:function(data)
                              {

                              },
                              success:function(data)
                              { 
                              
                               $('.assignlec').append(data);                                
                              }

                              
                           });
                          }
							
					$(document).on('click', '.course_signin, .course_signout', function(){
                              var course_code = $(this).attr('value');
                              var campus_id = $(this).attr('school-value');
                              var sign_type = $(this).attr('data-value');
                              coursesign(course_code, campus_id, sign_type);
                              		$('.lechide').hide();

                            });
				$(document).keypress(
				  function(event){
				    if (event.which == '13') {
				      event.preventDefault();
				    }
				});

				$(document).on('click', '#lecSignIn, #lecSignOut', function(e){
						e.preventDefault();
                              var form_submit = $(this).attr('id')+'Form';
                              var ena = document.getElementsByClassName('user-input');

                              $(document).on('submit', '#'+form_submit, function(e) {
								e.preventDefault();
                              var faculty_id = $('#faculty_id').val();
                              var code = $('.code').val();
                              	
								$.ajax({
									url: ''+dir+'/Processor/course',
									type: 'POST',
									data:new FormData(this),
									contentType:false,
									cache:false,
									processData:false,
									beforeSend:function(data)
									{
														
									},
									success:function(data)
									{
										data = $.trim(data);
										if (data==1) {
											$('.alert-message').fadeIn(200, function() {
											$(this).css('color','red');
												$(this).addClass('alert-danger').html('Incorrect Password For Faculty ID: '+faculty_id);
											});
											setTimeout(function(){
												$('.alert-message').fadeOut(200, function() {
													$(this).removeClass('alert-danger').html('');
													$(ena).each(function(index,record){
					                              		$(this).attr('disabled', 'disabled');
							    					});
							    					$('.pass').removeAttr('disabled');
												});
											},5000);
										}
										else if (data==2) {
											$('.alert-message').fadeIn(200, function() {
											$(this).css('color','red');
												$(this).addClass('alert-danger').html('Course Code: '+code+' Has Exceeded The Required Number Of Signings');
											});
											setTimeout(function(){
												$('.alert-message').fadeOut(200, function() {
													$(this).removeClass('alert-danger').html('');
													location.reload();
												});
											},5000);
										}
										else{
											$('.alert-message').fadeIn(200, function() {
											$(this).css('color','green');
												$(this).addClass('alert-success').html(''+data);
											});
											setTimeout(function(){
												$('.alert-message').fadeOut(200, function() {
												$(this).removeClass('alert-success').html('');
												location.reload();
												});
											},5000);
										}
									}
								});

                            });

                              if ((formChecker_extend('.'+selectinput)===true)) {
                              	
                              	$(ena).each(function(index,record){
                              	$(this).removeAttr('disabled');
		    					});
                             	$('#'+form_submit).submit();
                              }
                            
                         });

						$(document).on('click', '.lecclose', function(){
                              $('.lechide').show();
								$('.lechide').addClass('show');
								$('.lecmodal').hide();
                            });

                          function coursesign(course_code, campus, sign_type)
                          {
                              $.ajax({
                              url:''+dir+'/Processor/signings',
                              type: "POST",
                              data:{'course_code':course_code,'campus':campus,'sign_type':sign_type},
                              cache: false,
                              beforeSend:function(data)
                              {

                              },
                              success:function(data)
                              { 
                              
                               $('.updatelec').append(data);
                                
                              }

                              
                           });
                          }

                          $(document).on('click', '#lecassign, #attendance', function(e){
                              e.preventDefault();
								var id = $(this).attr('id');
								var form_submit = ''+id+'Form';
								var enabler = false;
								var url = ''+dir+'Processor/lecassigning';
								if (form_submit == 'attendanceForm') {
									url = ''+dir+'Processor';
								}
									$('.singleCheckbox').each(function(){
										if ($(this).prop('checked') == true) 
										{
										 enabler = true;
										}
							  		});
										$(document).keyup(mine(input)).change(mine(input));
										$(document).keyup(mine(selectinput)).change(mine(selectinput));
									if (enabler == true){
										if ((formChecker_extend('.'+selectinput)===true)) {
											$(document).on('submit', '#'+form_submit, function(e) {
												e.preventDefault();
												$.ajax({
													url: ''+url,
													type: 'POST',
													data:new FormData(this),
													contentType:false,
													cache:false,
													processData:false,
													beforeSend:function(data)
													{
														
													},
													success:function(data)
													{
														data= $.trim(data);
														if (form_submit == 'lecassignForm') {
																if (data == 'Updated') {
																$('.alert-message').fadeIn(200, function() {
																$(this).css('color','green');
																$(this).addClass('alert-success').html('Lecturer For This Course Updated Successfully');
																});
																setTimeout(function(){
																$('.alert-message').fadeOut(200, function() {
																	});
																},5000);
															}
															else
															 {
															 	$('.alert-message').fadeIn(200, function() {
																$(this).css('color','green');
																$(this).addClass('alert-success').html('Course Successfully Assigned To Lecturer');
																});
																setTimeout(function(){
																$('.alert-message').fadeOut(200, function() {

																	});
																},5000);
															 }
														}
														else
														{
															$('.att_view').remove();
															$('.attend_sheet_header').remove();
															$('#attendanceInfo').remove();
															$('#attendancePrint').remove();
															$('.viewcontent').show();
															$('.viewcontent').append(data);
														}
													}
												});
											});	
											$('#'+form_submit).submit();							
										}
									 }
									 else
									 {
									 	if (form_submit == 'lecassignForm') {
									 		$('.alert-message').fadeIn(200, function() {
											$(this).css('color','red');
											$(this).addClass('alert-danger').html('Please Select A Course To Be Assigned');
											});
											setTimeout(function(){
											$('.alert-message').fadeOut(200, function() {
												});
											},5000);
									 	}
									 	else {
									 		$('.alert-message').fadeIn(200, function() {
											$(this).css('color','red');
											$(this).addClass('alert-danger').html('Please Select A Lecturer To View Attendance');
											});
											setTimeout(function(){
											$('.alert-message').fadeOut(200, function() {
												});
											},5000);
									 	}
									 }
                           });
                          

					$(document).on('click', '#profile-image', function(){
						document.querySelector('#faculty-image').click();
					});


			$(document).on('click', '.s_checkbox', function(){
			  	if($('.checkbox').prop('checked') == true)
			  	{
			  		$('.checkbox').prop('checked',true);
			  	}
			  	else
			  	{
			  		$('.checkbox').prop('checked',false);
			  	}
			  });

			$(document).on('click', '.runs', function(){
			  	if($('.runs').prop('checked') == true)
			  	{
			  		$('.runs').attr('value', 'Yes');
			  	}
			  	else
			  	{
			  		$('.runs').attr('value', 'no');
			  	}
			  });


			

			$('#Attendanceform').submit(function(){
					$.ajax({
					url:''+dir+'attend.php',
					type:'POST',
					data:new FormData(this),
					contentType:false,
					cache:false,
					processData:false,
					beforeSend:function(data)
					{
					
					},
					success:function(data)
					{
						move();
						$('.att_view').remove();
						$('.attend_sheet_header').remove();
						$('#attendanceInfo').remove();
						$('#attendancePrint').remove();
						$('.viewcontent').show();
						$('.viewcontent').append(data);

					}

					});
				});


                     
//end of document
});

