<?php 

	/**
	 * 
	 */
	class DB 
	{
		private static $_instance= null;
		private $_pdo, $_query, $_error = false, $_result, $_count = 0, $_lastInsertedID = null;

		public $result, $count;
		private function __construct()
		{
			try 
			{
				$this->_pdo = new PDO("mysql:host=".db_host.";dbname=".db_name.";Charset=utf8", db_user, db_pass);
			} catch (PDOException $e) {
				die($e->getMessage());
			}
			
		}

		public static function getInstance()
		{
			if (!isset(self::$_instance)) 
			{
				self::$_instance = new DB();
			}

			return self::$_instance;
		}

		public function query($sql, $params =[], $condParams = [])
		{
			 $this->_error = false;
			
			 if ($this->_query = $this->_pdo->prepare($sql)) 
			 {
			 	$x = 1;

			 	//getting query binding parameters 
			 	if (count($params)) 
			 	{
			 		//assigning binding values using foreach looping
			 		foreach ($params as $param) 
			 		{
			 			$this->_query->bindValue($x, $param);
			 			$x++;
			 		}
			 		
			 	}

				if (count($condParams)) 
			 	{
			 		//assigning binding values using foreach looping
			 		foreach ($condParams as $condParam) 
			 		{
			 			$this->_query->bindValue($x, $condParam);
			 			$x++;
			 		}
			 	}//end of binding

			 	//executing the query
			 	if ($this->_query->execute()) 
			 	{
			 		$this->_result = $this->_query->fetchALL(PDO::FETCH_OBJ);
			 		$this->_count = $this->_query->rowCount();

			 		$this->result = $this->_query->fetchALL(PDO::FETCH_OBJ);
			 		$this->count = $this->_query->rowCount();

			 		$this->_lastInsertedID = $this->_pdo->lastInsertId();

			 	}
			 	else
			 	{
			 		$this->_error = true;
			 	}
			 }

			 return $this;
		}


	protected function _read($table, $params = [])
	{
		$conditionString = '';
		$bind = [];
		$order = '';
		$limit = '';

		//conditions
		if (isset($params['conditions'])) 
		{
			if (is_array($params['conditions'])) 
			{
				foreach ($params['conditions'] as $condition) 
				{
					$conditionString .= ' ' . $condition . 'AND';	
				}
				$conditionString = trim($conditionString);
				$conditionString = rtrim($conditionString, 'AND');
			}
			else
			{
				$conditionString = $params['conditions'];
			}

   
			if ($conditionString != '') 
			{
				$conditionString = ' WHERE ' . $conditionString;
			}
		}

		//binding
		if (array_key_exists('bind', $params)) 
		{
			$bind = $params['bind'];
		}

		//order
		if (array_key_exists('order', $params)) 
		{
			$oder = ' ORDER BY ' . $params['order'];
		}

		//limit
		if (array_key_exists('limit', $params)) 
		{
			$limit = ' LIMIT ' . $params['limit'];
		}

		$sql = "SELECT * FROM {$table}{$conditionString}{$order}{$limit}";
		if ($this->query($sql, $bind)) 
		{
			if (!count($this->_result)) 
			{
				return false;			
			}
			else
			{
				return true;
			}
			return false;
		}
	}



	public function find($table, $params = [])
	{
		if ($this->_read($table, $params)) 
		{
			return $this->results();	
		}
		
		return false;
		
	}


		public function findFirst($table, $params = [])
		{
			if ($this->_read($table, $params)) 
			{
				return $this->first();	
			}
			
			return false;
		}


		public function insert($table, $fields = [])
		{
			$fieldString = '';
			$valueString = '';
			$values = [];

			foreach ($fields as $field => $value) 
			{
				$fieldString .= '`' . $field . '`,';
				$valueString .= '?,';
				$values[] = $value;
			}

			$fieldString = rtrim($fieldString, ',');
			$valueString = rtrim($valueString, ',');
			$sql = "INSERT INTO {$table} ({$fieldString}) VALUES ({$valueString})";
			
			if (!$this->query($sql, $values)->error()) 
			{
				return true;	
			}
			else
			{
				return false;
			}
		}


		public function update($table, $fields = [], $conditions = [])
		{
			$fieldString = '';
			$condString = '';
			$values = [];
			$condValues = [];

			foreach ($fields as $field => $value)
			{
				$fieldString .= '' . $field . ' = ?,';
				$values[] = $value;
			}

			$fieldString = trim($fieldString);
			$fieldString = rtrim($fieldString, ',');

			foreach ($conditions as $condition => $value) 
			{
				$condString .= ' ' . $condition . ' = ? AND';	
				$condValues[] = $value;
			}

			$condString = trim($condString);
			$condString = rtrim($condString, 'AND');

			$sql = "UPDATE {$table} SET {$fieldString} WHERE {$condString}";

			if (!$this->query($sql, $values, $condValues)->error()) 
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public function select($table, $columns = [], $conditions = [])
		{
			$columnString = '';
			$condString = '';
			$values = [];
			$condValues = [];

			foreach ($columns as $column => $value)
			{
				$columnString .= '' . $column . ', ';
				$values[] = $value;
			}

			$columnString = trim($columnString);
			$columnString = rtrim($columnString, ',');

			foreach ($conditions as $condition => $value) 
			{
				$condString .= ' ' . $condition . ' = ? AND';	
				$condValues[] = $value;
			}

			$condString = trim($condString);
			$condString = rtrim($condString, 'AND');

			$sql = "SELECT {$columnString} FROM {$table} WHERE {$condString}";

			if (!$this->query($sql, $condValues)->error()) 
			{
				return true;
			}
			else
			{
				return false;
			}
		}

	public function condselect($table, $columns = [], $conditions = [], $logics = [])
		{
			$columnString = '';
			$condString = '';
			$values = [];
			$condValues = [];

			foreach ($columns as $column => $value)
			{
				$columnString .= '' . $column . ', ';
				$values[] = $value;
			}

			$columnString = trim($columnString);
			$columnString = rtrim($columnString, ',');
			$x = 1;
			foreach ($conditions as $condition => $value) 
			{
				$condString .= ' ' . $condition . ' ' .$logics[$x]. ' ? AND';	
				$condValues[] = $value;
				$x++;
			}

			$condString = trim($condString);
			$condString = rtrim($condString, 'AND');

			$sql = "SELECT {$columnString} FROM {$table} WHERE {$condString}";

			if (!$this->query($sql, $condValues)->error()) 
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
		public function selectAll($table, $conditions = [])
		{
			$condString = '';
			$values = [];
			$condValues = [];

			if (empty($conditions)) {
				$sql = "SELECT * FROM {$table}";
			}
			else
			{
				foreach ($conditions as $condition => $value) 
				{
					$condString .= ' ' . $condition . ' = ? AND';	
					$condValues[] = $value;
				}

				$condString = trim($condString);
				$condString = rtrim($condString, 'AND');

				$sql = "SELECT * FROM {$table} WHERE {$condString}";
			}

			if (!$this->query($sql, $condValues)->error()) 
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public function delete($table, $conditions = [])
		{
			$condString = '';
			$condValues = [];

			foreach ($conditions as $condition => $value) 
			{
				$condString .= ' ' . $condition . ' = ? AND';	
				$condValues[] = $value;
			}

			$condString = trim($condString);
			$condString = rtrim($condString, 'AND');

			$sql = "DELETE FROM {$table} WHERE {$condString}";
			if (!$this->query($sql, $condValues)->error()) 
			{
				return true;	
			}
			else 
			{
				return false;
			}
		}

		public function results()
		{
			return $this->_result; 
		}

		public function first()
		{
			return (!empty($this->_result)) ? $this->_result[0] : [];
		}

		public function error()
		{
			return $this->_error;
		}

		public function count()
		{
			return $this->_count;
		}

		public function lastId()
		{
			return $this->_lastInsertID;
		}

		public function get_columns($table)
		{
			return $this->query("SHOW COLUMNS FROM {$table}")->results();
		}


	}

 ?>